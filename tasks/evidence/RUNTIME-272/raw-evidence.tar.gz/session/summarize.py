from pathlib import Path
import json,statistics,sys,yaml
root=Path(sys.argv[1]); manifest=yaml.safe_load((root/'protocol.json').read_text())['manifest'] if False else json.loads((root/'protocol.json').read_text())['manifest']
rows={}
for d in sorted(root.glob('[0-9][0-9]-*')):
    raw=d/'raw-result.json'
    if not raw.exists(): continue
    r=json.loads(raw.read_text());arm=r['diagnostics']['arm']
    for scenario,detail in r['diagnostics']['scenarios'].items():
        hot=json.loads((d/f'{scenario}.hotspots.json').read_text())
        rows.setdefault(scenario,{}).setdefault(arm,[]).append({'wall_ms':detail['execution']['wall_ms'],'compiler_ms':sum(x['duration_ms'] for x in hot),'compiler_invocations':len(hot),'source_count':len({x['source'] for x in hot}),'sample':d.name})
summary={'benchmark_id':manifest['benchmark_id'],'source_revisions':manifest['params']['source_revisions'],'scenarios':{},'gate_failures':[]}
for scenario,arms in rows.items():
    s={}; summary['scenarios'][scenario]=s
    for arm,values in arms.items():
        s[arm]={'count':len(values),'samples':values}
        for metric in ['wall_ms','compiler_ms','compiler_invocations','source_count']:
            numbers=[v[metric] for v in values]; s[arm][metric]={'median':statistics.median(numbers),'min':min(numbers),'max':max(numbers)}
    if 'before' in s and 'after' in s:
        s['delta']={}
        for metric in ['wall_ms','compiler_ms']:
            b=s['before'][metric]['median'];a=s['after'][metric]['median'];d=a-b
            allowance=.02*b if metric=='compiler_ms' or scenario=='clean' else max(.02*b,100)
            s['delta'][metric]={'absolute_ms':d,'percent':100*d/b if b else None,'allowance_ms':allowance,'exceeds_original_allowance':d>allowance}
            if d>allowance and scenario!='new_fixture_impl': summary['gate_failures'].append(f'{scenario}.{metric}')
        print(scenario, 'wall', round(s['before']['wall_ms']['median']/1000,3),'->',round(s['after']['wall_ms']['median']/1000,3),'compiler',round(s['before']['compiler_ms']['median']/1000,3),'->',round(s['after']['compiler_ms']['median']/1000,3),'fanout',s['before']['source_count']['median'],'->',s['after']['source_count']['median'])
Path(sys.argv[2]).write_text(json.dumps(summary,indent=2)+'\n')
print('Original allowance exceeded:',summary['gate_failures'])
