#!/usr/bin/env bash
set -euo pipefail
git diff --exit-code 5f2f99ef0f5c05218ca4ed67b28da87ee9a2df32 -- src tests cmake
test "$(cat /tmp/intrinsic-runtime272/build/.compile-measurement-owner)" = /tmp/intrinsic-runtime272/baseline-pilot
mv /tmp/intrinsic-runtime272/build /tmp/intrinsic-runtime272/pilot-build
python3 tools/analysis/benchmark_compile_iteration.py --source /tmp/intrinsic-runtime272/source --build /tmp/intrinsic-runtime272/build --output /tmp/intrinsic-runtime272/results --manifest benchmarks/ci/manifests/runtime272_reuse_compile.yaml > /tmp/intrinsic-runtime272/results.log 2>&1
python3 tools/benchmark/validate_benchmark_results.py --root /tmp/intrinsic-runtime272/results/results --manifests-root benchmarks --strict
cmp /tmp/intrinsic-runtime272/baseline-pilot/01-before-1/dependencies.json /tmp/intrinsic-runtime272/results/01-before-1/dependencies.json
python3 /tmp/intrinsic-four-reuse/summarize.py /tmp/intrinsic-runtime272/results /tmp/intrinsic-four-reuse/runtime272-summary.json
python3 /tmp/intrinsic-four-reuse/report-table.py runtime272 > /tmp/intrinsic-four-reuse/runtime272-measurement-table.md
