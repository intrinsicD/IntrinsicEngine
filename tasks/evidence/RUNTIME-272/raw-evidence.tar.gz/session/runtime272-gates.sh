#!/usr/bin/env bash
set -euo pipefail
run() {
  local stage="$1"; shift
  local rc=0
  "$@" > "/tmp/intrinsic-four-reuse/runtime272-$stage.log" 2>&1 || rc=$?
  printf '%s\n' "$rc" > "/tmp/intrinsic-four-reuse/runtime272-$stage.exit"
  printf '%s: %s\n' "$stage" "$rc"
  tail -5 "/tmp/intrinsic-four-reuse/runtime272-$stage.log"
  return "$rc"
}
run ci-configure cmake --preset ci
run focused-build cmake --build --preset ci --target IntrinsicRuntimeContractTests --parallel 4
run focused-tests ctest --test-dir build/ci --output-on-failure -R 'NormalEstimation|KernelDensity|PointSpacing|OutlierAnalysis|KeypointAnalysis|BilateralFilter|DensityWeight|DescriptorAnalysis|RegistrationDomains|CompilationLocality' -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60
run clang20-configure cmake --preset ci -B build/ci-runtime272-clang20 --fresh -DCMAKE_C_COMPILER=/usr/bin/clang-20 -DCMAKE_CXX_COMPILER=/usr/bin/clang++-20 -DCMAKE_CXX_COMPILER_CLANG_SCAN_DEPS=/usr/bin/clang-scan-deps-20 -DEXTRINSIC_BACKEND=Null -DINTRINSIC_PLATFORM_BACKEND=Null -DINTRINSIC_HEADLESS_NO_GLFW=ON -DINTRINSIC_ENABLE_CCACHE=OFF -DCMAKE_C_COMPILER_LAUNCHER= -DCMAKE_CXX_COMPILER_LAUNCHER= -DVCPKG_MANIFEST_INSTALL=OFF
run clang20-build cmake --build build/ci-runtime272-clang20 --target EditorFeatureTestSupportObjs IntrinsicRuntimeContractTests --parallel 4
run clang20-tests ctest --test-dir build/ci-runtime272-clang20 --output-on-failure -R 'NormalEstimation|KernelDensity|PointSpacing|OutlierAnalysis|KeypointAnalysis|BilateralFilter|DensityWeight|DescriptorAnalysis|RegistrationDomains' -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60
run ci-full-build cmake --build --preset ci --target IntrinsicTests --parallel 4
run ci-full-tests ctest --test-dir build/ci --output-on-failure -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60 || exit $?
run asan-configure cmake --preset ci-asan --fresh -DINTRINSIC_GROUP_PURE_CTEST=ON
run asan-build cmake --build --preset ci-asan --target IntrinsicCpuTests --parallel 4
run asan-tests ctest --test-dir build/ci-asan --output-on-failure -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60 --parallel 1 || exit $?
run ubsan-configure cmake --preset ci-ubsan --fresh -DINTRINSIC_GROUP_PURE_CTEST=ON
run ubsan-build cmake --build --preset ci-ubsan --target IntrinsicCpuTests --parallel 4
run ubsan-tests ctest --test-dir build/ci-ubsan --output-on-failure -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60 --parallel 1
