# RUNTIME-272 matched compile cost

Six alternating samples, three per arm, use the frozen manifest
[`runtime272_reuse_compile.yaml`](../../../benchmarks/ci/manifests/runtime272_reuse_compile.yaml).
Clang 23, ci-derived Debug, Null/headless, four jobs, tests enabled,
benchmarks disabled, ccache disabled, identical preinstalled dependencies and
source/build paths; no competing builds or tests during timing. Input pre-read,
no cache flushing or CPU/governor control. These are local acceptance measurements,
not a general performance improvement claim.

