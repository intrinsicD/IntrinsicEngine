
The declaration probe deliberately compares different scopes: the baseline
`EditorFeatureTestContext.hpp` is broad; the candidate's new
`PointDomainFixture.hpp` is narrow. The duplicated topology did not previously
live in the broad header. Compiler-job counts report the actual consequence
of editing each declaration surface. The new `PointDomainFixture.cpp` probe
is an additional after-only cost; its before arm is a settled no-op and is
excluded from matched regression gates.

All samples, including the separate pre-edit pilot, are retained. Exact compiler
invocations, dependency fingerprints and canonical results remain in the raw
archive. The source bundle preserves the before, reviewed candidate and failed
first-build snapshots and requires repository commit
`66976e593b9562e5f0c34688e937d741016768cd`. The failed first build missed two
accessor callers; the corrected candidate was reviewed and fully reverified
before any after-arm timing. No source changed during the six matched samples.

The full ci suite selected 4,879 tests with zero failures; full ASan selected
3,230 with zero failures. Both retain the expected GLFW lifetime skip. Fresh
Clang 20 compiled the support producer and runtime executable, with 101 selected
contract cases passing and unchanged dependency fingerprints. The 226 focused
ci cases passed before and after extraction. Full UBSan failed only the
independently baseline-reproduced [BUG-206](../../backlog/bugs/BUG-206-uv-duplicate-submit-phase-race.md).
This repository-gate limitation remains explicit; the implementation review
and compile comparison do not imply that the task has retired.
