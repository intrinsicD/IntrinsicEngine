from pathlib import Path
import re
names=['NormalEstimation','KernelDensityOperations','PointSpacingOperations','OutlierAnalysis','KeypointAnalysisOperations','BilateralFilterOperations','DensityWeightOperations','DescriptorAnalysisOperations']
p=Path('tests/contract/runtime/Test.NormalEstimation.cpp');original=p.read_text();a=original.index('        auto entity = scene.Create();');b=original.index('        auto &props = Properties(',a);topology=original[a:b]
Path('tests/support/PointDomainFixture.hpp').write_text('''// Narrow property-domain fixtures for runtime method contract tests.
// Topology construction and property lookup compile in PointDomainFixture.cpp.
#pragma once

#include <entt/entity/fwd.hpp>

import Extrinsic.ECS.Scene.Registry;
import Extrinsic.Runtime.GeometryProperty.Types;
import Geometry.Properties;

namespace Intrinsic::Tests
{
    // Callers select one of the eight canonical point domains.
    entt::entity MakePointDomainSource(Extrinsic::ECS::Scene::Registry& scene,
                                     Extrinsic::Runtime::GeometryElementDomain domain);

    // The entity must already contain the requested domain.
    Geometry::PropertySet& PointDomainProperties(Extrinsic::ECS::Scene::Registry& scene,
                                                entt::entity entity,
                                                Extrinsic::Runtime::GeometryElementDomain domain);
}
''')
Path('tests/support/PointDomainFixture.cpp').write_text('''#include <array>
#include <utility>
#include <glm/glm.hpp>
#include <entt/entity/registry.hpp>

#include "PointDomainFixture.hpp"

import Extrinsic.Runtime.GeometryAvailability;
import Extrinsic.ECS.Components.GeometrySources;
import Extrinsic.ECS.Components.GeometrySourcesPopulate;
import Geometry.Graph;
import Geometry.HalfedgeMesh;

namespace Intrinsic::Tests
{
    namespace R = Extrinsic::Runtime;
    namespace GS = Extrinsic::ECS::Components::GeometrySources;
    using D = R::GeometryElementDomain;

    Geometry::PropertySet& PointDomainProperties(Extrinsic::ECS::Scene::Registry& scene,
                                                entt::entity entity, D domain)
    {
        return *const_cast<Geometry::PropertySet*>(
            R::ResolveGeometryPropertySet(R::BuildGeometryAvailability(scene.Raw(), entity), domain));
    }

    entt::entity MakePointDomainSource(Extrinsic::ECS::Scene::Registry& scene, D domain)
    {
        constexpr std::array<glm::vec3, 4> plane{{{0, 0, 0}, {2, 0, 0}, {0, 3, 0}, {2, 3, 0}}};
'''+topology+'''        return entity;
    }
}
''')
for name in names:
 p=Path(f'tests/contract/runtime/Test.{name}.cpp');s=p.read_text();start=s.index('    Geometry::PropertySet &Properties(');end=s.index('    entt::entity Make(',start);s=s[:start]+s[end:]
 assert s.count(topology)==1;s=s.replace(topology,'        auto entity = Intrinsic::Tests::MakePointDomainSource(scene, domain);\n')
 s=re.sub(r'\bProperties\(', 'PointDomainProperties(', s);s=s.replace('using D = R::GeometryElementDomain;','using D = R::GeometryElementDomain;\nusing Intrinsic::Tests::PointDomainProperties;')
 s=s.replace('#include "SandboxEditorJobHarness.hpp"','#include "SandboxEditorJobHarness.hpp"\n#include "PointDomainFixture.hpp"')
 s=s.replace('import Geometry.Graph;\n','')
 if name!='NormalEstimation':
  s=s.replace('import Geometry.HalfedgeMesh;\n','').replace('import Extrinsic.ECS.Components.GeometrySourcesPopulate;\n','')
 if s.count('plane')==1: s='\n'.join(line for line in s.split('\n') if 'constexpr std::array<glm::vec3, 4> plane' not in line)
 p.write_text(s)
p=Path('tests/contract/runtime/Test.RegistrationDomains.cpp');s=p.read_text().replace('#include "SandboxEditorJobHarness.hpp"','#include "SandboxEditorJobHarness.hpp"\n#include "PointDomainFixture.hpp"');s=s.replace('        auto available=R::BuildGeometryAvailability(scene.Raw(), entity);\n        auto* properties=const_cast<Geometry::PropertySet*>(R::ResolveGeometryPropertySet(available,domain));','        auto* properties = &Intrinsic::Tests::PointDomainProperties(scene, entity, domain);');p.write_text(s)
p=Path('tests/CMakeLists.txt');s=p.read_text().replace('        SOURCES support/EditorFeatureTestContext.cpp','        SOURCES\n            support/EditorFeatureTestContext.cpp\n            support/PointDomainFixture.cpp');p.write_text(s)
p=Path('tests/support/README.md');s=p.read_text().replace('`GraphicsTestSupport.hpp` declares','`PointDomainFixture.hpp` exposes the narrow shared source builder and property-set\naccessor for runtime point-domain contracts. Its mesh/graph construction and domain\nresolution compile in `PointDomainFixture.cpp` through `EditorFeatureTestSupportObjs`;\nmethod-specific samples, expected values and failure injection stay in each test.\n\n`GraphicsTestSupport.hpp` declares');p.write_text(s)
p=Path('tools/agents/skills/intrinsicengine-reuse/references/owner-routes.md');s=p.read_text();s+='| Build runtime method test sources for canonical property domains | `tests/support/PointDomainFixture.hpp/.cpp`: `MakePointDomainSource`, `PointDomainProperties` | Eight method fixtures share exact mesh/graph/cloud topology through a narrow header; RegistrationDomains shares only property access. Sample values, masks, configs and assertions stay in callers; support compiles in `EditorFeatureTestSupportObjs`. |\n';p.write_text(s)
