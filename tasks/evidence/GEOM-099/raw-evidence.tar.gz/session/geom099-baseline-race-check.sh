#!/usr/bin/env bash
set -euo pipefail
before=14af21fbaf3590cb96df7f478fd94247224facf3
after=1c1903c66a2866ed3cb55097a8bd1e9e71156a22
files=(src/geometry/Geometry.HalfedgeMesh.Parameterization.cpp src/geometry/Geometry.HalfedgeMesh.Utils.cpp src/geometry/Geometry.HalfedgeMesh.Utils.cppm src/geometry/Geometry.Parameterization.Bff.cpp src/geometry/Geometry.Parameterization.Harmonic.cpp tests/unit/geometry/Test.MeshTopologyUtilities.cpp)
git diff --exit-code "$after" -- "${files[@]}"
restore() {
  git restore --source="$after" --worktree -- "${files[@]}"
}
trap restore EXIT
git restore --source="$before" --worktree -- "${files[@]}"
python3 /tmp/intrinsic-four-reuse/snapshot.py geom099-baseline-race > /tmp/intrinsic-four-reuse/geom099-baseline-race-source.log
cmake --build --preset ci-ubsan --target IntrinsicRuntimeContractTests --parallel 4 > /tmp/intrinsic-four-reuse/geom099-baseline-race-build.log 2>&1
rc=0
ctest --test-dir build/ci-ubsan --output-on-failure -R '^SandboxEditorUi.UvRegenerationDuplicateSubmitUsesExistingActiveJob$' --repeat until-fail:100 --timeout 60 > /tmp/intrinsic-four-reuse/geom099-baseline-race-tests.log 2>&1 || rc=$?
printf '%s\n' "$rc" > /tmp/intrinsic-four-reuse/geom099-baseline-race-tests.exit
restore
trap - EXIT
cmake --build --preset ci-ubsan --target IntrinsicCpuTests --parallel 4 > /tmp/intrinsic-four-reuse/geom099-restored-ubsan-build.log 2>&1
ctest --test-dir build/ci-ubsan --output-on-failure -R 'BoundaryFirstFlattening|HarmonicParameterization|ParameterizationDispatch|LSCM|MeshTopologyUtilities' -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60 --parallel 1 > /tmp/intrinsic-four-reuse/geom099-restored-ubsan-geometry.log 2>&1
git diff --exit-code "$after" -- "${files[@]}"
tail -8 /tmp/intrinsic-four-reuse/geom099-baseline-race-tests.log
