#!/usr/bin/env bash
set -euo pipefail
rc=0
ctest --test-dir build/ci --output-on-failure -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60 > /tmp/intrinsic-four-reuse/geom099-final-cpu-tests.log 2>&1 || rc=$?
printf '%s\n' "$rc" > /tmp/intrinsic-four-reuse/geom099-final-cpu-tests.exit
tail -8 /tmp/intrinsic-four-reuse/geom099-final-cpu-tests.log
test "$(cat /tmp/intrinsic-geom099/build/.compile-measurement-owner)" = /tmp/intrinsic-geom099/baseline-pilot-03
mv /tmp/intrinsic-geom099/build /tmp/intrinsic-geom099/pilot-build
python3 tools/analysis/benchmark_compile_iteration.py --source /tmp/intrinsic-geom099/source --build /tmp/intrinsic-geom099/build --output /tmp/intrinsic-geom099/results --manifest benchmarks/ci/manifests/geom099_reuse_compile.yaml > /tmp/intrinsic-geom099/results.log 2>&1
python3 tools/benchmark/validate_benchmark_results.py --root /tmp/intrinsic-geom099/results/results --manifests-root benchmarks --strict
python3 /tmp/intrinsic-four-reuse/summarize.py /tmp/intrinsic-geom099/results /tmp/intrinsic-four-reuse/geom099-summary.json
