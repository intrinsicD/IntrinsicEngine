#!/usr/bin/env bash
set -euo pipefail
while kill -0 1218460 2>/dev/null; do sleep 2; done
run() {
  local stage="$1"; shift
  printf '%s\n' "$stage"
  local rc=0
  "$@" > "/tmp/intrinsic-four-reuse/$stage.log" 2>&1 || rc=$?
  printf '%s\n' "$rc" > "/tmp/intrinsic-four-reuse/$stage.exit"
  tail -6 "/tmp/intrinsic-four-reuse/$stage.log"
  return "$rc"
}
run geom099-final-focused-build cmake --build --preset ci --target IntrinsicGeometryTests --parallel 4
run geom099-final-focused-tests ctest --test-dir build/ci --output-on-failure -R 'BoundaryFirstFlattening|HarmonicParameterization|ParameterizationDispatch|LSCM|MeshTopologyUtilities' -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60
run geom099-asan-configure cmake --preset ci-asan --fresh -DINTRINSIC_GROUP_PURE_CTEST=ON
run geom099-asan-build cmake --build --preset ci-asan --target IntrinsicCpuTests --parallel 4
run geom099-asan-tests ctest --test-dir build/ci-asan --output-on-failure -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60 --parallel 1
run geom099-ubsan-configure cmake --preset ci-ubsan --fresh -DINTRINSIC_GROUP_PURE_CTEST=ON
run geom099-ubsan-build cmake --build --preset ci-ubsan --target IntrinsicCpuTests --parallel 4
run geom099-ubsan-tests ctest --test-dir build/ci-ubsan --output-on-failure -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60 --parallel 1
