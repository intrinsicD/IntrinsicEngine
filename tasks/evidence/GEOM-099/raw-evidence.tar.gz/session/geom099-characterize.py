from pathlib import Path
p=Path('tests/support/geometry/MeshBuilders.cpp')
s=p.read_text()+'''
Geometry::HalfedgeMesh::Mesh MakeDiskAndClosedComponent()
{
    auto mesh = MakeTetrahedron();
    const auto a = mesh.AddVertex({3.0f, 0.0f, 0.0f});
    const auto b = mesh.AddVertex({4.0f, 0.0f, 0.0f});
    const auto c = mesh.AddVertex({3.0f, 1.0f, 0.0f});
    (void)mesh.AddTriangle(a, b, c);
    return mesh;
}

Geometry::HalfedgeMesh::Mesh MakeBowtieTriangles()
{
    auto mesh = MakeSingleTriangle();
    const auto a = mesh.AddVertex({-1.0f, 0.0f, 0.0f});
    const auto b = mesh.AddVertex({0.0f, -1.0f, 0.0f});
    (void)mesh.AddTriangle(Geometry::VertexHandle{0u}, a, b);
    return mesh;
}
''';p.write_text(s)
for file,suite,call,fail in [('Test.BoundaryFirstFlattening.cpp','BoundaryFirstFlattening','Geometry::Parameterization::ComputeBFF(mesh)','    EXPECT_EQ(result.Status, Geometry::Parameterization::BffStatus::NotDiskTopology);\n    EXPECT_TRUE(result.UVs.empty());'),('Test.HarmonicParameterization.cpp','HarmonicParameterization','Geometry::Parameterization::ComputeHarmonic(mesh)','    ASSERT_TRUE(result.has_value());\n    EXPECT_EQ(result->Status, Geometry::Parameterization::HarmonicStatus::NotDiskTopology);'),('Test_Parameterization.cpp','LSCM','Geometry::Parameterization::ComputeLSCM(mesh)','    EXPECT_FALSE(result.has_value());')]:
    p=Path('tests/unit/geometry')/file;s=p.read_text()
    for name,setup in [('DisconnectedClosedComponentIsRejected','    auto mesh = MakeDiskAndClosedComponent();\n    ASSERT_EQ(Geometry::MeshUtils::CollectBoundaryLoops(mesh).size(), 1u);'),('NonmanifoldVertexIsRejected','    auto mesh = MakeBowtieTriangles();\n    ASSERT_FALSE(mesh.IsManifold(Geometry::VertexHandle{0u}));'),('IsolatedVertexIsRejected','    auto mesh = MakeSingleTriangle();\n    (void)mesh.AddVertex({2.0f, 2.0f, 0.0f});')]:
        s+=f'\nTEST({suite}, {name})\n{{\n{setup}\n    const auto result = {call};\n{fail}\n}}\n'
    if suite=='BoundaryFirstFlattening':
        for name,setup in [('PuncturedGenusOneMeshIsRejected','    auto mesh = MakePuncturedTorus();'),('MultipleBoundaryLoopsAreRejected','    auto mesh = MakeCube();\n    mesh.DeleteFace(Geometry::FaceHandle{0u});\n    mesh.DeleteFace(Geometry::FaceHandle{2u});\n    ASSERT_EQ(Geometry::MeshUtils::CollectBoundaryLoops(mesh).size(), 2u);')]:
            s+=f'\nTEST({suite}, {name})\n{{\n{setup}\n    const auto result = {call};\n{fail}\n}}\n'
    success='    ASSERT_TRUE(result.Succeeded());\n    const auto& uvs = result.UVs;' if suite=='BoundaryFirstFlattening' else ('    ASSERT_TRUE(result.has_value());\n    ASSERT_EQ(result->Status, Geometry::Parameterization::HarmonicStatus::Success);\n    const auto& uvs = result->UVs;' if suite=='HarmonicParameterization' else '    ASSERT_TRUE(result.has_value());\n    EXPECT_TRUE(result->Converged);\n    const auto& uvs = result->UVs;')
    s+=f'''\nTEST({suite}, DeletedSlotsPreserveLiveDiskUvs)
{{
    auto mesh = MakeTwoTriangleSquare();
    mesh.DeleteFace(Geometry::FaceHandle{{0u}});
    ASSERT_GT(mesh.VerticesSize(), mesh.VertexCount());
    ASSERT_GT(mesh.EdgesSize(), mesh.EdgeCount());
    ASSERT_GT(mesh.FacesSize(), mesh.FaceCount());
    const auto result = {call};
{success}
    ASSERT_EQ(uvs.size(), mesh.VerticesSize());
    for (std::size_t i = 0; i < mesh.VerticesSize(); ++i)
    {{
        if (!mesh.IsDeleted(Geometry::VertexHandle{{static_cast<Geometry::PropertyIndex>(i)}}))
        {{
            EXPECT_TRUE(std::isfinite(uvs[i].x));
            EXPECT_TRUE(std::isfinite(uvs[i].y));
        }}
    }}
}}
'''
    p.write_text(s)
