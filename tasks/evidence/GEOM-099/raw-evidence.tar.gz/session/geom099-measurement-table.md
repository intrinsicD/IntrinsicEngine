Source before: 14af21fbaf3590cb96df7f478fd94247224facf3 

Source after: 1c1903c66a2866ed3cb55097a8bd1e9e71156a22

| Probe | Wall median seconds, before → after | Wall delta | Compiler sum median seconds, before → after | Compiler delta | Compiler jobs, before → after |
| --- | --- | --- | --- | --- | --- |
| clean | 185.643 → 186.083 | +0.24% | 713.672 → 715.643 | +0.28% | 395 → 395 |
| noop | 0.069 → 0.066 | -4.38% | 0.000 → 0.000 | n/a (zero before) | 0 → 0 |
| bff_impl | 2.914 → 3.003 | +3.07% | 1.465 → 1.455 | -0.68% | 1 → 1 |
| harmonic_impl | 2.320 → 2.787 | +20.14% | 0.863 → 1.325 | +53.53% | 1 → 1 |
| lscm_impl | 3.238 → 3.230 | -0.25% | 1.781 → 1.757 | -1.35% | 1 → 1 |
| utils_interface | 90.406 → 90.767 | +0.40% | 342.059 → 343.552 | +0.44% | 84 → 85 |

Per-sample values and min/max ranges are in `compile-summary.json`; all original logs, Ninja timings, configure state, dependencies and canonical results are in `raw-evidence.tar.gz`.

Original threshold crossings: harmonic_impl.wall_ms, harmonic_impl.compiler_ms

implementation: 4585 → 4477 physical lines (-108).

regression_tests: 1326 → 1523 physical lines (+197).

total: 5911 → 6000 physical lines (+89).
