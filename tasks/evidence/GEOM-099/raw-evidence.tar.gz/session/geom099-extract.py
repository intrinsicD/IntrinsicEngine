from pathlib import Path
root=Path('src/geometry')
files=['Geometry.Parameterization.Bff.cpp','Geometry.Parameterization.Harmonic.cpp','Geometry.HalfedgeMesh.Parameterization.cpp']
for name in files:
    p=root/name;s=p.read_text();start=s.index('        [[nodiscard]] bool HasDiskTopology(')
    end=s.index('\n        [[nodiscard]]',start+1)
    if name=='Geometry.Parameterization.Harmonic.cpp': start=s.index('        // A connected orientable triangle mesh')
    if name=='Geometry.HalfedgeMesh.Parameterization.cpp': start=s.index('        // One boundary loop is not sufficient')
    s=s[:start]+s[end+1:]
    if name==files[0]: s=s.replace('HasDiskTopology(mesh, disk.Boundary)','MeshUtils::IsConnectedManifoldWithEulerOne(mesh, disk.Boundary.front())')
    elif name==files[1]:
        s=s.replace('import Geometry.HalfedgeMesh;','import Geometry.HalfedgeMesh;\nimport Geometry.HalfedgeMesh.Utils;')
        s=s.replace('HasDiskTopology(mesh, loop)','MeshUtils::IsConnectedManifoldWithEulerOne(mesh, loop.front())')
    else:
        s=s.replace('|| !HasDiskTopology(mesh, boundary.LoopVertices)','|| boundary.LoopVertices.empty()\n            || !MeshUtils::IsConnectedManifoldWithEulerOne(mesh,\n                VertexHandle{static_cast<PropertyIndex>(boundary.LoopVertices.front())})')
    p.write_text(s)
p=root/'Geometry.HalfedgeMesh.Utils.cppm';s=p.read_text();s='// Shared mesh traversal and geometric quantities for geometry algorithms.\n// Nontrivial operations compile once behind this declaration surface.\n'+s
needle='    // --- Index-buffer mesh utilities ---'
s=s.replace(needle,'''    // Requires a valid live seed and valid mesh connectivity. Disk callers must
    // separately require one boundary loop; this predicate alone is not a disk test.
    [[nodiscard]] bool IsConnectedManifoldWithEulerOne(
        const HalfedgeMesh::Mesh& mesh, VertexHandle seed);

'''+needle);p.write_text(s)
p=root/'Geometry.HalfedgeMesh.Utils.cpp';s=p.read_text();needle='    bool TryGetTriangleFaceView('
pos=s.index(needle)
s=s[:pos]+'''    bool IsConnectedManifoldWithEulerOne(const HalfedgeMesh::Mesh& mesh, VertexHandle seed)
    {
        std::vector<std::uint8_t> reached(mesh.VerticesSize(), 0u);
        std::vector<VertexHandle> pending{seed};
        reached[seed.Index] = 1u;
        while (!pending.empty())
        {
            const VertexHandle vertex = pending.back();
            pending.pop_back();
            for (const HalfedgeHandle halfedge : mesh.HalfedgesAroundVertex(vertex))
            {
                const VertexHandle neighbor = mesh.ToVertex(halfedge);
                if (mesh.IsDeleted(neighbor) || reached[neighbor.Index] != 0u)
                    continue;
                reached[neighbor.Index] = 1u;
                pending.push_back(neighbor);
            }
        }

        for (std::size_t vi = 0; vi < mesh.VerticesSize(); ++vi)
        {
            const VertexHandle vertex{static_cast<PropertyIndex>(vi)};
            if (mesh.IsDeleted(vertex))
                continue;
            if (mesh.IsIsolated(vertex) || !mesh.IsManifold(vertex) || reached[vi] == 0u)
                return false;
        }

        const std::int64_t eulerCharacteristic =
            static_cast<std::int64_t>(mesh.VertexCount())
            - static_cast<std::int64_t>(mesh.EdgeCount())
            + static_cast<std::int64_t>(mesh.FaceCount());
        return eulerCharacteristic == 1;
    }

'''+s[pos:];p.write_text(s)
p=Path('docs/architecture/geometry.md');s=p.read_text().replace('one; a punctured positive-genus surface','one. BFF, Harmonic/Tutte and LSCM share the compiled\n`MeshUtils::IsConnectedManifoldWithEulerOne` predicate in\n`Geometry.HalfedgeMesh.Utils`; each solver retains its boundary checks and\nvalidation order. A punctured positive-genus surface');p.write_text(s)
p=Path('tools/agents/skills/intrinsicengine-reuse/references/owner-routes.md');s=p.read_text();s+='\n| Connected manifold mesh with Euler characteristic one | `src/geometry/Geometry.HalfedgeMesh.Utils.cpp`: `MeshUtils::IsConnectedManifoldWithEulerOne` | BFF, Harmonic/Tutte and LSCM retain one-boundary checks and provide a valid live seed. Sparse/deleted slots remain indexed by storage; this predicate alone does not establish disk topology. |\n';p.write_text(s)
