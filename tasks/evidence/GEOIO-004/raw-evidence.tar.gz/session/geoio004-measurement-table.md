Source before: 6975abfc14c5e5b55f62de77b5b022d1f9eda5b6

Source after: 478e32e0a27b9f7569710d8ddd0f503c5840d60a

| Probe | Wall median seconds, before → after | Wall delta | Compiler sum median seconds, before → after | Compiler delta | Compiler jobs, before → after |
| --- | --- | --- | --- | --- | --- |
| clean | 99.580 → 99.796 | +0.22% | 358.268 → 358.811 | +0.15% | 297 → 298 |
| noop | 0.058 → 0.059 | +2.72% | 0.000 → 0.000 | n/a (zero before) | 0 → 0 |
| mesh_loader | 2.532 → 2.518 | -0.54% | 2.020 → 2.016 | -0.20% | 1 → 1 |
| cloud_loader | 2.016 → 2.005 | -0.57% | 1.523 → 1.508 | -0.98% | 1 → 1 |
| private_header | 2.571 → 2.654 | +3.20% | 4.967 → 6.174 | +24.30% | 3 → 4 |

Per-sample values and min/max ranges are in `compile-summary.json`; all original logs, Ninja timings, configure state, dependencies and canonical results are in `raw-evidence.tar.gz`.

Original threshold crossings: private_header.compiler_ms

implementation: 5921 → 5847 physical lines (-74).

regression_tests: 6119 → 6269 physical lines (+150).

total: 12040 → 12116 physical lines (+76).
