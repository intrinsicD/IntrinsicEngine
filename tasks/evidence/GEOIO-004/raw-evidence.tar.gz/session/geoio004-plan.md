## Execution plan — 2026-09-21

Current source confirms two header loops in the mesh and point-cloud LoadPLY
implementations. Move their lexical grammar into a single compiled
`Geometry.IOText.cpp` function declared in the existing private IOText header.
Return only format, ordered element/property records and the exact body byte
offset. Both public APIs retain their current error mapping and body parsers;
mesh alone validates every list-count type as integral after parsing.

The two integral-scalar predicates are equivalent for all parsed enum values,
but their spelling differs: mesh negates the floating predicate; cloud lists
six integral kinds. Keep the existing cloud constexpr form as the shared small
predicate. Do not change binary reads, attributes, alpha, UVs, exporters or
asset routing. The new ordinary compilation unit belongs to the existing
geometry library; no new module, target, abstraction or configuration axis.

Add seven public-loader characterizations before extraction, covering all
scalar aliases, CRLF/whitespace, comments and unknown directives, repeated
format/property/element records, malformed/truncated headers, the ASCII cloud
floating-count exception, and both binary body offsets. Run them on the original
loaders before freezing the before-source identity. Existing body/attribute and
asset-routing tests remain intact. Review the fixed extraction with Claude
Sonnet at medium effort, then run full CPU and sanitizer gates.

The task's focused producer was corrected before baseline measurement:
`Test.GeometryIO.cpp` is owned by `GeometryIoTestObjs` and linked into
`IntrinsicGeometryIoTests`, not `IntrinsicGeometryTests`. Use that actual target
for the focused build and matched compile manifest. This corrects coverage;
all original compile allowances remain unchanged. Freeze Clang 23, ci-derived
Debug Null/headless, four jobs, disabled ccache, exact source commits and
identical dependencies before extraction. Preserve the pilot and at least
three alternating matched samples per arm.
