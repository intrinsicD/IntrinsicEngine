#!/usr/bin/env bash
set -euo pipefail
name="$1"
run() {
  local stage="$1"; shift
  local rc=0
  "$@" > "/tmp/intrinsic-four-reuse/$name-structural-$stage.log" 2>&1 || rc=$?
  printf '%s\n' "$rc" > "/tmp/intrinsic-four-reuse/$name-structural-$stage.exit"
  printf '%s: %s\n' "$stage" "$rc"
  tail -3 "/tmp/intrinsic-four-reuse/$name-structural-$stage.log"
  return "$rc"
}
run tasks python3 tools/agents/check_task_policy.py --root . --strict
run task-links python3 tools/agents/check_task_state_links.py --root . --strict
run links python3 tools/docs/check_doc_links.py --root . --strict
run hygiene python3 tools/repo/check_root_hygiene.py --root . --strict
run mirrors python3 tools/agents/sync_skills.py --check
run claims python3 tools/agents/check_ara_claims.py --root . --strict
run config python3 tools/agents/check_codex_config.py --root . --strict
run allowlist python3 tools/repo/check_layering_allowlist_quality.py --root . --strict
run manifests python3 tools/benchmark/validate_benchmark_manifests.py --root benchmarks --strict
run methods python3 tools/agents/validate_method_manifests.py --root methods --strict
run workflow-evidence python3 tools/agents/workflow_evidence.py validate --root .
run custody python3 tools/agents/experiment_custody.py validate --root .
run whitespace git diff --check
