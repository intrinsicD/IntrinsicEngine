#!/usr/bin/env bash
set -euo pipefail
git diff --exit-code 478e32e0a27b9f7569710d8ddd0f503c5840d60a -- src tests cmake
test "$(cat /tmp/intrinsic-geoio004/build/.compile-measurement-owner)" = /tmp/intrinsic-geoio004/baseline-pilot
mv /tmp/intrinsic-geoio004/build /tmp/intrinsic-geoio004/pilot-build
python3 tools/analysis/benchmark_compile_iteration.py --source /tmp/intrinsic-geoio004/source --build /tmp/intrinsic-geoio004/build --output /tmp/intrinsic-geoio004/results --manifest benchmarks/ci/manifests/geoio004_reuse_compile.yaml > /tmp/intrinsic-geoio004/results.log 2>&1
python3 tools/benchmark/validate_benchmark_results.py --root /tmp/intrinsic-geoio004/results/results --manifests-root benchmarks --strict
cmp /tmp/intrinsic-geoio004/baseline-pilot/01-before-1/dependencies.json /tmp/intrinsic-geoio004/results/01-before-1/dependencies.json
python3 /tmp/intrinsic-four-reuse/summarize.py /tmp/intrinsic-geoio004/results /tmp/intrinsic-four-reuse/geoio004-summary.json
python3 /tmp/intrinsic-four-reuse/report-table.py geoio004 > /tmp/intrinsic-four-reuse/geoio004-measurement-table.md
