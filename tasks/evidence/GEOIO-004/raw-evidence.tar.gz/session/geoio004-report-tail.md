
The before and after sources contain the same seven new public-loader
characterizations. Footprint accounting instead starts before those test
additions, so their 150 added lines remain visible separately. The ordinary
compiled parser adds one private source to the existing geometry library;
header-edit fan-out includes that new consumer. No module surface is added.

The pre-edit pilot and failed first extraction build are retained separately
from the six matched samples. The first build caught duplicate record insertion;
it was corrected before review or candidate timing. Claude then suggested only
moving the CMake entry beside the other IO source; final verification and timing
use that ordered entry. The source bundle preserves original, characterized,
failed, reviewed and final candidate commits, requiring existing history at
`563be93dba09b7b2a37062731aeafa252480e98e`.

The original and extracted loaders each pass all 224 GeometryIO cases; the
expanded locality selection passes 319. Full ASan passes all 3,237 selected
entries. Full ci (4,886 selected) and UBSan (3,237 selected) fail only on the
independently baseline-reproduced [BUG-206](../../backlog/bugs/BUG-206-uv-duplicate-submit-phase-race.md),
with the expected GLFW lifetime skip in those two runs. That check passes under
ASan. Neither failing run reports a sanitizer diagnostic. No unrelated fix or
weakened assertion is included. The independent review and compile measurements
do not imply that the unresolved repository gate is green.
