#!/usr/bin/env bash
set -euo pipefail
run() {
  local stage="$1"; shift
  local rc=0
  "$@" > "/tmp/intrinsic-four-reuse/geoio004-$stage.log" 2>&1 || rc=$?
  printf '%s\n' "$rc" > "/tmp/intrinsic-four-reuse/geoio004-$stage.exit"
  printf '%s: %s\n' "$stage" "$rc"
  tail -5 "/tmp/intrinsic-four-reuse/geoio004-$stage.log"
  return "$rc"
}
run asan-configure cmake --preset ci-asan --fresh -DINTRINSIC_GROUP_PURE_CTEST=ON
run asan-build cmake --build --preset ci-asan --target IntrinsicCpuTests --parallel 4
run asan-tests ctest --test-dir build/ci-asan --output-on-failure -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60 --parallel 1
run ubsan-configure cmake --preset ci-ubsan --fresh -DINTRINSIC_GROUP_PURE_CTEST=ON
run ubsan-build cmake --build --preset ci-ubsan --target IntrinsicCpuTests --parallel 4
run ubsan-tests ctest --test-dir build/ci-ubsan --output-on-failure -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60 --parallel 1
