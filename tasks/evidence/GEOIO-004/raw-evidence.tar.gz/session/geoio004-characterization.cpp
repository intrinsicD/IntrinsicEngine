
TEST(GeometryIO_PlyHeader, SharedLexicalRulesAndScalarAliasesReachBothLoaders)
{
    for (const std::string scalar : {"char", "int8", "uchar", "uint8", "short", "int16",
                                    "ushort", "uint16", "int", "int32", "uint", "uint32",
                                    "float", "float32", "double", "float64"})
    {
        SCOPED_TRACE(scalar);
        TempFile file(".ply",
            " \tply\r\nformat binary_big_endian 1.0\r\nformat ascii 1.0\r\n"
            "comment retained lexical behavior\r\nobj_info anything\r\n"
            "future_directive ignored tokens\r\n\r\n"
            "element vertex 3 extra\r\nproperty " + scalar + " x extra\r\n"
            "property float32 y\r\nproperty float64 z\r\n"
            "element face 1 extra\r\nproperty list uint8 int32 vertex_indices extra\r\n"
            "end_header\r\n0 0 0\r\n1 0 0\r\n0 1 0\r\n3 0 1 2\r\n");
        const auto mesh = Geometry::MeshIO::LoadPLY(file.Path);
        ASSERT_TRUE(mesh.has_value());
        ExpectTriangleMeshProperties(*mesh);
        const auto cloud = Geometry::PointCloudIO::LoadPLY(file.Path);
        ASSERT_TRUE(cloud.has_value());
        ASSERT_EQ(cloud->Cloud.VerticesSize(), 3u);
        EXPECT_EQ(cloud->Cloud.Position(Geometry::VertexHandle{1}), glm::vec3(1, 0, 0));
        EXPECT_EQ(cloud->Cloud.Position(Geometry::VertexHandle{2}), glm::vec3(0, 1, 0));
    }
}

TEST(GeometryIO_PlyHeader, AsciiFloatingListCountSpellingKeepsLoaderSpecificAcceptance)
{
    TempFile file(".ply",
        "ply\nformat ascii 1.0\nelement vertex 3\n"
        "property float x\nproperty float y\nproperty float z\n"
        "element face 1\nproperty list float int vertex_indices\n"
        "end_header\n0 0 0\n1 0 0\n0 1 0\n3 0 1 2\n");
    const auto mesh = Geometry::MeshIO::LoadPLY(file.Path);
    ASSERT_FALSE(mesh.has_value());
    EXPECT_EQ(mesh.error(), Extrinsic::Core::ErrorCode::InvalidFormat);
    const auto cloud = Geometry::PointCloudIO::LoadPLY(file.Path);
    ASSERT_TRUE(cloud.has_value());
    ASSERT_EQ(cloud->Cloud.VerticesSize(), 3u);
    EXPECT_EQ(cloud->Cloud.Position(Geometry::VertexHandle{2}), glm::vec3(0, 1, 0));
}

TEST(GeometryIO_PlyHeader, MalformedAndTruncatedHeadersKeepBothPublicErrors)
{
    const std::string validTail =
        "element vertex 3\nproperty float x\nproperty float y\nproperty float z\n"
        "element face 1\nproperty list uchar int vertex_indices\n"
        "end_header\n0 0 0\n1 0 0\n0 1 0\n3 0 1 2\n";
    for (const std::string prefix : {
        "ply\nformat ascii 1.0 extra\n",
        "ply\nformat ascii 2.0\n",
        "ply\nformat unsupported 1.0\n",
        "ply\nformat ascii 1.0\nformat ascii 2.0\n",
        "ply\nformat ascii 1.0\nelement vertex\n",
        "ply\nformat ascii 1.0\nelement vertex -1\n",
        "ply\nformat ascii 1.0\nproperty float x\n",
        "ply\nformat ascii 1.0\nelement metadata 0\nproperty float\n",
        "ply\nformat ascii 1.0\nelement metadata 0\nproperty unknown x\n",
        "ply\nformat ascii 1.0\nelement metadata 0\nproperty list uchar int\n",
        "ply\n"})
    {
        SCOPED_TRACE(prefix);
        TempFile file(".ply", prefix + validTail);
        const auto mesh = Geometry::MeshIO::LoadPLY(file.Path);
        ASSERT_FALSE(mesh.has_value());
        EXPECT_EQ(mesh.error(), Extrinsic::Core::ErrorCode::InvalidFormat);
        const auto cloud = Geometry::PointCloudIO::LoadPLY(file.Path);
        ASSERT_FALSE(cloud.has_value());
        EXPECT_EQ(cloud.error(), Extrinsic::Core::ErrorCode::InvalidFormat);
    }
}

TEST(GeometryIO_PlyHeader, NonIntegralListCountAndTruncatedHeaderRemainInvalid)
{
    TempFile file(".ply",
        "ply\nformat ascii 1.0\nelement vertex 3\n"
        "property float x\nproperty float y\nproperty float z\n"
        "element face 1\nproperty list float int vertex_indices\n");
    const auto mesh = Geometry::MeshIO::LoadPLY(file.Path);
    ASSERT_FALSE(mesh.has_value());
    EXPECT_EQ(mesh.error(), Extrinsic::Core::ErrorCode::InvalidFormat);
    const auto cloud = Geometry::PointCloudIO::LoadPLY(file.Path);
    ASSERT_FALSE(cloud.has_value());
    EXPECT_EQ(cloud.error(), Extrinsic::Core::ErrorCode::InvalidFormat);
}

TEST(GeometryIO_PlyHeader, RepeatedPropertiesKeepAsciiFirstOccurrence)
{
    TempFile file(".ply",
        "ply\nformat ascii 1.0\nelement vertex 3\n"
        "property float x\nproperty float y\nproperty float z\nproperty float x\n"
        "element face 1\nproperty list uchar int vertex_indices\n"
        "end_header\n0 0 0 99\n1 0 0 99\n0 1 0 99\n3 0 1 2\n");
    const auto mesh = Geometry::MeshIO::LoadPLY(file.Path);
    ASSERT_TRUE(mesh.has_value());
    ExpectTriangleMeshProperties(*mesh);
    EXPECT_EQ(mesh->Vertices.Get<glm::vec3>("v:point")[1], glm::vec3(1, 0, 0));
    const auto cloud = Geometry::PointCloudIO::LoadPLY(file.Path);
    ASSERT_TRUE(cloud.has_value());
    EXPECT_EQ(cloud->Cloud.Position(Geometry::VertexHandle{1}), glm::vec3(1, 0, 0));
}

TEST(GeometryIO_PlyHeader, RepeatedVertexElementsKeepLoaderSpecificCountSelection)
{
    TempFile file(".ply",
        "ply\nformat ascii 1.0\nelement vertex 3\n"
        "property float x\nproperty float y\nproperty float z\n"
        "element face 1\nproperty list uchar int vertex_indices\n"
        "element vertex 0\nproperty float x\nproperty float y\nproperty float z\n"
        "end_header\n0 0 0\n1 0 0\n0 1 0\n3 0 1 2\n");
    const auto mesh = Geometry::MeshIO::LoadPLY(file.Path);
    ASSERT_FALSE(mesh.has_value());
    EXPECT_EQ(mesh.error(), Extrinsic::Core::ErrorCode::InvalidFormat);
    const auto cloud = Geometry::PointCloudIO::LoadPLY(file.Path);
    ASSERT_TRUE(cloud.has_value());
    EXPECT_EQ(cloud->Cloud.VerticesSize(), 3u);
}

TEST(GeometryIO_PlyHeader, BinaryCrlfHeaderKeepsExactBodyOffsetInBothEndians)
{
    for (const auto endian : {BinaryPlyEndian::Little, BinaryPlyEndian::Big})
    {
        SCOPED_TRACE(endian == BinaryPlyEndian::Little ? "little" : "big");
        std::string contents = MakeBinaryPLYPointCloudTriangle(endian,
            "comment byte offset\nobj_info header only\nunknown_directive ignored\n"
            "element face 1\nproperty list uchar int vertex_indices\n");
        const auto offset = contents.find("end_header\n") + std::strlen("end_header\n");
        std::string crlf;
        for (const char c : contents.substr(0, offset))
        {
            if (c == '\n') crlf += '\r';
            crlf += c;
        }
        crlf += contents.substr(offset);
        crlf.push_back(static_cast<char>(3));
        for (std::uint32_t index : {0u, 1u, 2u})
            AppendEncodedBytes(crlf, EncodeUint32(index, endian));
        TempFile file(".ply", std::move(crlf));
        const auto mesh = Geometry::MeshIO::LoadPLY(file.Path);
        ASSERT_TRUE(mesh.has_value());
        ExpectTriangleMeshProperties(*mesh);
        EXPECT_EQ(mesh->Vertices.Get<glm::vec3>("v:point")[1], glm::vec3(1, 0, 0));
        const auto cloud = Geometry::PointCloudIO::LoadPLY(file.Path);
        ASSERT_TRUE(cloud.has_value());
        ASSERT_EQ(cloud->Cloud.VerticesSize(), 3u);
        EXPECT_EQ(cloud->Cloud.Position(Geometry::VertexHandle{1}), glm::vec3(1, 0, 0));
        EXPECT_EQ(cloud->Cloud.Position(Geometry::VertexHandle{2}), glm::vec3(0, 1, 0));
    }
}
