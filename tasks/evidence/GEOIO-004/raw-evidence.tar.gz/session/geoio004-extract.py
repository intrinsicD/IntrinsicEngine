from pathlib import Path
root=Path('src/geometry')
cloud=root/'Geometry.PointCloud.IO.cpp';original=cloud.read_text()
load=original.index('    Extrinsic::Core::Expected<PointCloudIOResult> LoadPLY(')
a=original.index('        std::size_t cursor = 0;',load);b=original.index('        if (format == PlyFormat::Ascii)',a)
body=original[a:b].replace('return InvalidPointCloudFormat();','return std::nullopt;')
body+='        return PlyHeader{format, std::move(elements), cursor};\n'
Path('src/geometry/Geometry.IOText.cpp').write_text('#include "Geometry.IOText.hpp"\n\n#include <utility>\n\nnamespace Geometry::IOText\n{\n    std::optional<PlyHeader> ParsePlyHeader(std::string_view text)\n    {\n'+body.replace('*text','text')+'    }\n}\n')
start=original.index('        [[nodiscard]] constexpr bool IsPlyIntegralScalar(');end=original.index('\n        }',start)+len('\n        }');scalar=original[start:end]
for name,typ,invalid,ascii,binary in [('Geometry.HalfedgeMesh.IO.cpp','MeshIOResult','InvalidMeshFormat','ParseAsciiPLY','ParseBinaryPLY'),('Geometry.PointCloud.IO.cpp','PointCloudIOResult','InvalidPointCloudFormat','ParseAsciiPLYPointCloud','ParseBinaryPLYPointCloud')]:
 p=root/name;s=p.read_text();load=s.index(f'    Extrinsic::Core::Expected<{typ}> LoadPLY(');a=s.index('        std::size_t cursor = 0;',load);b=s.index('\n    }',a)
 text='''        const auto header = IOText::ParsePlyHeader(*text);
        if (!header)
        {
            return INVALID();
        }

'''.replace('INVALID',invalid)
 if typ=='MeshIOResult':text+='''        for (const auto& element : header->Elements)
        {
            for (const auto& property : element.Properties)
            {
                if (property.IsList && !IsPlyIntegralScalar(property.ListCountType))
                {
                    return InvalidMeshFormat();
                }
            }
        }

'''
 text+='''        if (header->Format == PlyFormat::Ascii)
        {
            return ASCII(*text, header->BodyOffset, header->Elements, absolute_path);
        }

        const std::span<const std::byte> body(
            reinterpret_cast<const std::byte*>(text->data() + header->BodyOffset),
            text->size() - header->BodyOffset);
        return BINARY(body, header->Elements,
                         header->Format == PlyFormat::BinaryBigEndian, absolute_path);'''.replace('ASCII',ascii).replace('BINARY',binary)
 s=s[:a]+text+s[b:]
 start=s.index('        [[nodiscard]] '+('constexpr ' if typ=='PointCloudIOResult' else '')+'bool IsPlyIntegralScalar(');end=s.index('\n        }',start)+len('\n        }\n\n');s=s[:start]+s[end:]
 s=s.replace('        using Geometry::IOText::IsPlyFloatingScalar;','        using Geometry::IOText::IsPlyFloatingScalar;\n        using Geometry::IOText::IsPlyIntegralScalar;')
 if s.count('ParsePlyScalarType')==1:s=s.replace('        using Geometry::IOText::ParsePlyScalarType;\n','')
 p.write_text(s)
p=root/'Geometry.IOText.hpp';s=p.read_text().replace('// Shared path, text parsing and PLY scalar decoding for geometry IO implementations.','// Shared paths, lexical parsing, PLY headers and scalar decoding for geometry IO.')
s=s.replace('    [[nodiscard]] constexpr std::size_t PlyScalarBytes', '\n'.join(line[4:] for line in scalar.splitlines())+'\n\n    [[nodiscard]] constexpr std::size_t PlyScalarBytes')
s=s.replace('    inline void ByteSwap(std::byte* p, std::size_t n)\n    {','''    struct PlyHeader
    {
        PlyFormat Format = PlyFormat::Ascii;
        std::vector<PlyElement> Elements;
        std::size_t BodyOffset = 0;
    };

    [[nodiscard]] std::optional<PlyHeader> ParsePlyHeader(std::string_view text);

    inline void ByteSwap(std::byte* p, std::size_t n)
    {''')
p.write_text(s)
p=root/'CMakeLists.txt';s=p.read_text().replace('        Geometry.HalfedgeMesh.IO.cpp\n','        Geometry.HalfedgeMesh.IO.cpp\n        Geometry.IOText.cpp\n');p.write_text(s)
p=Path('tools/agents/skills/intrinsicengine-reuse/references/owner-routes.md');s=p.read_text().replace('`src/geometry/Geometry.IOText.hpp` | `Geometry.HalfedgeMesh.IO.cpp`','`src/geometry/Geometry.IOText.hpp/.cpp`: `ParsePlyHeader` and lexical/scalar helpers | Mesh retains integral-list-count validation; cloud retains its format-specific body validation. `Geometry.HalfedgeMesh.IO.cpp`');p.write_text(s)
