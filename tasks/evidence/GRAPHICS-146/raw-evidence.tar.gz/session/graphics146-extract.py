from pathlib import Path
import re
for part in ['Surface','LinePoint','Selection']:
 p=Path(f'tests/contract/graphics/Test.{part}PassContracts.cpp');s=p.read_text();a=s.index('    enum class EventKind');b=s.index('    Graphics::GpuWorld::InitDesc TinyWorldDesc()',a)
 s=s[:a]+'    using EventKind = MockCommandContext::EventKind;\n\n'+s[b:]
 s=s.replace('using Tests::MockDevice;','using Tests::MockDevice;\nusing Tests::MockCommandContext;').replace('RecordingCommandContext','MockCommandContext')
 s=re.sub(r'(\.Events\[\d+\])\.Kind',r'\1',s).replace('.LastPipeline','.LastBoundPipeline').replace('.LastVertexCount','.LastDraw.VertexCount')
 s=s.replace('        ASSERT_EQ(cmd.LastPushConstants.size(),','        ASSERT_EQ(cmd.PushConstantPayloads.size(), 1u);\n        ASSERT_EQ(cmd.LastPushConstants.size(),').replace('    ASSERT_EQ(cmd.LastPushConstants.size(), 144u);','    ASSERT_EQ(cmd.PushConstantPayloads.size(), 1u);\n    ASSERT_EQ(cmd.LastPushConstants.size(), 144u);')
 s=s.replace('.LastPushConstants','.PushConstantPayloads.back()')
 def indirect(m):
  var,field=m.groups();indexed=part=='Surface' or (part=='Selection' and var!='pointCmd')
  return var+'.'+('LastDrawIndexedIndirectCount' if indexed else 'LastDrawIndirectCount')+'.'+('ArgumentBuffer' if field=='LastIndirectArgs' else 'CountBuffer')
 s=re.sub(r'(\w+)\.(LastIndirectArgs|LastIndirectCount)',indirect,s)
 if part=='Selection':
  for var,events in [('entityCmd',['BindPipeline','BindIndexBuffer','PushConstants','DrawIndexedIndirectCount']),('faceCmd',['BindPipeline','BindIndexBuffer','PushConstants','DrawIndexedIndirectCount']),('edgeCmd',['BindPipeline','BindIndexBuffer','PushConstants','DrawIndexedIndirectCount']),('pointCmd',['BindPipeline','PushConstants','DrawIndirectCount'])]:
   for i,e in enumerate(events):s=s.replace(f'    EXPECT_EQ({var}.Events[{i}], EventKind::{e});\n','')
   anchor=f'    ASSERT_EQ({var}.Events.size(), {len(events)}u);'
   s=s.replace(anchor,anchor+'\n'+'\n'.join(f'    EXPECT_EQ({var}.Events[{i}], EventKind::{e});' for i,e in enumerate(events)))
 p.write_text(s)
p=Path('tests/support/MockRHI.hpp');s=p.read_text();needle='        struct DrawIndexedRecord'
s=s.replace(needle,'''        struct IndirectCountRecord
        {
            RHI::BufferHandle ArgumentBuffer{};
            std::uint64_t ArgumentOffset = 0;
            RHI::BufferHandle CountBuffer{};
            std::uint64_t CountOffset = 0;
            std::uint32_t MaxDrawCount = 0;
        };

'''+needle).replace('        DrawRecord LastDraw{};','        IndirectCountRecord LastDrawIndexedIndirectCount{};\n        IndirectCountRecord LastDrawIndirectCount{};\n        DrawRecord LastDraw{};');p.write_text(s)
p=Path('tests/support/MockRHI.cpp');s=p.read_text()
for method in ['DrawIndexedIndirectCount','DrawIndirectCount']:
 old=f'''    void MockCommandContext::{method}(RHI::BufferHandle, std::uint64_t, RHI::BufferHandle,
        std::uint64_t, std::uint32_t maxDrawCount)
    {{
        ++{method}Calls;'''
 new=f'''    void MockCommandContext::{method}(RHI::BufferHandle argumentBuffer,
        std::uint64_t argumentOffset, RHI::BufferHandle countBuffer,
        std::uint64_t countOffset, std::uint32_t maxDrawCount)
    {{
        Last{method} = {{argumentBuffer, argumentOffset, countBuffer, countOffset, maxDrawCount}};
        ++{method}Calls;'''
 assert old in s;s=s.replace(old,new)
p.write_text(s)
p=Path('tests/contract/graphics/Test.GraphicsTestSupport.cpp');s=p.read_text().replace('import Extrinsic.Graphics.RenderDiagnostics;','#include "MockRHI.hpp"\n\nimport Extrinsic.Graphics.RenderDiagnostics;');s+='''
TEST(GraphicsTestSupport, IndirectCountRecordingKeepsIndependentArgumentsAndOffsets)
{
    using namespace Extrinsic;
    Tests::MockCommandContext cmd;
    const RHI::BufferHandle arguments{11u, 3u};
    const RHI::BufferHandle count{12u, 4u};
    const RHI::BufferHandle indexedArguments{21u, 5u};
    const RHI::BufferHandle indexedCount{22u, 6u};
    cmd.DrawIndirectCount(arguments, 16u, count, 32u, 7u);
    cmd.DrawIndexedIndirectCount(indexedArguments, 48u, indexedCount, 64u, 9u);

    const auto& plain = cmd.LastDrawIndirectCount;
    EXPECT_EQ(plain.ArgumentBuffer, arguments);
    EXPECT_EQ(plain.ArgumentOffset, 16u);
    EXPECT_EQ(plain.CountBuffer, count);
    EXPECT_EQ(plain.CountOffset, 32u);
    EXPECT_EQ(plain.MaxDrawCount, 7u);
    const auto& indexed = cmd.LastDrawIndexedIndirectCount;
    EXPECT_EQ(indexed.ArgumentBuffer, indexedArguments);
    EXPECT_EQ(indexed.ArgumentOffset, 48u);
    EXPECT_EQ(indexed.CountBuffer, indexedCount);
    EXPECT_EQ(indexed.CountOffset, 64u);
    EXPECT_EQ(indexed.MaxDrawCount, 9u);
    EXPECT_EQ(cmd.DrawIndirectCountCalls, 1);
    EXPECT_EQ(cmd.DrawIndexedIndirectCountCalls, 1);
    EXPECT_EQ(cmd.LastMaxDrawCount, 9u);
    ASSERT_EQ(cmd.Events.size(), 2u);
    EXPECT_EQ(cmd.Events[0], Tests::MockCommandContext::EventKind::DrawIndirectCount);
    EXPECT_EQ(cmd.Events[1], Tests::MockCommandContext::EventKind::DrawIndexedIndirectCount);
}
''';p.write_text(s)
p=Path('tests/support/README.md');s=p.read_text().replace('the recorded-command methods, linked through `MockRhiTestSupportObjs`.','the recorded-command methods, linked through `MockRhiTestSupportObjs`.\nThe command context retains independent last-call arguments and byte offsets\nfor indexed and nonindexed indirect-count draws, alongside the full ordered\nevent stream and submission-ordered push-constant payloads.');p.write_text(s)
