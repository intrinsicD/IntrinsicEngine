
The new field-contract case adds `MockRHI.hpp` to the existing
`Test.GraphicsTestSupport.cpp`, creating one additional declaration consumer.
Its observed rebuild cost remains included in the shared-header probe. The
separate regression-test footprint includes the test's two-line include addition;
the 17 strengthened assertions in migrated callers remain included in the
recorder/caller net change. No production source or CMake entry changes.

The pre-edit pilot is retained separately from the six matched samples. All
compiler invocations, wall timings, dependency fingerprints and canonical result
records remain in the raw archive. The source bundle preserves both exact
commits and requires existing history at
`1fd3b3e72ea4321ff063b1eb555a62d60bd9aec5`. No source changed after independent
review or between measured samples. No Vulkan execution claim is made by the
CPU mock tests.

## Behavioral verification

The original eleven focused graphics cases pass before extraction. The reviewed
candidate passes twelve focused cases, including the new recorder-contract test,
and the expanded graphics/compilation-locality selector passes 107 entries.
Canonical ci configuration and `IntrinsicTests` build pass; the full CPU selector
passes 4,880 selected entries with one expected GLFW lifetime skip (168.72 s).
Fresh grouped ASan configuration, `IntrinsicCpuTests` build and serial full gate
pass all 3,231 entries (657.23 s). Fresh grouped UBSan configuration, matching build
and serial full gate pass 3,231 selected entries with the expected GLFW lifetime
skip (294.23 s). No sanitizer findings occur.

These gates cover exact combined source
`33f6e4427c9ba3dbb050c5d81fe0e5d177ebf46a`: GEOM-099 and RUNTIME-272 retained,
GEOIO-004 restored, and this reviewed graphics candidate. All 23 code/build files
affected by GEOM-099 and RUNTIME-272 are byte-identical to their reviewed source
identities; the raw archive includes that per-file hash check. This is the required
verification for a new graphics diff, not a retry of unchanged source to obtain
a passing result. The previously recorded BUG-206 phase-snapshot race does not
occur in these runs; it remains an open independent bug and is not claimed fixed.
