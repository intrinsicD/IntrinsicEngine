## Execution plan — 2026-09-21

The existing compiled `MockCommandContext` owns command recording. Extend it
with one plain indirect-count record type and separate indexed/nonindexed
last-call records, retaining all counters, LastMaxDrawCount, the complete event
stream and ordered push-constant payloads. Remove the three local recorder
classes in surface, line/point and selection contract tests in the same slice.
No renderer or RHI implementation changes are needed.

The current production Execute bodies confirm the event contracts: indexed
surface and selection entity/face/edge calls bind pipeline, bind index buffer,
push constants and draw indexed indirect-count; line, point and selection point
bind pipeline, push constants and draw indirect-count; outline binds pipeline,
pushes constants and issues a three-vertex draw. Guard exits issue no commands.
Every successful invocation contributes one payload. Preserve all independent
buffer, frame, bucket, offset, no-draw and payload assertions; compare full
unfiltered event lists. Add a focused mock test with distinct buffers and
nonzero offsets for both variants so argument independence is observable.

Freeze the original tests and source before implementation. Use the existing
MockRhiTestSupportObjs ownership and the IntrinsicTests timing target to include
all mock consumers, including runtime. Keep the ci-derived Clang 23 Debug
Null/headless, four-job, disabled-ccache identity, identical dependencies and
three alternating samples per arm. All original compile allowances remain.
Run focused graphics/compilation-locality tests, independent read-only Claude
review, the full CPU and sanitizer gates, and matched compile probes. Update
only test-support documentation and the required evidence/task records.
