#!/usr/bin/env bash
set -euo pipefail
git diff --exit-code 33f6e4427c9ba3dbb050c5d81fe0e5d177ebf46a -- src tests cmake
test "$(cat /tmp/intrinsic-graphics146/build/.compile-measurement-owner)" = /tmp/intrinsic-graphics146/baseline-pilot
mv /tmp/intrinsic-graphics146/build /tmp/intrinsic-graphics146/pilot-build
python3 tools/analysis/benchmark_compile_iteration.py --source /tmp/intrinsic-graphics146/source --build /tmp/intrinsic-graphics146/build --output /tmp/intrinsic-graphics146/results --manifest benchmarks/ci/manifests/graphics146_reuse_compile.yaml > /tmp/intrinsic-graphics146/results.log 2>&1
python3 tools/benchmark/validate_benchmark_results.py --root /tmp/intrinsic-graphics146/results/results --manifests-root benchmarks --strict
cmp /tmp/intrinsic-graphics146/baseline-pilot/01-before-1/dependencies.json /tmp/intrinsic-graphics146/results/01-before-1/dependencies.json
python3 /tmp/intrinsic-four-reuse/summarize.py /tmp/intrinsic-graphics146/results /tmp/intrinsic-four-reuse/graphics146-summary.json
python3 /tmp/intrinsic-four-reuse/report-table.py graphics146 > /tmp/intrinsic-four-reuse/graphics146-measurement-table.md
