Source before: d82d87d765400961b1c2870fbf3d871eafdad2df

Source after: 33f6e4427c9ba3dbb050c5d81fe0e5d177ebf46a

| Probe | Wall median seconds, before → after | Wall delta | Compiler sum median seconds, before → after | Compiler delta | Compiler jobs, before → after |
| --- | --- | --- | --- | --- | --- |
| clean | 626.720 → 625.658 | -0.17% | 2423.576 → 2419.458 | -0.17% | 1151 → 1151 |
| noop | 0.138 → 0.133 | -3.51% | 0.000 → 0.000 | n/a (zero before) | 0 → 0 |
| consumer_impl | 2.607 → 2.544 | -2.42% | 1.735 → 1.685 | -2.88% | 1 → 1 |
| mock_impl | 5.588 → 5.518 | -1.24% | 1.041 → 1.011 | -2.88% | 1 → 1 |
| mock_header | 56.487 → 56.937 | +0.80% | 189.063 → 190.272 | +0.64% | 50 → 51 |

Per-sample values and min/max ranges are in `compile-summary.json`; all original logs, Ninja timings, configure state, dependencies and canonical results are in `raw-evidence.tar.gz`.

Original threshold crossings: none

implementation: 2014 → 1812 physical lines (-202).

regression_tests: 73 → 106 physical lines (+33).

total: 2087 → 1918 physical lines (-169).
