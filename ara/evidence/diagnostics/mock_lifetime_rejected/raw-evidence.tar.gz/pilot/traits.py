import json,shlex,subprocess,sys
from pathlib import Path
root=Path('/home/alex/Documents/IntrinsicEngine');out=Path('/tmp/intrinsic-mock-lifetime-20260921')
src=out/'traits.cpp'
traits=['is_default_constructible','is_nothrow_default_constructible','is_copy_constructible','is_nothrow_copy_constructible','is_move_constructible','is_nothrow_move_constructible','is_copy_assignable','is_nothrow_copy_assignable','is_move_assignable','is_nothrow_move_assignable','is_nothrow_destructible']
types=['MockTransferQueue','MockBindlessHeap','MockCommandContext','MockDevice']
src.write_text('#include <type_traits>\n#include "MockRHI.hpp"\n'+'\n'.join('extern const bool '+t+'[] = {'+','.join('std::'+v+'_v<Extrinsic::Tests::'+t+'>' for v in traits)+'};' for t in types))
c=next(x for x in json.load(open(root/'build/ci/compile_commands.json')) if x['file'].endswith('Test.SandboxEditorMeshMethods.cpp'))
a=shlex.split(c['command']);a[a.index('-o')+1]=str(out/(sys.argv[1]+'.ll'));a[-1]=str(src);a+=['-S','-emit-llvm'];subprocess.run(a,cwd=c['directory'],check=True)
print('\n'.join(x for x in (out/(sys.argv[1]+'.ll')).read_text().splitlines() if x.startswith('@') and 'constant [' in x and 'Mock' in x))
