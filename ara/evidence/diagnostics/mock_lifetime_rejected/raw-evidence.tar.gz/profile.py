import json,shlex,subprocess,sys,time
from pathlib import Path
root=Path('/home/alex/Documents/IntrinsicEngine')
out=Path('/tmp/intrinsic-compile-graph')/sys.argv[1];out.mkdir(exist_ok=True)
commands=json.load(open(root/'build/ci/compile_commands.json'))
names=['Test.SandboxEditorModels.cpp','Test.SandboxEditorVisualization.cpp','Test.SandboxEditorMeshMethods.cpp','Test.SandboxEditorClusteringMethods.cpp','EditorFeatureTestContext.cpp']
if len(sys.argv)>2: names=sys.argv[2:]
results=[]
for name in names:
 c=next(c for c in commands if Path(c['file']).name==name)
 args=shlex.split(c['command']);args[args.index('-o')+1]=str(out/(name+'.o'))
 args+=['-ftime-trace='+str(out/(name+'.json'))]
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:
  r=subprocess.run(args,cwd=c['directory'],stdout=log,stderr=subprocess.STDOUT)
 elapsed=time.monotonic()-start
 results.append({'file':name,'elapsed':elapsed,'returncode':r.returncode})
 print(results[-1],flush=True)
 (out/'timings.json').write_text(json.dumps(results,indent=2))
 if r.returncode:sys.exit(r.returncode)
