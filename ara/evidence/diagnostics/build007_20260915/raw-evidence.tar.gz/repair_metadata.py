from pathlib import Path
import copy,json
root=Path('/tmp/intrinsic-build007-measure/cohort-20260915-r2')
out=root/'results-repaired';out.mkdir(exist_ok=True)
for p in sorted((root/'results').glob('*.json')):
 d=json.loads(p.read_text());destination=out/p.name
 if destination.exists():continue
 assert d['backend']=='clang23_ninja_cpu'
 repaired=copy.deepcopy(d);repaired['backend']='external_baseline'
 repaired['attempt_id']=d['attempt_id']+'-metadata01'
 repaired['diagnostics']['original_attempt_id']=d['attempt_id']
 repaired['diagnostics']['toolchain_backend']=d['backend']
 repaired['supersedes']=[{k:d[k] for k in ['benchmark_id','run_id','attempt_id']}]
 repaired['notes']=['Metadata-only correction: use the canonical external_baseline category for external compiler/build timing, following tools/ci/aggregate_gate_timing.py. No new execution or metric/source/manifest change. Original result retained.']
 assert repaired['metrics']==d['metrics'] and repaired['source']==d['source']
 destination.write_text(json.dumps(repaired,indent=2)+'\n')
 print('Repaired metadata:',p.name)
