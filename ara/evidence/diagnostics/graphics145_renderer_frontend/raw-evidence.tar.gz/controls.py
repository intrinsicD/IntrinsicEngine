from pathlib import Path
import re,json,subprocess,hashlib,time,sys
P=Path('/tmp/intrinsic-graphics145');R=Path('/home/alex/Documents/IntrinsicEngine');B=Path('/dev/shm/intrinsic-graphics145');s=(R/'src/graphics/renderer/Graphics.Renderer.cpp').read_text();label=sys.argv[1]
if label=='sorts-only':
 for name in ['items','packets']:
  old=f'std::ranges::sort({name},';assert s.count(old)==1;s=s.replace(old,f'std::sort({name}.begin(), {name}.end(),')
elif label=='span-fields':
 names=['m_VisualizationPropertyBuffers','m_VisualizationAttributeBuffers','m_VisualizationScalars','m_VisualizationColors','m_VisualizationVectorFields','m_VisualizationIsolines','m_VisualizationHtexAtlases','m_VisualizationFragmentBakeAtlases','m_RenderableSnapshots','m_LightSnapshots','m_SelectionSelectedStableIds','m_DebugLinePackets','m_DebugPointPackets','m_DebugTrianglePackets','m_TransformGizmoPackets','textureBarriers','bufferBarriers','memoryBarriers','rhiQueueWaits[batchIndex]','rhiQueueSignals[batchIndex]','rhiSubmitBatches','parallelContextRequests','activeRenderPass.ColorAttachments']
 for name in names:
  pattern=r'(\.\w+\s*=\s*)'+re.escape(name)+r'(?=[,}])';s,n=re.subn(pattern,lambda m:m[1]+'{'+name+'.data(), '+name+'.size()}',s);assert n>0,name;print(name,n)
 p=r'(std::span<[^>]+>\{)\s*(activeSnapshot->\w+)\}'
 s,n=re.subn(p,lambda m:m[1]+m[2]+'.data(), '+m[2]+'.size()}',s);assert n==5,n
else:raise ValueError(label)
source=P/(label+'.cpp');source.write_text(s);prior=json.loads((P/'before-renderer-impl.summary.json').read_text());args=prior['command'];args[args.index('-c')+1]=str(source);args[args.index('-o')+1]=str(B/(label+'.o'));args=[a for a in args if not a.startswith('-ftime-trace=')];args+=['-ftime-trace='+str(P/(label+'.trace.json'))]
start=time.perf_counter()
with (P/(label+'.log')).open('w') as f:r=subprocess.run(['/usr/bin/time','-v','-o',str(P/(label+'.time.txt'))]+args,cwd=prior['cwd'],stdout=f,stderr=subprocess.STDOUT)
d={'label':label,'scope':'single isolated diagnostic, not benchmark cohort','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'command':args,'returncode':r.returncode,'wall_s':time.perf_counter()-start}
if r.returncode==0:
 trace=json.loads((P/(label+'.trace.json')).read_text());d['totals_s']={x['name']:x['dur']/1e6 for x in trace['traceEvents'] if x['name'].startswith('Total ') and 'dur' in x}
(P/(label+'.summary.json')).write_text(json.dumps(d,indent=2)+'\n');print(label,r.returncode,round(d['wall_s'],3),d.get('totals_s',{}).get('Total CheckConstraintSatisfaction'));raise SystemExit(r.returncode)
