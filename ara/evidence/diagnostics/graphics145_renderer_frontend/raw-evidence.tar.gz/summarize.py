from pathlib import Path
import collections,hashlib,json,statistics,sys,yaml
R=Path('/home/alex/Documents/IntrinsicEngine');P=Path('/tmp/intrinsic-graphics145');O=P/'measurement'
sys.path[:0]=[str(R/'tools/benchmark')]
from validate_benchmark_results import validate_result_data
mp=R/'benchmarks/ci/manifests/renderer_frontend.yaml';m=yaml.safe_load(mp.read_text());frozen=json.loads((P/'freeze.json').read_text());protocol=json.loads((O/'protocol.json').read_text())
assert hashlib.sha256(mp.read_bytes()).hexdigest()==frozen['manifest_sha256']==protocol['manifest_sha256']
assert hashlib.sha256((P/'benchmark.py').read_bytes()).hexdigest()==frozen['runner_sha256']==protocol['runner_sha256']
files=sorted((O/'results').glob('*.json'));assert len(files)==10
rows=[]
for i,f in enumerate(files):
 d=json.loads(f.read_text());_,errors=validate_result_data(d,f,{m['benchmark_id']:(mp,m)},R/'benchmarks');assert not errors,errors
 diag=d['diagnostics'];arm=m['params']['sample_order'][i];assert diag['arm']==arm and diag['position']==i+1
 assert d['source']['revision']==m['params']['source_revisions'][arm] and d['source']['state']=='clean_commit' and not d['claim_eligible'] and d['status']=='passed'
 assert diag['source_clean_before_after'] and diag['dependencies_and_commands_unchanged'] and diag['frozen_bmi_count']==len(protocol['frozen_bmis'])
 assert diag['scenarios']['implementation_edit']['compiler_invocations']==1 and diag['scenarios']['noop']['compiler_invocations']==0
 for s,v in diag['scenarios'].items():
  assert v['execution']['exit_code']==0 and d['metrics']['build_time_ms'][s]==v['execution']['wall_ms']
  assert v['execution']['started_at']>frozen['frozen_at']
 rows.append({'attempt':d['attempt_id'],'arm':arm,'source_sha256':diag['source_sha256'],'build_time_ms':d['metrics']['build_time_ms'],'memory_peak_bytes':d['metrics']['memory_peak_bytes'],'critical_path_ms':{s:v['critical_path']['duration_ms'] for s,v in diag['scenarios'].items()}})
assert collections.Counter(x['arm'] for x in rows)=={'before':5,'after':5}
summary={'benchmark_id':m['benchmark_id'],'source_revisions':m['params']['source_revisions'],'freeze':frozen,'samples':rows,'frozen_bmi_count':len(protocol['frozen_bmis']),'compile_commands_count':len(json.loads((O/'compile_commands.json').read_text())),'cpu_model':protocol['cpu_model'],'compiler':protocol['compiler'],'arms':{}}
for arm in ('before','after'):
 subset=[x for x in rows if x['arm']==arm];assert len({x['source_sha256'] for x in subset})==1
 summary['arms'][arm]={}
 for metric in ('build_time_ms','memory_peak_bytes','critical_path_ms'):
  summary['arms'][arm][metric]={}
  for s in subset[0][metric]:
   vals=[x[metric][s] for x in subset];summary['arms'][arm][metric][s]={'median':statistics.median(vals),'min':min(vals),'max':max(vals),'samples':vals}
summary['median_reduction_percent']={s:100*(1-summary['arms']['after']['build_time_ms'][s]['median']/summary['arms']['before']['build_time_ms'][s]['median']) for s in rows[0]['build_time_ms']}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k in ['arms','median_reduction_percent','frozen_bmi_count','compile_commands_count']},indent=2))
