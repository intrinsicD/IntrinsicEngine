from pathlib import Path
from datetime import datetime,UTC
import collections,hashlib,json,os,shlex,shutil,subprocess,sys,time,yaml
R=Path('/home/alex/Documents/IntrinsicEngine');P=Path('/tmp/intrinsic-graphics145');BASE=Path('/dev/shm/intrinsic-graphics145');SOURCE=BASE/'source';BUILD=BASE/'build';OUT=P/'measurement';MANIFEST=R/'benchmarks/ci/manifests/renderer_frontend.yaml';REL='src/graphics/renderer/Graphics.Renderer.cpp'
sys.path[:0]=[str(R/'tools/analysis'),str(R/'tools/benchmark')]
import compile_hotspots as hotspots
from benchmark_compile_iteration import command,dependency_snapshot,log_window,critical_path,write_json
from seal_benchmark_results import canonicalize
from validate_benchmark_results import validate_result_data
m=yaml.safe_load(MANIFEST.read_text());params=m['params'];refs=params['source_revisions'];order=params['sample_order']
assert collections.Counter(order)=={'before':5,'after':5}
assert not MANIFEST.is_relative_to(SOURCE) and not OUT.exists() and not BUILD.exists()
assert (SOURCE/'.git').is_file() and not command(['git','status','--porcelain'],SOURCE)
changed=command(['git','diff','--name-only',refs['before'],refs['after'],'--','src','cmake','CMakeLists.txt','CMakePresets.json','vcpkg.json','vcpkg-configuration.json'],SOURCE).splitlines();assert changed==[REL],changed
OUT.mkdir(parents=True);BUILD.mkdir();(BUILD/'.graphics145-owner').write_text(str(OUT));env=dict(os.environ,CCACHE_DISABLE='1',VCPKG_FORCE_SYSTEM_BINARIES='1')
def checkout(rev):
 assert not command(['git','status','--porcelain'],SOURCE)
 subprocess.run(['git','checkout','--detach',rev],cwd=SOURCE,check=True,capture_output=True)
 assert command(['git','rev-parse','HEAD'],SOURCE).strip()==rev
assert shutil.disk_usage(BASE).free > 8 * 1024**3, 'Need 8 GiB tmpfs headroom for setup'
checkout(refs['before']);packages=dependency_snapshot(SOURCE/'external/vcpkg-installed/ci')
configure=['cmake','--preset','ci','-B',str(BUILD),*params['configure_options'],'-DVCPKG_MANIFEST_INSTALL=OFF'];build=['cmake','--build',str(BUILD),'--target','ExtrinsicGraphics','--parallel','4']
for label,args in [('configure',configure),('settle',build)]:
 with (OUT/(label+'.log')).open('w') as f:r=subprocess.run(args,cwd=SOURCE,env=env,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,label
assert dependency_snapshot(SOURCE/'external/vcpkg-installed/ci')==packages
commands=json.loads((BUILD/'compile_commands.json').read_text());assert all('ccache' not in x['command'] for x in commands);assert all(params['compiler'] in x['command'] for x in commands if x['file'].endswith(('.cpp','.cppm')))
shutil.copyfile(BUILD/'compile_commands.json',OUT/'compile_commands.json');shutil.copyfile(BUILD/'CMakeCache.txt',OUT/'CMakeCache.txt')
row=next(x for x in commands if x['file']==str(SOURCE/REL))
rsps=[a[1:] for a in shlex.split(row['command']) if a.startswith('@')]
assert len(rsps)==1, 'Expected exactly one renderer module response file'
response=BUILD/rsps[0];response_bytes=response.read_bytes();(OUT/'renderer.modmap').write_bytes(response_bytes)
assert f'CMAKE_HOME_DIRECTORY:INTERNAL={SOURCE}' in (BUILD/'CMakeCache.txt').read_text()
assert f'CMAKE_CACHEFILE_DIR:INTERNAL={BUILD}' in (BUILD/'CMakeCache.txt').read_text()
fixed={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(BUILD.rglob('*.pcm'))};assert len(fixed)>100
protocol={'manifest':m,'manifest_sha256':hashlib.sha256(MANIFEST.read_bytes()).hexdigest(),'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source':str(SOURCE),'build':str(BUILD),'packages':packages,'setup_commands':[configure,build],'common_compile_commands_sha256':hashlib.sha256((BUILD/'compile_commands.json').read_bytes()).hexdigest(),'frozen_bmis':fixed,'compiler':command([params['compiler'],'--version'],SOURCE),'cpu_model':next(x.split(':',1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name'))}
write_json(OUT/'protocol.json',protocol);resolver=hotspots.SourceResolver(SOURCE,BUILD)
def verify(rev):
 assert not command(['git','status','--porcelain'],SOURCE) and command(['git','rev-parse','HEAD'],SOURCE).strip()==rev
 assert json.loads((BUILD/'compile_commands.json').read_text())==commands
 assert response.read_bytes()==response_bytes
 assert {str(p) for p in BUILD.rglob('*.pcm')}==set(fixed)
 for n,d in fixed.items():assert hashlib.sha256(Path(n).read_bytes()).hexdigest()==d,n
 assert dependency_snapshot(SOURCE/'external/vcpkg-installed/ci')==packages
counts=collections.Counter()
for pos,arm in enumerate(order,1):
 rev=refs[arm];checkout(rev);counts[arm]+=1;attempt=f'{pos:02d}-{arm}-{counts[arm]}';dest=OUT/attempt;dest.mkdir();print('START',attempt,flush=True);verify(rev)
 data=(SOURCE/REL).read_bytes();assert data==subprocess.check_output(['git','show',rev+':'+REL],cwd=SOURCE)
 timings={};rss={};details={}
 for scenario in ['implementation_edit','noop']:
  subprocess.run(['ninja','-C',str(BUILD),'-t','recompact'],check=True,stdout=subprocess.DEVNULL)
  if scenario=='implementation_edit':os.utime(SOURCE/REL,None)
  before=(BUILD/'.ninja_log').read_bytes();stamp=datetime.now(UTC).isoformat();load=os.getloadavg();start=time.perf_counter()
  with (dest/(scenario+'.log')).open('w') as f:r=subprocess.run(['/usr/bin/time','-q','-f','{"user_s":%U,"system_s":%S,"max_single_process_rss_kib":%M}','-o',str(dest/(scenario+'.time.json')),'--',*build],cwd=SOURCE,env=env,stdout=f,stderr=subprocess.STDOUT)
  wall=(time.perf_counter()-start)*1000;record=json.loads((dest/(scenario+'.time.json')).read_text().splitlines()[-1]);record.update(wall_ms=wall,started_at=stamp,loadavg_before=load,exit_code=r.returncode,command=build);write_json(dest/(scenario+'.execution.json'),record);assert r.returncode==0
  log=log_window(before,(BUILD/'.ninja_log').read_bytes());assert log.startswith(b'# ninja log v');logpath=dest/(scenario+'.ninja_log');logpath.write_bytes(log)
  rows=[hotspots.build_report_row(SOURCE,resolver,e) for e in hotspots.parse_ninja_log(logpath,BUILD)]
  expected=[REL] if scenario=='implementation_edit' else [];assert sorted(x['source'] for x in rows)==expected,rows
  outputs=[line.split('\t')[3] for line in log.decode().splitlines()[1:]]
  if scenario=='implementation_edit':assert {x for x in outputs if x.endswith('.a')}=={'lib/libExtrinsicGraphics.a'},outputs
  else:assert not any(x.endswith(('.o','.a','.pcm')) for x in outputs),outputs
  graph=command(['ninja','-C',str(BUILD),'-t','graph','ExtrinsicGraphics'],SOURCE);(dest/(scenario+'.dot')).write_text(graph);crit=critical_path(graph,log);assert crit['duration_ms']<=wall+100
  write_json(dest/(scenario+'.hotspots.json'),rows);details[scenario]={'execution':record,'compiler_invocations':len(rows),'sources':expected,'critical_path':crit,'producer_rows':rows};timings[scenario]=wall;rss[scenario]=record['max_single_process_rss_kib']*1024
  if scenario=='implementation_edit':timings['renderer_compiler']=rows[0]['duration_ms']
  verify(rev);print(' PASS',scenario,round(wall/1000,3),flush=True)
 raw={'benchmark_id':m['benchmark_id'],'method':m['method'],'dataset':m['dataset'],'backend':'external_baseline','commit':rev,'status':'passed','metrics':{'build_time_ms':timings,'memory_peak_bytes':rss,'sample_count':1},'diagnostics':{'arm':arm,'position':pos,'sample':counts[arm],'scenarios':details,'source_clean_before_after':True,'source_sha256':hashlib.sha256(data).hexdigest(),'frozen_bmi_count':len(fixed),'dependencies_and_commands_unchanged':True}}
 write_json(dest/'raw-result.json',raw);sealed=canonicalize(raw,manifest_path=MANIFEST,manifest=m,manifests_root=R/'benchmarks',run_id='graphics145-settled-rebuild',attempt_id=attempt,source_state='clean_commit',source_revision=rev,claim_eligible=False,snapshot_sha256=None,diff_sha256=None);resultdir=OUT/'results';resultdir.mkdir(exist_ok=True);f=resultdir/(attempt+'.json');_,errors=validate_result_data(sealed,f,{m['benchmark_id']:(MANIFEST,m)},R/'benchmarks');assert not errors,errors;write_json(f,sealed);print('COMPLETE',attempt,flush=True)
assert counts=={'before':5,'after':5}
