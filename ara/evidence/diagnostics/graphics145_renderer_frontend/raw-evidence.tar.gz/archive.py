from pathlib import Path
import hashlib,json,tarfile
P=Path('/tmp/intrinsic-graphics145');D=Path('/home/alex/Documents/IntrinsicEngine/ara/evidence/diagnostics/graphics145_renderer_frontend')
files=[p for p in P.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']
# Scratch contains scripts, logs and evidence only; compiled binaries live in owned tmpfs.
assert not any(p.suffix in ['.o','.pcm'] for p in files)
a=D/'raw-evidence.tar.gz'
with tarfile.open(a,'w:gz',compresslevel=6) as tar:
 for f in sorted(files):tar.add(f,arcname=str(f.relative_to(P)),recursive=False)
with tarfile.open(a) as tar:
 assert len(tar.getnames())==len(files)
 for f in files:
  raw=tar.extractfile(str(f.relative_to(P))).read();assert hashlib.sha256(raw).digest()==hashlib.sha256(f.read_bytes()).digest()
 assert len([n for n in tar.getnames() if n.startswith('measurement/results/') and n.endswith('.json')])==10
ident=json.loads((P/'source-identity.json').read_text());freeze=json.loads((P/'freeze.json').read_text())
index={'baseline_revision':ident['before_revision'],'source_revision':freeze['source_revisions']['after'],'archive_members':len(files),'canonical_results':10,'binary_artifacts_in_archive':False,'archive_byte_verified':True,'recalculation_script':'raw-evidence.tar.gz:summarize.py','protocol_runner':'raw-evidence.tar.gz:benchmark.py','files':{p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(D.iterdir()) if p.is_file() and p.name!='evidence-index.json'}}
(D/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({'members':len(files),'archive_bytes':a.stat().st_size,'canonical_results':10},indent=2))
