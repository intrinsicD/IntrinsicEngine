from pathlib import Path
import json,sys
from unittest.mock import patch
root=Path('/home/alex/Documents/IntrinsicEngine')
sys.path.insert(0,str(root/'tools/analysis'))
import compile_hotspots as h
build=root/'build/ci'
sources=['src/runtime/Editor/Runtime.EditorProcessing.cppm','src/runtime/Editor/Operations/Runtime.GeometryProcessingOperations.cppm','src/runtime/Editor/Runtime.EditorWorkspaceSnapshots.cppm']
forbidden=['Extrinsic.RHI.Device','Extrinsic.Runtime.SpatialIndexCache','Geometry.PointLBVH']
assert not h.check_module_boundary(root,build,sources,forbidden)
resolver=h.SourceResolver(root,build)
read_text=Path.read_text
for source in sources:
 outputs=[o for o,c in resolver.by_output.items() if any(x[0]==source for x in c)]
 assert len(outputs)==1
 ddi=Path(str(build/outputs[0])+'.ddi')
 for module in forbidden:
  def injected(path,*args,**kwargs):
   text=read_text(path,*args,**kwargs)
   if path==ddi:
    data=json.loads(text)
    data['rules'][0].setdefault('requires',[]).append({'logical-name':module})
    return json.dumps(data)
   return text
  with patch.object(Path,'read_text',injected):
   failures=h.check_module_boundary(root,build,[source],forbidden)
  assert any(f.endswith(' -> '+module) for f in failures), (source,module,failures)
  print('Expected rejection:',source,'->',module)
assert not h.check_module_boundary(root,build,sources,forbidden)
print('PASS: nine in-memory scanner-import faults rejected; unchanged real metadata passes.')
