from pathlib import Path
import subprocess,json,sys
p=Path('/tmp/intrinsic-graphics144'); stage=sys.argv[1]
cmd=['claude','-p','--effort','low','--max-turns','1','--tools','','--output-format','json','--setting-sources','','--settings','{"disableAllHooks":true}','--strict-mcp-config','--mcp-config','{"mcpServers":{}}','--no-session-persistence']
with (p/f'{stage}.json').open('w') as out,(p/f'{stage}.err').open('w') as err:
 r=subprocess.run(cmd,input=(p/f'{stage}-prompt.txt').read_text(),text=True,stdout=out,stderr=err)
d=json.loads((p/f'{stage}.json').read_text()); (p/f'{stage}.txt').write_text(d.get('result',str(d.get('errors',''))))
print((p/f'{stage}.txt').read_text()); raise SystemExit(r.returncode)
