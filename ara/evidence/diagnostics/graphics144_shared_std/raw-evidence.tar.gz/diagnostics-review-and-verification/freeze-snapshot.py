from pathlib import Path
import json,hashlib,re,shutil,subprocess
P=Path('/tmp/intrinsic-graphics144');R=Path('/home/alex/Documents/IntrinsicEngine');D=Path('/dev/shm/intrinsic-graphics144/frozen-snapshot');D.mkdir()
rows=json.loads((P/'snapshot-commands.json').read_text());maps={}
for arm in rows:
 maps[arm]={}
 for a in rows[arm][1]['modmap']:
  if a.startswith('-fmodule-file='):
   n,p=a[len('-fmodule-file='):].split('=',1);maps[arm][n]=str(Path(rows[arm][1]['directory'])/p)
assert set(maps['before'])-set(maps['after'])=={'Extrinsic.Runtime.Private.EditorSnapshotStd'}
assert set(maps['after'])-set(maps['before'])=={'Extrinsic.Core.Std'}
common=set(maps['before'])&set(maps['after']);assert all(maps['before'][n]==maps['after'][n] for n in common)
sources={}
for p in (R/'src').rglob('*.cppm'):
 m=re.search(r'^export module ([^;]+);',p.read_text(),re.M)
 if m:sources[m[1]]=p
fixed={}
for n in sorted(common):
 old=Path(maps['after'][n]);assert old.is_file(),old
 src=sources[n];rel=str(src.relative_to(R));baseline=subprocess.check_output(['git','show','dc606482a:'+rel],cwd=R);assert baseline==src.read_bytes(),rel
 dest=D/(n+'.pcm');shutil.copyfile(old,dest)
 fixed[n]={'path':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'source':rel,'source_sha256':hashlib.sha256(baseline).hexdigest(),'bytes':dest.stat().st_size}
(P/'snapshot-frozen.json').write_text(json.dumps(fixed,indent=2)+'\n')
flags=['-fmodule-file='+n+'='+x['path'] for n,x in fixed.items()];graph={};out=P/'snapshot-module-info';out.mkdir()
for n,x in fixed.items():
 r=subprocess.run(['/usr/bin/clang++-23','-module-file-info',x['path']]+flags,capture_output=True,text=True);assert r.returncode==0,(n,r.stderr)
 (out/(n+'.txt')).write_text(r.stdout+r.stderr);graph[n]=re.findall(r"Imports module '([^']+)':",r.stdout)
for n in graph:
 for q in graph[n]:assert q in graph,(n,q)
assert not (set(graph)&{'Extrinsic.Graphics.Renderer','Extrinsic.Runtime.EditorWorkspaceSnapshots','Extrinsic.Runtime.Private.EditorSnapshotStd','Extrinsic.Core.Std'})
(P/'snapshot-import-graph.json').write_text(json.dumps({'passed':True,'imports':graph,'source':'clang++-23 -module-file-info with all explicit frozen module maps; every prerequisite source matches baseline bytes'},indent=2)+'\n')
print('Frozen and validated',len(fixed),'unchanged prerequisite BMIs;',sum(x['bytes'] for x in fixed.values()),'bytes')
