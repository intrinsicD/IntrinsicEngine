from pathlib import Path
import subprocess,json,hashlib,time
P=Path('/tmp/intrinsic-graphics144');R=Path('/home/alex/Documents/IntrinsicEngine');B=Path('/dev/shm/intrinsic-graphics144');label='baseline-glm-fwd-only';assert not (P/(label+'.summary.json')).exists()
src=subprocess.check_output(['git','show','dc606482a:src/graphics/renderer/Graphics.Renderer.cppm'],cwd=R).decode();assert src.count('#include <glm/glm.hpp>')==1
src=src.replace('#include <glm/glm.hpp>','#include <glm/fwd.hpp>')
source=P/(label+'.cppm');source.write_text(src)
prior=json.loads((P/'before-renderer.summary.json').read_text());args=prior['command'];args[args.index('-c')+1]=str(source);args[args.index('-o')+1]=str(B/(label+'.o'));args=[a for a in args if not a.startswith('-ftime-trace=')];mp=P/(label+'.modmap');lines=(P/'before-renderer.modmap').read_text().splitlines();mp.write_text('\n'.join('-fmodule-output='+str(B/(label+'.pcm')) if a.startswith('-fmodule-output=') else a for a in lines)+'\n');args[next(i for i,a in enumerate(args) if a.startswith('@'))]='@'+str(mp);args+=['-ftime-trace='+str(P/(label+'.trace.json'))]
start=time.perf_counter()
with (P/(label+'.log')).open('w') as out:r=subprocess.run(['/usr/bin/time','-v','-o',str(P/(label+'.time.txt'))]+args,cwd=prior['cwd'],stdout=out,stderr=subprocess.STDOUT)
d={'label':label,'scope':'one partial-variant trace diagnostic, not benchmark cohort','source':'baseline source with only GLM umbrella replaced by fwd','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'command':args,'cwd':prior['cwd'],'returncode':r.returncode,'outer_wall_seconds':time.perf_counter()-start}
if r.returncode==0:
 t=json.loads((P/(label+'.trace.json')).read_text());d['totals_s']={x['name']:x['dur']/1e6 for x in t['traceEvents'] if x['name'].startswith('Total ') and 'dur' in x};d['bmi_bytes']=(B/(label+'.pcm')).stat().st_size
(P/(label+'.summary.json')).write_text(json.dumps(d,indent=2)+'\n');print(label,r.returncode,d.get('bmi_bytes'),d.get('totals_s',{}).get('Total WriteAST'));raise SystemExit(r.returncode)
