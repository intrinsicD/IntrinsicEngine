from pathlib import Path
import json,hashlib,statistics,collections,sys,yaml
R=Path('/home/alex/Documents/IntrinsicEngine');P=Path('/tmp/intrinsic-graphics144')
sys.path.insert(0,str(R/'tools/analysis'))
from benchmark_compile_iteration import dependency_snapshot
summary={};packages=dependency_snapshot(R/'external/vcpkg-installed/ci');freeze=json.loads((P/'premeasurement-freeze.json').read_text())
for name,dig in freeze['sha256'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==dig,name
for cohort in ['snapshot-control','measurement']:
 B=P/cohort;protocol=json.loads((B/'protocol.json').read_text());manifest=protocol['manifest'];rows=[];paths=sorted((B/'results').glob('*.json'));assert len(paths)==10
 assert len(manifest['params']['sample_order'])==10
 assert protocol['runner_sha256']==freeze['sha256'][str(P/'snapshot-control.py') if cohort=='snapshot-control' else 'tools/analysis/benchmark_compile_iteration.py']
 for i,f in enumerate(paths,1):
  d=json.loads(f.read_text());assert d['execution_status']=='passed' and not d['claim_eligible'] and d['source']['state']=='clean_commit';arm=d['diagnostics']['arm'];assert arm==manifest['params']['sample_order'][i-1]
  assert d['commit']==manifest['params']['source_revisions'][arm] and d['diagnostics']['position']==i and d['diagnostics']['source_clean_before_after']
  assert d['metrics']['sample_count']==1
  row={'attempt_id':d['attempt_id'],'arm':arm,'revision':d['commit'],'wall_ms':d['metrics']['build_time_ms'],'memory_peak_bytes':d['metrics']['memory_peak_bytes']}
  if cohort=='measurement':
   row['compiler_invocations']={s:x['compiler_invocations'] for s,x in d['diagnostics']['scenarios'].items()};row['critical_path_ms']={s:x['critical_path']['duration_ms'] for s,x in d['diagnostics']['scenarios'].items()};row['configure_ms']=d['metrics']['configure_time_ms'];assert json.loads((B/d['attempt_id']/'dependencies.json').read_text())==packages
  else:
   row['bmi_bytes']=d['diagnostics']['emitted_bmi_bytes']
   for label,detail in d['diagnostics']['scenarios'].items():
    data=__import__('subprocess').check_output(['git','show',d['commit']+':'+detail['source']],cwd=R);assert hashlib.sha256(data).hexdigest()==detail['source_sha256']
  rows.append(row)
 assert collections.Counter(x['arm'] for x in rows)=={'before':5,'after':5}
 metrics={}
 for scenario in rows[0]['wall_ms']:
  arms={a:[x['wall_ms'][scenario] for x in rows if x['arm']==a] for a in ['before','after']};metrics[scenario]={a:{'median_ms':statistics.median(v),'min_ms':min(v),'max_ms':max(v)} for a,v in arms.items()};metrics[scenario]['median_change_percent']=(statistics.median(arms['after'])/statistics.median(arms['before'])-1)*100
 c={'benchmark_id':manifest['benchmark_id'],'samples':rows,'timings':metrics,'claim_eligible':False}
 if cohort=='snapshot-control':assert protocol['packages']==packages
 else:
  commands={};sets={};producers={}
  for row in rows:
   arm=row['arm'];path=B/row['attempt_id'];cmds={x['file']:x['command'] for x in json.loads((path/'compile_commands.json').read_text())};assert len(cmds)==len(json.loads((path/'compile_commands.json').read_text()))
   assert arm not in commands or commands[arm]==cmds;commands[arm]=cmds
   current={s:{x['source'] for x in json.loads((path/(s+'.hotspots.json')).read_text())} for s in row['wall_ms']};assert arm not in sets or sets[arm]==current;sets[arm]=current
   for s in row['wall_ms']:
    for x in json.loads((path/(s+'.hotspots.json')).read_text()):producers.setdefault(s,{}).setdefault(x['source'],{}).setdefault(arm,[]).append(x['duration_ms'])
  common=set(commands['before'])&set(commands['after']);assert all(commands['before'][s]==commands['after'][s] for s in common)
  c['common_command_count']=len(common);c['commands_added']=sorted(set(commands['after'])-set(commands['before']));c['commands_removed']=sorted(set(commands['before'])-set(commands['after']))
  c['source_sets']={a:{s:sorted(xs) for s,xs in v.items()} for a,v in sets.items()};c['producer_timings_ms']={s:{p:{a:{'median':statistics.median(v),'samples':v} for a,v in arm.items()} for p,arm in ps.items()} for s,ps in producers.items()}
 summary[cohort]=c
summary['dependencies_before_during_after']=packages;summary['freeze']=freeze
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for n,c in summary.items():
 if isinstance(c,dict) and 'timings' in c:print(n,json.dumps(c['timings'],indent=2))
