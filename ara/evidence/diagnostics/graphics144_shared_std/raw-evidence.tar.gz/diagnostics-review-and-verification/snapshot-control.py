from pathlib import Path
from datetime import UTC,datetime
import collections,hashlib,json,os,shlex,subprocess,sys,time,yaml
ROOT=Path('/home/alex/Documents/IntrinsicEngine'); P=Path('/tmp/intrinsic-graphics144'); BASE=Path('/dev/shm/intrinsic-graphics144'); SOURCE=BASE/'source'; BUILD=BASE/'snapshot-output'; OUTPUT=P/'snapshot-control'
sys.path[:0]=[str(ROOT/'tools/analysis'),str(ROOT/'tools/benchmark')]
from benchmark_compile_iteration import dependency_snapshot,command,write_json
from seal_benchmark_results import canonicalize
from validate_benchmark_results import validate_result_data
manifest_path=ROOT/'benchmarks/ci/manifests/snapshot_shared_std.yaml';manifest=yaml.safe_load(manifest_path.read_text());params=manifest['params'];rows=json.loads((P/'snapshot-commands.json').read_text())
fixed=json.loads((P/'snapshot-frozen.json').read_text());packages=dependency_snapshot(ROOT/'external/vcpkg-installed/ci')
assert not manifest_path.is_relative_to(SOURCE)
assert json.loads((P/'snapshot-import-graph.json').read_text())['passed']
inputs=json.loads((P/'snapshot-input-files.json').read_text())
assert set(rows)=={'before','after'} and all(len(r)==2 for r in rows.values())
assert rows['before'][1]['command']==rows['after'][1]['command']
assert collections.Counter(params['sample_order'])=={'before':5,'after':5}
assert all(not a.startswith('-fmodule-file=') for arm in rows for a in rows[arm][0]['modmap'])
assert not OUTPUT.exists();OUTPUT.mkdir();BUILD.mkdir(exist_ok=True)
write_json(OUTPUT/'protocol.json',{'manifest':manifest,'manifest_sha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest(),'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'commands':rows,'std_owner_execution_flags':'baseline runtime-owner flags in both arms; actual per-target captures retained','frozen':fixed,'input_files':inputs,'supporting_sha256':{n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in ['snapshot-commands.json','snapshot-import-graph.json','snapshot-input-files.json']},'packages':packages,'compiler':command(['/usr/bin/clang++-23','--version'],ROOT)})
counts=collections.Counter()
def verify():
 for n,d in inputs.items():assert hashlib.sha256(Path(n).read_bytes()).hexdigest()==d['sha256'],n
 for n,f in fixed.items():
  assert hashlib.sha256(Path(f['path']).read_bytes()).hexdigest()==f['sha256'],n
  assert hashlib.sha256((SOURCE/f['source']).read_bytes()).hexdigest()==f['source_sha256'],n
 assert dependency_snapshot(ROOT/'external/vcpkg-installed/ci')==packages
for position,arm in enumerate(params['sample_order'],1):
 assert not command(['git','status','--porcelain'],SOURCE)
 rev=params['source_revisions'][arm];subprocess.run(['git','checkout','--detach',rev],cwd=SOURCE,check=True,capture_output=True)
 assert command(['git','rev-parse','HEAD'],SOURCE).strip()==rev
 counts[arm]+=1;attempt=f'{position:02d}-{arm}-{counts[arm]}';dest=OUTPUT/attempt;dest.mkdir();print('START',attempt,flush=True);verify()
 for f in BUILD.iterdir():assert f.is_file();f.unlink()
 timings={};rss={};details={}
 for label,row in zip(['std_owner','snapshot_interface'],rows[arm],strict=True):
  rel=Path(row['file']).relative_to(ROOT);src=SOURCE/rel;data=src.read_bytes();args=shlex.split((rows['before'][0] if label=='std_owner' else row)['command']);assert args[0]=='/usr/bin/clang++-23'
  assert sum(a.startswith('@') for a in args)==1
  assert args.count('-c')==1 and args.count('-o')==1
  assert args[args.index('-c')+1]==(rows['before'][0] if label=='std_owner' else row)['file']
  for a in args:assert not a.startswith(('-MD','-MMD','-MF','-MT','-MQ','-MJ','--serialize-diagnostics','-serialize-diagnostics','-fmodules-cache-path','-fmodule-output=','-ftime-trace','-fprebuilt-module-path')),a
  args[args.index('-o')+1]=str(BUILD/(label+'.o'));args[args.index('-c')+1]=str(src)
  args=[a if ('ENGINE_ROOT_DIR=' in a or str(ROOT/'external')+'/' in a) else a.replace(str(ROOT)+'/',str(SOURCE)+'/') for a in args]
  for a in args:assert str(ROOT) not in a or 'ENGINE_ROOT_DIR=' in a or str(ROOT/'external')+'/' in a,a
  for i,a in enumerate(args):
   if a.startswith('-I'):assert Path(a[2:]).is_absolute(),a
   if a in ('-isystem','-iquote'):assert Path(args[i+1]).is_absolute(),args[i+1]
  lines=[]
  for a in row['modmap']:
   if a=='-x c++-module':lines.append(a)
   elif a.startswith('-fmodule-output='):lines.append('-fmodule-output='+str(BUILD/(label+'.pcm')))
   else:
    assert a.startswith('-fmodule-file='),a
    n=a[len('-fmodule-file='):].split('=',1)[0]
    loc=BUILD/'std_owner.pcm' if n in ['Extrinsic.Core.Std','Extrinsic.Runtime.Private.EditorSnapshotStd'] else Path(fixed[n]['path'])
    if loc==BUILD/'std_owner.pcm':assert label=='snapshot_interface'
    lines.append('-fmodule-file='+n+'='+str(loc))
  assert sum(a.startswith('-fmodule-output=') for a in lines)==1
  assert len(lines)==len(set(lines))
  mp=dest/(label+'.modmap');mp.write_text('\n'.join(lines)+'\n');args[next(i for i,a in enumerate(args) if a.startswith('@'))]='@'+str(mp)
  stamp=datetime.now(UTC).isoformat();started=time.perf_counter();load=os.getloadavg()
  with (dest/(label+'.log')).open('w') as log:
   r=subprocess.run(['/usr/bin/time','-q','-f','{"cpu_user_s":%U,"cpu_system_s":%S,"max_single_process_rss_kib":%M}','-o',str(dest/(label+'.time.json')),'--']+args,cwd=row['directory'],env=dict(os.environ,CCACHE_DISABLE='1'),stdout=log,stderr=subprocess.STDOUT)
  wall=(time.perf_counter()-started)*1000;record=json.loads((dest/(label+'.time.json')).read_text().splitlines()[-1]);record.update(started_at=stamp,command=args,source=str(rel),source_sha256=hashlib.sha256(data).hexdigest(),wall_ms=wall,exit_code=r.returncode,loadavg_before=load);write_json(dest/(label+'.execution.json'),record);assert r.returncode==0,(attempt,label)
  timings[label]=wall;rss[label]=record['max_single_process_rss_kib']*1024;details[label]=record
 verify();assert not command(['git','status','--porcelain'],SOURCE)
 timings['owner_and_snapshot']=sum(timings.values())
 raw={'benchmark_id':manifest['benchmark_id'],'method':manifest['method'],'dataset':manifest['dataset'],'backend':'external_baseline','commit':rev,'status':'passed','metrics':{'build_time_ms':timings,'memory_peak_bytes':rss,'sample_count':1},'diagnostics':{'arm':arm,'position':position,'sample':counts[arm],'scenarios':details,'emitted_bmi_bytes':{f.name:f.stat().st_size for f in BUILD.glob('*.pcm')},'source_clean_before_after':True}}
 write_json(dest/'raw-result.json',raw)
 sealed=canonicalize(raw,manifest_path=manifest_path,manifest=manifest,manifests_root=ROOT/'benchmarks',run_id='graphics144-snapshot-control',attempt_id=attempt,source_state='clean_commit',source_revision=rev,claim_eligible=False,snapshot_sha256=None,diff_sha256=None)
 results=OUTPUT/'results';results.mkdir(exist_ok=True);fp=results/(attempt+'.json');_,errors=validate_result_data(sealed,fp,{manifest['benchmark_id']:(manifest_path,manifest)},ROOT/'benchmarks');assert not errors,errors;write_json(fp,sealed);print('COMPLETE',attempt,round(timings['owner_and_snapshot']/1000,3),flush=True)
assert dict(counts)=={'before':5,'after':5}
