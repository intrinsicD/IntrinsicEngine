from pathlib import Path
import json,statistics
P=Path('/tmp/intrinsic-graphics144');s=json.loads((P/'summary.json').read_text());g=s['measurement'];w=s['snapshot-control']
def fmt(d):return f"{d['median_ms']/1000:.3f} [{d['min_ms']/1000:.3f}–{d['max_ms']/1000:.3f}]"
def table(c,names):return '\n'.join(f'| {label} | {fmt(c["timings"][k]["before"])} | {fmt(c["timings"][k]["after"])} |' for k,label in names)
clean=g['timings']['clean'];edit=g['timings']['renderer_interface']
t=f'''# GRAPHICS-144 — Shared standard declarations for renderer and snapshots

## Decision and scope

Keep the shared declaration owner and narrower renderer GLM include. In this local
five-sample-per-arm comparison, median **clean graphics-library build time changes
from {clean['before']['median_ms']/1000:.3f} to {clean['after']['median_ms']/1000:.3f} seconds
({-clean['median_change_percent']:.1f}% lower)**. A settled renderer-interface edit
changes from **{edit['before']['median_ms']/1000:.3f} to {edit['after']['median_ms']/1000:.3f} seconds
({-edit['median_change_percent']:.1f}% lower)**, including its implementation consumer.
Implementation-only rebuild ranges overlap; no implementation speedup is established.
The snapshot interface is also unchanged within overlapping ranges; compiling its
expanded owner in isolation adds a small cost, retained below.

These are compilation observations on this host, not whole-engine build, engine
runtime, GPU or cross-host results. No statistical significance or general speedup
is asserted. All twenty canonical records remain `claim_eligible: false`.

Exact source commits `dc606482aecec0f0412b06b7a811a62835e98438` →
`5537a4dda505959e6e818713963ce43ad7805c90`. The implementation was fully verified
before measurement. Manifest checkpoints are `7061e4e8a` and `70fb1222c`; the final
premeasurement freeze binds both manifests and runners. Earlier protocol refinements
are retained; no timed sample was discarded, repaired or overwritten.

## Matched graphics-library comparison

`build.engine_compile_iteration.graphics_std.v1`, Clang23 Debug, ci-derived
Null/headless configuration, target `ExtrinsicGraphics`, four compiler jobs,
cache/launchers disabled. Ten fresh tmpfs builds use one fixed detached source/build
path in ABBAABBAAB order. Every sample runs clean, settled no-op, implementation
mtime edit and interface mtime edit; source bytes remain at the exact clean commit.
Configure is recorded separately, outside the table's build wall times.

Seconds: median [minimum–maximum]. Every clean candidate build pays the new Core.Std
producer; settled edit probes reuse it. Build walls include scanning and linking.

| Scenario | Before | After |
|---|---:|---:|
{table(g,[('clean','Clean graphics library'),('renderer_interface','Renderer interface edit + consumer'),('renderer_impl','Renderer implementation edit'),('noop','Settled no-op')])}

Compiler invocations: clean 267 → 268, interface edits 2 → 2, implementation edits
1 → 1, no-op 0 → 0, constant across samples. The clean addition is Core.Std; the
old runtime-local owner lies outside this graphics target. The interface/implementation
source sets are identical, so the improvement does not come from omitting consumers.
{g['common_command_count']} common configured compile commands match byte-for-byte across all
samples; the only added/removed source entries are the moved declaration owner.
The same dependency-package fingerprint holds before, during and after every sample.

| Attempt | Clean | Implementation edit | Interface edit |
|---|---:|---:|---:|
'''
for r in g['samples']:t+=f"| {r['attempt_id']} | {r['wall_ms']['clean']/1000:.3f} | {r['wall_ms']['renderer_impl']/1000:.3f} | {r['wall_ms']['renderer_interface']/1000:.3f} |\n"
t+='''
Ninja invocation windows and dependency-DAG weighted critical paths, per-producer
walls, user/system CPU and maximum single-process RSS are retained in the raw
records and summary. Critical-path durations are not aggregate compile time;
maximum process RSS is not the sum of concurrently running compilers. No memory
improvement is claimed.

## Snapshot cost control

`build.engine_compile_iteration.snapshot_shared_std.v1` replays two serial producer
commands per sample: declaration owner, then snapshot. Both arms use the original
runtime-owner compiler flags to isolate declaration cost; actual Core-target flags
remain captured and are used naturally in the separate graphics-build cohort.
The snapshot command is byte-identical. These ci prerequisite flags have Vulkan/GLFW
configured, unlike the Null/headless graphics cohort; there is no GPU execution.

Ninety-one frozen prerequisite BMIs have source bytes identical in both commits;
compiler-inspected import metadata verifies that none imports either standard owner,
the renderer or the snapshot. Every sample rebuilds its owner/snapshot and uses those
fresh BMIs. All frozen BMI hashes, 831 recorded input-file hashes, exact worktree
sources and dependency-package fingerprints are checked before/after each sample.
The root source and shared inputs remain unchanged during sampling.

| Producer or pair | Before | After |
|---|---:|---:|
'''+table(w,[('std_owner','Standard declaration owner'),('snapshot_interface','Snapshot interface'),('owner_and_snapshot','Serial owner + snapshot pair')])+'''

The pair row is the median of each sample's summed walls, not the sum of medians.
In a graphics-plus-runtime build Core.Std would already be built; do not add its
cost twice or sum these two independent benchmark cohorts. This control is not a
whole-runtime measurement. All samples and per-command RSS remain in the summary.

## Source change and alternatives

Move the existing 21-line runtime declaration owner to the 26-line Core.Std module,
adding only renderer-required function/span/unique_ptr declarations. Both measured
consumers name the original standard types through ordinary using-declarations in
an engine namespace. No replacement containers, wrappers, allocation, forwarding,
new target-link edge or compatibility path; helper names are not re-exported by
these consumers. Required renderer subsystem imports and all implementation state
remain. The former snapshot-specific private-import exception is removed.

Source accounting: **+6 production C++ lines**, no net source-file/module addition,
419 modules total. CMake has one added and one removed fileset entry. This reduces
repeated compiler work; it is not a source-line reduction claim. A separate graphics
copy would duplicate the existing owner. Pimpl or record splits would change more
ownership without directly addressing the measured serialization interaction.

The renderer needs only the visible vec3 name from `<glm/fwd.hpp>`. Its required
SpatialDebugVisualizers import exports SpatialDebugAabb with by-value vec3 members,
which makes the complete definition reachable. An explicit `sizeof(glm::vec3)`
assertion precedes the spans. A forward declaration alone would be insufficient:
[span requires a complete element type](https://eel.is/c++draft/span.overview), and
[reachable declarations carry completeness](https://eel.is/c++draft/module.reach).
Concrete implementation files keep their own full headers. Both minimum-supported
Clang20 and current Clang23 compile the final assertion and real consumers.

Single trace controls below are diagnostics, not matched performance comparisons.
Every control keeps the required renderer imports and data/API shape. The GLM-only
control is a temporary copy of the exact baseline with only its include narrowed;
the standard-only prototype retains the full GLM include. The final assertion is
included only in the final combined diagnostic and verified implementation.

| Renderer source variant | Emitted BMI bytes | WriteAST seconds |
|---|---:|---:|
| Exact baseline | 30,132,708 | 9.513907 |
| Shared standard owner only | 15,069,644 | 5.798290 |
| GLM forward include only | 25,100,172 | 7.318660 |
| Final combined change | 807,440 | 0.046537 |

The new owner independently emits 10,729,460 bytes in its single diagnostic.
Renderer-only BMI reduction does not include this producer or the whole prerequisite
cache. The matched clean target charges it. Trace categories overlap and cannot be
summed. Source hashes, exact commands/maps, outer wall, phase totals, BMI sizes and
all controls are retained. No project-wide compiler flag or BMI-mode change shipped.

## Verification, review and remaining work

Canonical ci configure and complete IntrinsicTests build passed. Focused CPU:
444 passed (35.19 seconds). Full CPU: 4,664 passed, zero failures, one expected
ASan-only GLFW leak-control skip out of 4,665 selected (141.22 seconds). Existing
material, UV, extraction, frame-hook, snapshot and compiler-boundary tests remain.
New static assertions verify exact renderer factory, hook and span standard types;
existing snapshot contracts verify aggregates, standard types and value semantics.

A fresh cache-off Clang20 Null/headless Sandbox editor closure passed. Final
reconciliation includes the completeness assertion and renderer lifecycle/snapshot
model test objects. This is Clang20 build evidence, not Clang20 test execution.
There is no GPU or sanitizer execution claim. No runtime/GPU lifetime code changed.
Strict layering/task/test-layout/root/documentation checks pass; inventory is current.
Source-documentation audit has zero objective errors; 23 review flags were inspected,
retaining existing lifecycle and ownership comments outside this slice.

Claude reviewed the plan, fixed source, completeness reasoning, measurement protocol
and final results. Resolutions include explicit complete-type proof, common compiler
flags, immutable prerequisite input/source checks, safe source/output rewriting,
full source IDs, separate owner costs and bounded claims. Hypothetical objections
contradicted by captured command/metadata evidence are documented as such.

GRAPHICS-144 closes at CPUContracted. The renderer implementation remains a compile
cost; this slice establishes no improvement there. RUNTIME-267 stays open: its
by-value config/results and embedded prepared frame need an ownership decision;
replacing the panel frame with references to construction temporaries is invalid.
No session facade was added. UI-037, GRAPHICS-105, LEGACY-043 and BUILD-006 retain
their independently owned work and prerequisites.

## Reproduction and evidence

Inputs are pre-read, with no cache flushing or CPU affinity/governor/turbo control.
Normal desktop noise remains; no competing build/test jobs ran during timing.
No cold-filesystem, publication-grade or stable future-speedup claim is made.

The canonical graphics runner is unchanged. The archived snapshot replay reuses
canonical fingerprint/sealing/validation helpers. Recreate the exact source commits,
recorded toolchain and dependency versions; for the focused replay, rebuild and
freeze the unchanged prerequisite closure and input hashes before invoking the
saved runner. Absolute paths describe this host; prebuilt BMI/object binaries are
not checked in. All20 canonical results, full raw commands/logs/Ninja graphs, source
hashes, diagnostic controls, runner scripts and fixed Claude packets are archived.

[Graphics manifest](../../../benchmarks/ci/manifests/graphics_standard_declarations.yaml) ·
[Snapshot manifest](../../../benchmarks/ci/manifests/snapshot_shared_std.yaml) ·
[All samples and recalculation](../diagnostics/graphics144_shared_std/summary.json) ·
[Verification](../diagnostics/graphics144_shared_std/verification.json) ·
[Source/protocol/archive index](../diagnostics/graphics144_shared_std/evidence-index.json) ·
[Claude results review](../diagnostics/graphics144_shared_std/results-review.txt) ·
[Raw evidence](../diagnostics/graphics144_shared_std/raw-evidence.tar.gz).
'''
(P/'report-draft.md').write_text(t)
print('Wrote bounded report draft; review before publishing.')
