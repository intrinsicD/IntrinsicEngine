from pathlib import Path
import sys,json,shlex,subprocess,time,hashlib
root=Path('/home/alex/Documents/IntrinsicEngine');p=Path('/tmp/intrinsic-graphics144');out=Path('/dev/shm/intrinsic-graphics144');out.mkdir(exist_ok=True)
label,relative=sys.argv[1:];source=root/relative
assert not (p/(label+'.summary.json')).exists()
row=next(r for r in json.loads((root/'build/ci/compile_commands.json').read_text()) if r['file']==str(source));args=shlex.split(row['command']);cwd=Path(row['directory']);mi=next(i for i,a in enumerate(args) if a.startswith('@'));lines=(cwd/args[mi][1:]).read_text().splitlines();pcm=out/(label+'.pcm');obj=out/(label+'.o');mp=p/(label+'.modmap')
mp.write_text('\n'.join('-fmodule-output='+str(pcm) if a.startswith('-fmodule-output=') else a for a in lines)+'\n');args[mi]='@'+str(mp);args[args.index('-o')+1]=str(obj);trace=p/(label+'.trace.json');args+=['-ftime-trace='+str(trace)]
driver=subprocess.run(args+['-###'],cwd=cwd,text=True,capture_output=True);(p/(label+'.driver.txt')).write_text(driver.stderr)
start=time.perf_counter()
with (p/(label+'.log')).open('w') as f:r=subprocess.run(['/usr/bin/time','-v','-o',str(p/(label+'.time.txt'))]+args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
d={'label':label,'source':relative,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'dirty':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),'command':args,'cwd':str(cwd),'outer_wall_seconds':time.perf_counter()-start,'returncode':r.returncode,'driver_cc1_jobs':driver.stderr.count('"-cc1"'),'scope':'one trace diagnostic; not benchmark cohort'}
if r.returncode==0:
 t=json.loads(trace.read_text());d['totals_s']={x['name']:x['dur']/1e6 for x in t['traceEvents'] if x['name'].startswith('Total ') and 'dur' in x};d['bmi_bytes']=pcm.stat().st_size if pcm.exists() else 0
(p/(label+'.summary.json')).write_text(json.dumps(d,indent=2)+'\n');print(label,r.returncode,round(d['outer_wall_seconds'],3),d.get('bmi_bytes'),d.get('totals_s',{}).get('Total WriteAST'));sys.exit(r.returncode)
