# GRAPHICS-144 evidence notes (not a claim record)

Exact verified source dc606482a -> 5537a4dda. Frozen graphics manifest7061e4e8a,
snapshot clarified70fb1222c. Final runner hash in premeasurement-freeze.json;
first freeze preserved v1, no timed sample before final refinement.

Source relocation: src production +6lines total (Core new26 vs old21; renderer+1),
no net file/module gain:419modules. Private import exception removed. No API data
shape/lifetime/state/algorithm changes. Reuse existing standard entities, no std
namespace additions. Std names aren't reexported by consumers. Shared owner only
these two actual users; no broad prelude mandate.

Source review: two compilers including final sizeofassert; existing exported
SpatialDebugAabb by-valuevec3 and LightSystem records require reachable definition.
span element must be complete; glm/fwd only supplies visible name. See official
https://eel.is/c++draft/span.overview and https://eel.is/c++draft/module.reach.
No private implpartition reachability reliance.

Diagnostics only: exactbaseline fullstd/fullglm30,132,708BMI WriteAST9.513907s;
Stdsharing alone fullglm15,069,644 /5.798290s;
GLMfwdonly baseline25,100,172 /7.318660s;
finalcombined807,440 /0.046537s. Every tracephase overlaps; no sum or matchedspeedup
from these1-offvariants. Controls retain same actual engineimports/API except
stdnames/headerroute and implementation-only sourcecopy forGLMonly.

MinimumClang20 build fresh1,612steps plus finalassert/testobjectreconciliation153.
CanonicalfinalIntrinsicTests119actions;444focused35.19s,full4,665selected4,664pass
1ASan-onlyskip141.22s. GPU/sanitizer not run/claimed. Strictsourcechecks pass;
source-doc0errors23manualreview flags retain ownership/lifecyclecomments.

RUNTIME267audit: embeddedpreparedframe config/resultvalueownership; don't replace
fields with references to temporaries; no facades added. Remainsopen. EarlyClaude
plan simulatedtoolcalls and falsepaths discarded, not evidence.
