import ctypes,re,subprocess,sys,time
from pathlib import Path
pid=int(sys.argv[1])
windows=subprocess.check_output(['xwininfo','-root','-tree'],text=True)
for xid in re.findall(r'^\s*(0x[0-9a-fA-F]+)\s', windows, re.M):
    owner=subprocess.run(['xprop','-id',xid,'_NET_WM_PID'],capture_output=True,text=True)
    match=re.search(r'=\s*(\d+)',owner.stdout)
    if not match or int(match[1])!=pid: continue
    details=subprocess.check_output(['xwininfo','-id',xid],text=True)
    width=re.search(r'Width:\s*(\d+)',details)
    if not width or int(width[1])<100: continue
    x11=ctypes.CDLL('libX11.so.6'); x11.XOpenDisplay.restype=ctypes.c_void_p
    x11.XRaiseWindow.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
    x11.XFlush.argtypes=[ctypes.c_void_p]; x11.XCloseDisplay.argtypes=[ctypes.c_void_p]
    display=x11.XOpenDisplay(None)
    if display:
        x11.XRaiseWindow(display,int(xid,16)); x11.XFlush(display); time.sleep(.3); x11.XCloseDisplay(display)
    output=Path('/tmp/intrinsic-method047-collaboration/atlas-workspace.png')
    subprocess.run(['import','-window',xid,str(output)],check=True,timeout=15)
    print('Captured task-owned Sandbox window:',output)
    break
else: raise SystemExit('No Sandbox window belonging to the diagnostic process')
