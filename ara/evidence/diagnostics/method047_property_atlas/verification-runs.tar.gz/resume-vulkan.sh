#!/usr/bin/env bash
set -eu
cd /home/alex/Documents/IntrinsicEngine
CCACHE_DISABLE=1 cmake --build --preset ci-vulkan --target IntrinsicTests ExtrinsicSandbox -j2 > /tmp/intrinsic-method047-collaboration/vulkan-final-build-3.log 2>&1
ctest --test-dir build/ci-vulkan --output-on-failure -L gpu -L vulkan --timeout 120 -j1 > /tmp/intrinsic-method047-collaboration/vulkan-final-tests-2.log 2>&1
cp build/ci-vulkan/Testing/Temporary/LastTest.log /tmp/intrinsic-method047-collaboration/vulkan-final-tests-2-output.log
bash /tmp/intrinsic-method047-collaboration/capture-atlas.sh
