from pathlib import Path
import time
pid=2362924
# Hold the actual running CTest log inode. A concurrent show-only metadata
# query replaced the path; this descriptor retains the original complete log.
with open(f'/proc/{pid}/fd/4','rb') as source:
 while Path(f'/proc/{pid}').exists():time.sleep(1)
 source.seek(0);data=source.read()
 out=Path('/tmp/intrinsic-method047-collaboration/vulkan-final-tests-2-recovered-output.log')
 out.write_bytes(data)
 print('Retained original CTest output:',len(data),'bytes; null bytes:',data.count(b'\0'))
