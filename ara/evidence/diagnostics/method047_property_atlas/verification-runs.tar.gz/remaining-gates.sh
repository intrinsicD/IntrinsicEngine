#!/usr/bin/env bash
set -eu
cd /home/alex/Documents/IntrinsicEngine
rg -q '^100% tests passed' /tmp/intrinsic-method047-collaboration/full-cpu-9.log
cmake --build --preset ci-asan --target IntrinsicCpuTests -j2 > /tmp/intrinsic-method047-collaboration/asan-build-4.log 2>&1
ctest --test-dir build/ci-asan --output-on-failure -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60 --parallel 1 > /tmp/intrinsic-method047-collaboration/asan-full-4.log 2>&1
cp build/ci-asan/Testing/Temporary/LastTest.log /tmp/intrinsic-method047-collaboration/asan-full-4-output.log
bash /tmp/intrinsic-method047-collaboration/final-corpus.sh > /tmp/intrinsic-method047-collaboration/final-corpus-summary.log 2>&1
cmake --preset ci-ubsan --fresh -DINTRINSIC_GROUP_PURE_CTEST=ON > /tmp/intrinsic-method047-collaboration/ubsan-configure-2.log 2>&1
cmake --build --preset ci-ubsan --target IntrinsicCpuTests -j2 > /tmp/intrinsic-method047-collaboration/ubsan-build-2.log 2>&1
ctest --test-dir build/ci-ubsan --output-on-failure -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60 --parallel 1 > /tmp/intrinsic-method047-collaboration/ubsan-full-2.log 2>&1
cp build/ci-ubsan/Testing/Temporary/LastTest.log /tmp/intrinsic-method047-collaboration/ubsan-full-2-output.log
cmake --preset ci-vulkan > /tmp/intrinsic-method047-collaboration/vulkan-final-configure-2.log 2>&1
cmake --build --preset ci-vulkan --target IntrinsicTests ExtrinsicSandbox -j2 > /tmp/intrinsic-method047-collaboration/vulkan-final-build-2.log 2>&1
ctest --test-dir build/ci-vulkan --output-on-failure -L gpu -L vulkan --timeout 120 -j1 > /tmp/intrinsic-method047-collaboration/vulkan-final-tests-2.log 2>&1
cp build/ci-vulkan/Testing/Temporary/LastTest.log /tmp/intrinsic-method047-collaboration/vulkan-final-tests-2-output.log
