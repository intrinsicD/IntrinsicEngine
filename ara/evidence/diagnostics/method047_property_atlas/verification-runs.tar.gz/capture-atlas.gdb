set pagination off
set confirm off
set environment ASAN_OPTIONS detect_leaks=0
break Test.RuntimeSandboxAcceptanceGpuSmoke.cpp:2145
run --gtest_filter=RuntimeSandboxAcceptanceGpuSmoke.AtlasWorkspaceUsesOperationalGpuTargetAndSceneRectangle
python import subprocess; subprocess.run(["python3", "/tmp/intrinsic-method047-collaboration/capture-atlas-window.py", str(gdb.selected_inferior().pid)], check=True)
continue
