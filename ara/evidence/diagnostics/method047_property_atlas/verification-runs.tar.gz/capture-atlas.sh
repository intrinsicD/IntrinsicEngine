#!/usr/bin/env bash
set -eu
cd /home/alex/Documents/IntrinsicEngine
rg -q '^100% tests passed' /tmp/intrinsic-method047-collaboration/vulkan-final-tests-2.log
# This extra debugger capture is a visual diagnostic, not a sanitizer gate.
# LeakSanitizer cannot run under ptrace; the normal unmodified gate runs first.
gdb -q -batch -x /tmp/intrinsic-method047-collaboration/capture-atlas.gdb --args build/ci-vulkan/bin/IntrinsicRuntimeSandboxAcceptanceGpuSmokeTests > /tmp/intrinsic-method047-collaboration/atlas-workspace-capture.log 2>&1
test -s /tmp/intrinsic-method047-collaboration/atlas-workspace.png
