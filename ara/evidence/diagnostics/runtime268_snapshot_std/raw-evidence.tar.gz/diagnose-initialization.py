from pathlib import Path
import time
p=Path('/tmp/intrinsic-runtime268')
while not (p/'runtime-function.summary.json').exists():time.sleep(1)
exec((p/'diagnose.py').read_text().split('identity=')[0])
for label,body in [('string-no-init','std::string Value;'),('string-declared-ctor','std::string Value; Single();'),('string-reference','std::string* Value;'),('vector-no-init','std::vector<int> Value;')]:
 text=gmf+'export module Intrinsic.Diagnostic.InitializationProbe;\n'+imports+'\nexport namespace Extrinsic::Runtime { struct Single { '+body+' }; }\n'
 run(label,text,{'kind':'synthetic member initialization control'})
# Equivalent export shape, preserves all named declarations.
text=original.replace('export namespace Extrinsic::Runtime\n{','namespace Extrinsic::Runtime\n{\nexport {')
text=text.rstrip()+'\n}\n'
run('export-block',text,{'kind':'full source with inner export block instead of export namespace'})
