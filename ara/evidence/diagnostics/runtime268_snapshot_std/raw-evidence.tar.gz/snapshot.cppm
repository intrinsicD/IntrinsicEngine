// Read-only editor workspace and panel snapshots, including cached selections.
// Exposes copied presentation state without granting scene mutation access.
module;

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <vector>

export module Intrinsic.Diagnostic.SnapshotGroup;
import Extrinsic.ECS.Components.GeometrySources;
import Extrinsic.Runtime.EditorCommon;
import Extrinsic.Runtime.EditorWorkspaceAttachment;
import Extrinsic.Runtime.EditorProcessing;
import Extrinsic.Runtime.GeometryProcessingOperations;
import Extrinsic.Runtime.RenderRecipeEditingOperations;
import Extrinsic.Runtime.SceneEditingOperations;
import Extrinsic.Runtime.VisualizationEditingOperations;
namespace Extrinsic::Runtime { struct EditorWorkspaceSnapshotQueriesAccess; }
export namespace Extrinsic::Runtime {
    struct EditorGeometryDomainModel
    {
        ECS::Components::GeometrySources::Domain Domain{
            ECS::Components::GeometrySources::Domain::None};
        bool        Valid{false};
        std::size_t VertexCount{0u};
        std::size_t EdgeCount{0u};
        std::size_t HalfedgeCount{0u};
        std::size_t FaceCount{0u};
        std::size_t NodeCount{0u};
    };
    struct EditorInspectorModel
    {
        bool                             HasEntity{false};
        EditorEntityRow          Entity{};
        EditorTransformModel     Transform{};
        EditorRenderHintModel    RenderHints{};
        EditorGeometryDomainModel Geometry{};
        EditorPropertyCatalogModel PropertyCatalog{};
        EditorGeometryPresentationModel GeometryPresentation{};
        EditorBoundRenderStateModel BoundState{};
        EditorTextureBakeControlsModel TextureBake{};
        EditorGeometryProcessingCapabilities Processing{};
        std::vector<EditorDiagnostic> Diagnostics{};
    };
extern "C++" {
    struct EditorWorkspaceSnapshot
    {
        std::vector<EditorEntityRow> Hierarchy{};
        EditorInspectorModel         Inspector{};
        EditorSelectionModel         Selection{};
        EditorDocumentModel          Document{};
        EditorSceneFileModel        SceneFile{};
        EditorFileImportModel        FileImport{};
        EditorAssetImportQueueModel  AssetImportQueue{};
        EditorRenderGraphModel       RenderGraph{};
        EditorRenderRecipeEditorModel RenderRecipe{};
        EditorCameraRenderModel      CameraRender{};
        EditorVisualizationModel     Visualization{};
        EditorWorkspaceSnapshotStats        ModelBuildStats{};
        std::vector<EditorDiagnostic> Diagnostics{};
    };
}
}
