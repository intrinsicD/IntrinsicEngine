from pathlib import Path
import json,subprocess,time
p=Path('/tmp/intrinsic-runtime268')
exec((p/'diagnose.py').read_text().split('identity=')[0])
lib=p/'StdTypes.cppm';lib.write_text(gmf+'export module Intrinsic.Diagnostic.StdTypes;\nexport namespace std { using std::array; using std::size_t; using std::uint8_t; using std::uint32_t; using std::uint64_t; using std::shared_ptr; using std::optional; using std::nullopt; using std::string; using std::vector; }\n')
args=base.copy();args.remove(args[mi]);pcm=out/'StdTypes.pcm';args+=['-fmodule-output='+str(pcm)];args[args.index('-c')+1]=str(lib);args[args.index('-o')+1]=str(out/'StdTypes.o')
start=time.perf_counter()
with (p/'stdlib-owner.log').open('w') as f:r=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
print('Std owner',r.returncode,round(time.perf_counter()-start,3),flush=True)
assert r.returncode==0,(p/'stdlib-owner.log').read_text()
modmap+='-fmodule-file=Intrinsic.Diagnostic.StdTypes='+str(pcm)+'\n'
text=original[len(gmf):].replace('export module Extrinsic.Runtime.EditorWorkspaceSnapshots;','export module Extrinsic.Runtime.EditorWorkspaceSnapshots;\nimport Intrinsic.Diagnostic.StdTypes;')
run('imported-stdlib-owner',text,{'kind':'candidate shared standard declaration ownership; exact snapshot declarations, standard exports moved into separate owner; not production verified'})
