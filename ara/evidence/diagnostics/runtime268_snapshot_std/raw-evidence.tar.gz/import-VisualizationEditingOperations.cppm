// Read-only editor workspace and panel snapshots, including cached selections.
// Exposes copied presentation state without granting scene mutation access.
module;

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <vector>

export module Intrinsic.Diagnostic.ImportProbe;
import Extrinsic.Runtime.VisualizationEditingOperations;
export namespace IntrinsicProbe { struct Single { std::string Value; }; }
