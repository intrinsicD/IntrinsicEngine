// Read-only editor workspace and panel snapshots, including cached selections.
// Exposes copied presentation state without granting scene mutation access.
module;

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <vector>

export module Intrinsic.Diagnostic.SnapshotGroup;
import Extrinsic.ECS.Components.GeometrySources;
import Extrinsic.Runtime.EditorCommon;
import Extrinsic.Runtime.EditorWorkspaceAttachment;
import Extrinsic.Runtime.EditorProcessing;
import Extrinsic.Runtime.GeometryProcessingOperations;
import Extrinsic.Runtime.RenderRecipeEditingOperations;
import Extrinsic.Runtime.SceneEditingOperations;
import Extrinsic.Runtime.VisualizationEditingOperations;
namespace Extrinsic::Runtime { struct EditorWorkspaceSnapshotQueriesAccess; }
export namespace Extrinsic::Runtime {
    enum class EditorSelectedModelCacheSection : std::uint8_t
    {
        SelectedAnalysis,
        Visualization,
    };
    enum class EditorSelectedAnalysisCacheConsumer : std::uint8_t
    {
        Inspector,
        MeshDomainWindow,
        GraphDomainWindow,
        PointCloudDomainWindow,
    };
    struct EditorSelectedModelCacheKey
    {
        EditorSelectedModelCacheSection Section{
            EditorSelectedModelCacheSection::SelectedAnalysis};
        EditorSelectedAnalysisCacheConsumer SelectedAnalysisConsumer{
            EditorSelectedAnalysisCacheConsumer::Inspector};
        EditorVisualizationTarget VisualizationTarget{
            EditorVisualizationTarget::Entity};
        std::uint32_t PrimaryStableId{0u};
        std::vector<std::uint32_t> SelectedStableIds{};
        std::uint64_t SelectionGeneration{0u};
        std::uint64_t PrimitiveSelectionGeneration{0u};
        ECS::Components::GeometrySources::Domain SelectedDomain{
            ECS::Components::GeometrySources::Domain::None};
        std::size_t VertexCount{0u};
        std::size_t EdgeCount{0u};
        std::size_t HalfedgeCount{0u};
        std::size_t FaceCount{0u};
        std::size_t NodeCount{0u};
        std::uint64_t GeometryMetadataSignature{0u};
        std::uint64_t RenderHintSignature{0u};
        std::uint64_t VisualizationStateSignature{0u};
        std::uint64_t BindingGeneration{0u};
        std::uint64_t GeometryPresentationRecipeGeneration{0u};
        std::uint64_t DerivedJobStateSignature{0u};
        std::uint64_t CommandHistoryRevision{0u};
        std::uint64_t VisualizationRecipeRevision{0u};
        std::uint32_t ViewportWidth{0u};
        std::uint32_t ViewportHeight{0u};
        bool VisualizationCommandsAvailable{false};
        bool VisualizationRecipesAvailable{false};

        friend bool operator==(
            const EditorSelectedModelCacheKey&,
            const EditorSelectedModelCacheKey&) = default;
    };
    struct EditorSelectedAnalysisModel
    {
        EditorPropertyCatalogModel PropertyCatalog{};
        EditorGeometryPresentationModel GeometryPresentation{};
        EditorBoundRenderStateModel BoundState{};
        EditorTextureBakeControlsModel TextureBake{};
    };
    struct EditorSelectedAnalysisCacheEntry
    {
        bool Valid{false};
        EditorSelectedModelCacheKey Key{};
        EditorSelectedAnalysisModel Model{};
    };
    struct EditorVisualizationModelCacheEntry
    {
        bool Valid{false};
        EditorSelectedModelCacheKey Key{};
        EditorVisualizationModel Model{};
    };
    struct EditorSelectedModelCacheStats
    {
        std::uint32_t SelectedAnalysisCacheHits{0u};
        std::uint32_t SelectedAnalysisCacheMisses{0u};
        std::uint32_t VisualizationModelCacheHits{0u};
        std::uint32_t VisualizationModelCacheMisses{0u};
        std::uint32_t Invalidations{0u};
        std::uint32_t Entries{0u};
    };
extern "C++" {
    struct EditorSelectedModelCache
    {
        std::array<EditorSelectedAnalysisCacheEntry, 4u>
            SelectedAnalysis{};
        std::array<EditorVisualizationModelCacheEntry, 4u>
            Visualization{};
        EditorSelectedModelCacheStats Counters{};

        void Clear() noexcept;

        [[nodiscard]] EditorSelectedModelCacheStats Stats() const noexcept;
    };
}
extern "C++" {
    struct EditorWorkspaceSnapshotContext
    {
        EditorSceneEditingContext Scene{};
        EditorProcessingContext Geometry{};
        EditorVisualizationEditingContext Visualization{};
        EditorRenderRecipeEditingContext RenderRecipe{};
        EditorSelectedModelCache* SelectedModelCache{nullptr};
    };
}
    class EditorWorkspaceSnapshotQueries final
    {
    public:
        EditorWorkspaceSnapshotQueries() = default;

        [[nodiscard]] bool IsBound() const noexcept;

    private:
        std::shared_ptr<const EditorWorkspaceSnapshotContext> m_Context{};

        explicit EditorWorkspaceSnapshotQueries(
            std::shared_ptr<const EditorWorkspaceSnapshotContext> context);
        friend struct EditorWorkspaceSnapshotQueriesAccess;
        friend EditorWorkspaceSnapshotQueries
        BindEditorWorkspaceSnapshotQueries(
            EditorWorkspaceSnapshotContext context);
    };
}
