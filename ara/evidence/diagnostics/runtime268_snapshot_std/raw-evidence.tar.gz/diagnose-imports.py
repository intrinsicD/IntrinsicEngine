from pathlib import Path
import time
p=Path('/tmp/intrinsic-runtime268')
while not (p/'export-block.summary.json').exists():time.sleep(1)
exec((p/'diagnose.py').read_text().split('identity=')[0])
for label,imp in [('none','')]+[(x.split('.')[-1][:-1],x) for x in imports.splitlines()]:
 text=gmf+'export module Intrinsic.Diagnostic.ImportProbe;\n'+imp+'\nexport namespace IntrinsicProbe { struct Single { std::string Value; }; }\n'
 run('import-'+label,text,{'kind':'synthetic single-import string record','import':imp})
