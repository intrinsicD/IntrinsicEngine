// Read-only editor workspace and panel snapshots, including cached selections.
// Exposes copied presentation state without granting scene mutation access.
module;

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <vector>

export module Intrinsic.Diagnostic.SnapshotMember;
import Extrinsic.ECS.Components.GeometrySources;
import Extrinsic.Runtime.EditorCommon;
import Extrinsic.Runtime.EditorWorkspaceAttachment;
import Extrinsic.Runtime.EditorProcessing;
import Extrinsic.Runtime.GeometryProcessingOperations;
import Extrinsic.Runtime.RenderRecipeEditingOperations;
import Extrinsic.Runtime.SceneEditingOperations;
import Extrinsic.Runtime.VisualizationEditingOperations;
export namespace Extrinsic::Runtime { struct Single { EditorEntityRow Value{}; }; }
