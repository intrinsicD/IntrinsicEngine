from pathlib import Path
import json,re,subprocess,hashlib
p=Path('/tmp/intrinsic-runtime268');fixed=json.loads((p/'frozen-dependencies.json').read_text());out=p/'frozen-module-info';out.mkdir(exist_ok=True)
flags=['-fmodule-file='+n+'='+x['path'] for n,x in fixed.items()];graph={}
for n,x in fixed.items():
 r=subprocess.run(['/usr/bin/clang++-23','-module-file-info',x['path']]+flags,capture_output=True,text=True)
 (out/(n.replace(':','-')+'.txt')).write_text(r.stdout+r.stderr);assert r.returncode==0,(n,r.stderr)
 graph[n]=re.findall(r"Imports module '([^']+)':",r.stdout)
 assert hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256']
for n in graph:
 if n=='Extrinsic.Runtime.EditorWorkspaceSnapshots':continue
 todo=list(graph[n]);seen=set()
 while todo:
  q=todo.pop()
  assert q!='Extrinsic.Runtime.EditorWorkspaceSnapshots',(n,q)
  assert q in graph,(n,q)
  if q in seen:continue
  seen.add(q);todo.extend(graph[q])
(p/'frozen-module-imports.json').write_text(json.dumps({'imports':graph,'no_prerequisite_depends_on_snapshot':True,'source':'Clang module-file-info on each frozen BMI with explicit frozen dependency maps'},indent=2)+'\n')
print('Validated imports from',len(graph),'frozen BMIs; no prerequisite imports snapshot.')
