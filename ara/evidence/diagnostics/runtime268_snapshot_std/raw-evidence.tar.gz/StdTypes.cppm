// Read-only editor workspace and panel snapshots, including cached selections.
// Exposes copied presentation state without granting scene mutation access.
module;

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <vector>

export module Intrinsic.Diagnostic.StdTypes;
export namespace std { using std::array; using std::size_t; using std::uint8_t; using std::uint32_t; using std::uint64_t; using std::shared_ptr; using std::optional; using std::nullopt; using std::string; using std::vector; }
