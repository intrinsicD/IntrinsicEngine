// Read-only editor workspace and panel snapshots, including cached selections.
// Exposes copied presentation state without granting scene mutation access.
module;

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <vector>

export module Intrinsic.Diagnostic.SnapshotGroup;
import Extrinsic.ECS.Components.GeometrySources;
import Extrinsic.Runtime.EditorCommon;
import Extrinsic.Runtime.EditorWorkspaceAttachment;
import Extrinsic.Runtime.EditorProcessing;
import Extrinsic.Runtime.GeometryProcessingOperations;
import Extrinsic.Runtime.RenderRecipeEditingOperations;
import Extrinsic.Runtime.SceneEditingOperations;
import Extrinsic.Runtime.VisualizationEditingOperations;
namespace Extrinsic::Runtime { struct EditorWorkspaceSnapshotQueriesAccess; }
export namespace Extrinsic::Runtime {
    struct EditorDomainWindowModel
    {
        EditorDomainWindowKind Kind{EditorDomainWindowKind::Mesh};
        ECS::Components::GeometrySources::Domain ExpectedDomain{
            ECS::Components::GeometrySources::Domain::Mesh};
        bool HasSelectedEntity{false};
        EditorEntityRow SelectedEntity{};
        std::uint32_t SelectedStableId{0u};
        ECS::Components::GeometrySources::Domain SelectedDomain{
            ECS::Components::GeometrySources::Domain::None};
        bool DomainMatches{false};
        EditorRenderHintModel RenderHints{};
        bool PrimitiveViewControlsAvailable{false};
        bool HasPrimitiveViewSettings{false};
        EditorPrimitiveViewSettings PrimitiveView{};
        bool VisualizationControlsAvailable{false};
        bool VisualizationTargetAvailable{false};
        EditorVisualizationTarget VisualizationTarget{
            EditorVisualizationTarget::Entity};
        EditorVisualizationModel Visualization{};
        EditorPropertyCatalogModel PropertyCatalog{};
        EditorBoundRenderStateModel BoundState{};
        EditorTextureBakeControlsModel TextureBake{};
        EditorGeometryProcessingModel Processing{};
        EditorPrimitiveDetailModel Primitive{};
        std::vector<EditorDiagnostic> Diagnostics{};
    };
}
