from pathlib import Path
import collections,hashlib,json,os,shlex,subprocess,sys,time,yaml
ROOT=Path('/home/alex/Documents/IntrinsicEngine');P=Path('/tmp/intrinsic-runtime268');BASE=Path('/dev/shm/intrinsic-runtime268');SOURCE=BASE/'source';BUILD=BASE/'focused';OUTPUT=P/'measurement'
sys.path[:0]=[str(ROOT/'tools/analysis'),str(ROOT/'tools/benchmark')]
from benchmark_compile_iteration import dependency_snapshot,command,write_json
from seal_benchmark_results import canonicalize
from validate_benchmark_results import validate_result_data
manifest_path=ROOT/'benchmarks/ci/manifests/workspace_snapshot_std.yaml';manifest=yaml.safe_load(manifest_path.read_text());params=manifest['params']
assert not OUTPUT.exists();OUTPUT.mkdir();BUILD.mkdir(exist_ok=True)
rows=json.loads((P/'before-commands.json').read_text());consumer=json.loads((P/'consumer-command.json').read_text())
newrow=next(x for x in json.loads((ROOT/'build/ci/compile_commands.json').read_text()) if x['file'].endswith('/Runtime.EditorWorkspaceSnapshots.Std.cppm'))
a=shlex.split(newrow['command']);newrow['modmap']=(Path(newrow['directory'])/next(x[1:] for x in a if x.startswith('@'))).read_text().splitlines()
order=['Runtime.EditorWorkspaceSnapshots.cppm','Runtime.EditorWorkspaceSnapshots.Public.cpp','Runtime.EditorWorkspaceSnapshots.Models.cpp','Runtime.EditorFeatureContextAdapters.cpp','Runtime.EditorWorkspaceSession.cpp']
assert {Path(r['file']).name for r in rows}==set(order)
rows.sort(key=lambda r:order.index(Path(r['file']).name))
current={r['file']:r for r in json.loads((ROOT/'build/ci/compile_commands.json').read_text())}
after_rows=[]
for old in rows+[consumer]:
    new=current[old['file']];assert new['command']==old['command'],old['file']
    args=shlex.split(new['command']);assert sum(a.startswith('@') for a in args)==1
    new['modmap']=(Path(new['directory'])/next(a[1:] for a in args if a.startswith('@'))).read_text().splitlines()
    old_names={a.split('=',2)[1] for a in old['modmap'] if a.startswith('-fmodule-file=')}
    new_names={a.split('=',2)[1] for a in new['modmap'] if a.startswith('-fmodule-file=')}
    assert new_names==old_names|{'Extrinsic.Runtime.Private.EditorSnapshotStd'},old['file']
    after_rows.append(new)
assert sum(any(a.startswith('-fmodule-output=') for a in r['modmap']) for r in rows)==1
assert not any(a.startswith('-fmodule-output=') for a in consumer['modmap'])
fixed=json.loads((P/'frozen-dependencies.json').read_text());pkgroot=ROOT/'external/vcpkg-installed/ci';packages=dependency_snapshot(pkgroot)
assert all(not Path(x['path']).is_relative_to(BUILD) for x in fixed.values())
imports=json.loads((P/'frozen-module-imports.json').read_text());assert imports['no_prerequisite_depends_on_snapshot']
ident={'manifest_sha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest(),'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'compiler':command(['/usr/bin/clang++-23','--version'],ROOT),'frozen_prerequisites':fixed,'packages':packages,'before_commands':rows,'after_owner_command':newrow,'consumer_command':consumer,'actual_after_commands':after_rows,'frozen_import_graph':imports,'source_path':str(SOURCE),'output_path':str(BUILD)}
write_json(OUTPUT/'identity.json',ident)
assert all(shlex.split(r['command'])[0]=='/usr/bin/clang++-23' for r in rows+[newrow,consumer])
counts=collections.Counter()
for position,arm in enumerate(params['sample_order'],1):
 assert not command(['git','status','--porcelain'],SOURCE)
 rev=params['source_revisions'][arm];subprocess.run(['git','checkout','--detach',rev],cwd=SOURCE,check=True,capture_output=True)
 assert command(['git','rev-parse','HEAD'],SOURCE).strip()==rev
 counts[arm]+=1;attempt=f'{position:02d}-{arm}-{counts[arm]}';dest=OUTPUT/attempt;dest.mkdir();print('START',attempt,flush=True)
 for name,x in fixed.items():
  data=Path(x['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==x['sha256'],name
 assert dependency_snapshot(pkgroot)==packages
 selected=[newrow]+after_rows if arm=='after' else rows+[consumer]
 for r in selected:
  src=SOURCE/Path(r['file']).relative_to(ROOT);src.read_bytes()
 for f in BUILD.iterdir():
  assert f.is_file();f.unlink()
 details={};timings={};rss={};started=time.perf_counter()
 assert len({Path(r['file']).stem for r in selected})==len(selected)
 for idx,row in enumerate(selected):
  rel=Path(row['file']).relative_to(ROOT);label=rel.stem.replace('Runtime.EditorWorkspaceSnapshots','snapshot')
  args=shlex.split(row['command']);out=BUILD/(label+'.o');args[args.index('-o')+1]=str(out);args[args.index('-c')+1]=str(SOURCE/rel)
  for arg in args:
   assert not arg.startswith(('-MD','-MMD','-MF','-MT','-MQ','-MJ','--serialize-diagnostics','-serialize-diagnostics','-fmodules-cache-path','-fmodule-output=','-ftime-trace','-fprebuilt-module-path')),arg
  args=[x if ('ENGINE_ROOT_DIR=' in x or str(ROOT/'external')+'/' in x) else x.replace(str(ROOT)+'/',str(SOURCE)+'/') for x in args]
  for arg in args:
   assert str(ROOT) not in arg or 'ENGINE_ROOT_DIR=' in arg or str(ROOT/'external')+'/' in arg,arg
   if arg.startswith('-I'):assert Path(arg[2:]).is_absolute(),arg
  for opt in ('-isystem','-iquote'):
   for j,a in enumerate(args[:-1]):
    if a==opt:assert Path(args[j+1]).is_absolute(),args[j+1]
  source_is_owner=row is newrow;source_is_primary=rel.name=='Runtime.EditorWorkspaceSnapshots.cppm'
  mp=dest/(label+'.modmap');lines=[]
  for line in row['modmap']:
   if line.startswith('-fmodule-output='):
    assert source_is_owner or source_is_primary
    lines.append('-fmodule-output='+str(BUILD/('std.pcm' if source_is_owner else 'snapshot.pcm')));continue
   if line=='-x c++-module':
    assert source_is_owner or source_is_primary
    lines.append(line);continue
   assert line.startswith('-fmodule-file='),line
   name=line[len('-fmodule-file='):].split('=',1)[0]
   if name=='Extrinsic.Runtime.EditorWorkspaceSnapshots':loc=BUILD/'snapshot.pcm'
   elif name=='Extrinsic.Runtime.Private.EditorSnapshotStd':loc=BUILD/'std.pcm'
   else:loc=Path(fixed[name]['path'])
   lines.append('-fmodule-file='+name+'='+str(loc))
  assert len(lines)==len(set(lines)),label
  mp.write_text('\n'.join(lines)+'\n');assert sum(x.startswith('@') for x in args)==1;mi=next(i for i,x in enumerate(args) if x.startswith('@'));args[mi]='@'+str(mp)
  # No launchers, tracing, configure, dependency scanning or linking in this focused replay.
  t=time.perf_counter();load=os.getloadavg()
  with (dest/(label+'.log')).open('w') as log:
   result=subprocess.run(['/usr/bin/time','-q','-f','{"cpu_user_s":%U,"cpu_system_s":%S,"max_single_process_rss_kib":%M}','-o',str(dest/(label+'.time.json')),'--']+args,cwd=row['directory'],env=dict(os.environ,CCACHE_DISABLE='1'),stdout=log,stderr=subprocess.STDOUT)
  elapsed=(time.perf_counter()-t)*1000;record=json.loads((dest/(label+'.time.json')).read_text().splitlines()[-1]);record.update(command=args,source=str(rel),source_sha256=hashlib.sha256((SOURCE/rel).read_bytes()).hexdigest(),wall_ms=elapsed,exit_code=result.returncode,loadavg_before=load)
  write_json(dest/(label+'.execution.json'),record);assert result.returncode==0,(attempt,label)
  details[label]=record;timings[label]=elapsed;rss[label]=record['max_single_process_rss_kib']*1024
 end_to_end=(time.perf_counter()-started)*1000
 consumer_label=next(reversed(details));engine_total=sum(v for k,v in timings.items() if k!=consumer_label)
 bmis={f.name:f.stat().st_size for f in BUILD.glob('*.pcm')}
 raw={'benchmark_id':manifest['benchmark_id'],'method':manifest['method'],'dataset':manifest['dataset'],'backend':'external_baseline','commit':rev,'status':'passed','metrics':{'build_time_ms':timings,'total_time_ms':{'runtime_producers':engine_total,'runtime_and_consumer':sum(timings.values())},'memory_peak_bytes':rss,'sample_count':1},'diagnostics':{'arm':arm,'position':position,'sample':counts[arm],'scenarios':details,'emitted_bmi_bytes':bmis,'instrumented_sequence_wall_ms':end_to_end,'source_clean_before_after':True,'scope':params['scope']}}
 assert not command(['git','status','--porcelain'],SOURCE)
 for name,x in fixed.items():assert hashlib.sha256(Path(x['path']).read_bytes()).hexdigest()==x['sha256'],name
 assert dependency_snapshot(pkgroot)==packages
 write_json(dest/'raw-result.json',raw)
 sealed=canonicalize(raw,manifest_path=manifest_path,manifest=manifest,manifests_root=ROOT/'benchmarks',run_id=OUTPUT.name+'-runtime268',attempt_id=attempt,source_state='clean_commit',source_revision=rev,claim_eligible=False,snapshot_sha256=None,diff_sha256=None)
 resultpath=OUTPUT/'results'/(attempt+'.json');resultpath.parent.mkdir(exist_ok=True)
 _,errors=validate_result_data(sealed,resultpath,{manifest['benchmark_id']:(manifest_path,manifest)},ROOT/'benchmarks');assert not errors,errors;write_json(resultpath,sealed)
 print('COMPLETE',attempt,'runtime',round(engine_total/1000,3),'consumer',round(timings[consumer_label]/1000,3),flush=True)

assert dict(counts)=={'before':5,'after':5}
print('All ten focused samples complete.',flush=True)
