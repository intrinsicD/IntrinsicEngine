from pathlib import Path
import time
p=Path('/tmp/intrinsic-runtime268')
while not (p/'member-presentation.summary.json').exists():time.sleep(1)
exec((p/'diagnose.py').read_text().split('identity=')[0])
for label,body in [('runtime-empty','export namespace Extrinsic::Runtime {}'),('runtime-scalar','export namespace Extrinsic::Runtime { struct Tiny { int value; }; }'),('unrelated-scalar','export namespace IntrinsicProbe { struct Tiny { int value; }; }'),('runtime-function','export namespace Extrinsic::Runtime { int tiny(); }')]:
 text=gmf+'export module Intrinsic.Diagnostic.NamespaceProbe;\n'+imports+'\n'+body+'\n'
 run(label,text,{'kind':'synthetic namespace/declaration control'})
