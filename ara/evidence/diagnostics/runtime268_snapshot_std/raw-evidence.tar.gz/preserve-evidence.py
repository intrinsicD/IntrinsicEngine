from pathlib import Path
import hashlib,json,shutil,tarfile,subprocess
root=Path('/home/alex/Documents/IntrinsicEngine');p=Path('/tmp/intrinsic-runtime268');out=root/'ara/evidence/diagnostics/runtime268_snapshot_std'
out.mkdir(parents=True,exist_ok=True)
for name in ['summary.json','verification.json','frozen-protocol.json','frozen-protocol.initial.json','diagnostic-custody-note.json','duplicate-declarations.summary.json','imports.summary.json','measurement.log','results-review.txt','results-review-prompt.txt']:
 shutil.copy2(p/name,out/name)
for f in sorted((p/'measurement/results').glob('*.json')):
 (out/'results').mkdir(exist_ok=True);shutil.copy2(f,out/'results'/f.name)
assert len(list((out/'results').glob('*.json')))==10
archive=out/'raw-evidence.tar.gz';files=[f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.suffix not in ('.o','.pcm','.pyc')]
with tarfile.open(archive,'w:gz') as tar:
 for f in sorted(files):tar.add(f,arcname=str(f.relative_to(p)),recursive=False)
hashes={str(f.relative_to(p)):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in files}
tools=['tools/analysis/benchmark_compile_iteration.py','tools/benchmark/seal_benchmark_results.py','tools/benchmark/validate_benchmark_results.py']
index={'source_before':'4fa241cc250113d7d1b5cc8bbd0b54e9c82f6aed','source_after':'ca164c10cf20d1b037ac2c116194c1839ec6bb3d','manifest_commit':'01e92cdf6','benchmark_id':'build.workspace_snapshot_std.v1','manifest_path':'benchmarks/ci/manifests/workspace_snapshot_std.yaml','manifest_sha256':hashlib.sha256((root/'benchmarks/ci/manifests/workspace_snapshot_std.yaml').read_bytes()).hexdigest(),'runner_sha256':hashlib.sha256((p/'measure-focused.py').read_bytes()).hexdigest(),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_files':hashes,'canonical_helpers':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in tools},'production_source_delta':{'added_files':1,'added_modules':1,'net_cpp_lines':23,'net_src_lines_including_cmake':24},'portability':'Scratch paths identify the original execution; rebuild prerequisite BMIs from exact source/compiler/dependencies to replay. Prebuilt BMIs and object files excluded.','retained_failed_attempt':'failed-preflight/; no compiler or timed sample executed before protocol correction','scratch_cleanup':'Recorded separately after all evidence is saved.'}
(out/'evidence-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(len(files),'archived files;',archive.stat().st_size,'archive bytes')
