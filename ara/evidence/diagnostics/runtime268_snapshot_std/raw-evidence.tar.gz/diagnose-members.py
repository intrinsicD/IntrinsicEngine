from pathlib import Path
import time
p=Path('/tmp/intrinsic-runtime268')
while not (p/'prepared.summary.json').exists():time.sleep(1)
exec((p/'diagnose.py').read_text().split('identity=')[0])
run('without-empty-member-initializers',original.replace('{};', ';'),{'kind':'synthetic removal of empty member initializers only; scalar/enumerator defaults retained, no feature parity'})
run('declared-equality',original.replace('const EditorSelectedModelCacheKey&) = default;', 'const EditorSelectedModelCacheKey&);'),{'kind':'synthetic equality declaration only; no link implementation'})
for label,typ in [('string','std::string'),('vector','std::vector<int>'),('entity','EditorEntityRow'),('transform','EditorTransformModel'),('catalog','EditorPropertyCatalogModel'),('presentation','EditorGeometryPresentationModel')]:
 text=gmf+'export module Intrinsic.Diagnostic.SnapshotMember;\n'+imports+'\nexport namespace Extrinsic::Runtime { struct Single { '+typ+' Value{}; }; }\n'
 run('member-'+label,text,{'kind':'synthetic one-member record','type':typ})
