from pathlib import Path
import json,re,subprocess,time,shlex,hashlib
root=Path('/home/alex/Documents/IntrinsicEngine');p=Path('/tmp/intrinsic-runtime268');out=Path('/dev/shm/intrinsic-runtime268');out.mkdir(exist_ok=True)
source=root/'src/runtime/Editor/Runtime.EditorWorkspaceSnapshots.cppm';original=source.read_text()
cmd=next(x for x in json.loads((root/'build/ci/compile_commands.json').read_text()) if x['file']==str(source));base=shlex.split(cmd['command']);cwd=Path(cmd['directory'])
mi=next(i for i,a in enumerate(base) if a.startswith('@'));modmap=(cwd/base[mi][1:]).read_text();srcidx=base.index('-c')+1
blocks={}
for m in re.finditer(r'^    (?:struct|class|enum class) (\w+)[^\n]*\n    \{',original,re.M):
 start=m.start();op=original.index('{',start);depth=1;i=op+1
 while depth:
  if original[i]=='{':depth+=1
  elif original[i]=='}':depth-=1
  i+=1
 assert original[i]==';';blocks[m[1]]=original[start:i+1]
imports='\n'.join(re.findall(r'^import [^;]+;',original,re.M));gmf=original.split('export module ',1)[0]
global_types={'EditorSelectedModelCache','EditorWorkspaceSnapshotRequest','EditorWorkspaceSnapshot','EditorWorkspaceSnapshotContext'}
def synthetic(names):
 needed=set(names)
 while True:
  new=needed|{n for n in blocks if any(re.search(r'\b'+n+r'\b',blocks[q]) for q in needed)}
  if new==needed:break
  needed=new
 body='\n'.join(('extern "C++" {\n'+b+'\n}' if n in global_types else b) for n,b in blocks.items() if n in needed)
 return gmf+'export module Intrinsic.Diagnostic.SnapshotGroup;\n'+imports+'\nnamespace Extrinsic::Runtime { struct EditorWorkspaceSnapshotQueriesAccess; }\nexport namespace Extrinsic::Runtime {\n'+body+'\n}\n',sorted(needed)
def run(name,text,scope):
 src=p/(name+'.cppm');src.write_text(text);pcm=out/(name+'.pcm');obj=out/(name+'.o');mp=p/(name+'.modmap');tr=p/(name+'.trace.json');tm=p/(name+'.time.txt')
 mp.write_text('\n'.join('-fmodule-output='+str(pcm) if a.startswith('-fmodule-output=') else a for a in modmap.splitlines())+'\n')
 args=base.copy();args[mi]='@'+str(mp);args[srcidx]=str(src);args[args.index('-o')+1]=str(obj);args+=['-ftime-trace='+str(tr)]
 driver=subprocess.run(args+['-###'],cwd=cwd,capture_output=True,text=True);(p/(name+'.driver.txt')).write_text(driver.stderr)
 start=time.perf_counter()
 with (p/(name+'.log')).open('w') as f:r=subprocess.run(['/usr/bin/time','-v','-o',str(tm)]+args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 wall=time.perf_counter()-start
 d={'name':name,'scope':scope,'command':args,'cwd':str(cwd),'source_sha256':hashlib.sha256(text.encode()).hexdigest(),'outer_wall_seconds':wall,'returncode':r.returncode,'driver_cc1_jobs':driver.stderr.count('"-cc1"')}
 if r.returncode==0:
  trace=json.loads(tr.read_text());d['totals']={x['name']:x['dur']/1e6 for x in trace['traceEvents'] if x['name'].startswith('Total ') and 'dur'in x};d['pcm_bytes']=pcm.stat().st_size
 (p/(name+'.summary.json')).write_text(json.dumps(d,indent=2)+'\n')
 print(name,r.returncode,round(wall,3),d.get('pcm_bytes'),round(d.get('totals',{}).get('Total WriteAST',0),3),flush=True)
 for f in [pcm,obj]:f.unlink(missing_ok=True)
 if r.returncode:raise RuntimeError((p/(name+'.log')).read_text()[-4000:])
identity={'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_sha256':hashlib.sha256(original.encode()).hexdigest(),'compiler_version':subprocess.check_output([base[0],'--version'],text=True),'original_command':cmd,'original_modmap':modmap,'scope':'Diagnostic isolation, not a feature-equivalent benchmark. Same GMF and direct imports in all synthetic groups; exact emitted declaration closure recorded.'}
(p/'diagnostic-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
run('real',original,{'kind':'exact original interface'})
for label,names in [('imports',[]),('inspector',['EditorInspectorModel']),('domain',['EditorDomainWindowModel']),('cache',['EditorSelectedModelCache']),('snapshot',['EditorWorkspaceSnapshot']),('context',['EditorWorkspaceSnapshotContext']),('queries',['EditorWorkspaceSnapshotQueries']),('prepared',['EditorWorkspaceSnapshotPreparedFrame'])]:
 text,closure=synthetic(names);run(label,text,{'kind':'synthetic own-declaration closure','declarations':closure})
