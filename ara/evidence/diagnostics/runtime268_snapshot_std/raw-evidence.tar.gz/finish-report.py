from pathlib import Path
import json
p=Path('/tmp/intrinsic-runtime268');s=json.loads((p/'summary.json').read_text());b=s['times_s']['before'];a=s['times_s']['after']
text='''# RUNTIME-268 — Shared standard declarations for workspace snapshots

## Decision and measured scope

Keep the narrow declaration-owner change. In this retained local five-sample-per-arm
comparison, the median snapshot-plus-owner compilation changes from **{before:.3f}
to {after:.3f} seconds ({reduction:.1f}% lower)**. The affected runtime producer
subtotal changes from **{runtime_before:.3f} to {runtime_after:.3f} seconds**.
The real Sandbox consumer's ranges overlap; its small median difference establishes
no consumer improvement or regression. These are focused serial compile-command
observations, not whole-engine, parallel-build, runtime or cross-host results.
All ten canonical records remain `claim_eligible: false`; C99 records only this
bounded local observation.

`build.workspace_snapshot_std.v1`, exact sources `4fa241cc2` → `ca164c10c`;
manifest committed at `01e92cdf6`. ABBAABBAAB, five samples per arm, Clang23 Debug
canonical ci flags, one compiler at a time, fixed detached source/output paths,
cache/launchers/tracing off. The candidate pays for the added standard-owner
compilation before compiling the same six files. Configure, scanning, linking,
tests and all other compilation are excluded. Runtime plus consumer totals are
sums of per-command walls; outer instrumentation time is separate.

All six common commands match byte-for-byte before path projection. The after maps
are captured from actual CMake output and differ only by the added standard owner.
232 frozen prerequisite BMI hashes and the 1,728-file package fingerprint are
checked before/after every sample. Compiler-inspected module metadata verifies
that none of the frozen prerequisites (other than the unused old snapshot copy)
imports the snapshot, including transitively. Every sampled consumer uses the
newly emitted snapshot BMI and, in the candidate, the newly emitted standard BMI.

Prerequisites originate from ci with Vulkan/GLFW configured, distinct from earlier
Null/headless timed cohorts; there is no GPU execution. Inputs are pre-read, but
normal desktop filesystem/compiler first-use caches, CPU affinity, governor and
turbo are uncontrolled. No competing builds/tests ran during sampling. Every
measured sample is retained, including the slow first baseline. No statistical
significance, publication-grade eligibility or stable future speedup is asserted.

## Timing observations

Seconds, median [minimum–maximum]. The combined snapshot row charges the new owner;
the primary-only row is shown for attribution, not as the headline saving.
Subtotal rows are medians of each sample's summed walls, not sums of the
per-command medians.

| Producer or subtotal | Before | After |
|---|---:|---:|
'''.format(before=b['snapshot_with_owner']['median'],after=a['snapshot_with_owner']['median'],reduction=s['median_time_reduction_percent']['snapshot_with_owner'],runtime_before=b['runtime_producers']['median'],runtime_after=a['runtime_producers']['median'])
def cell(x):return f"{x['median']:.3f} [{x['min']:.3f}–{x['max']:.3f}]"
for k,label in [('snapshot_with_owner','Snapshot + added standard owner'),('snapshot','Snapshot primary only'),('snapshot.Public','Snapshot Public implementation'),('snapshot.Models','Snapshot Models implementation'),('Runtime.EditorFeatureContextAdapters','Context adapters'),('Runtime.EditorWorkspaceSession','Workspace session'),('Sandbox.PanelSupport','Sandbox PanelSupport consumer'),('runtime_producers','Runtime subtotal, including new owner'),('runtime_and_consumer','Runtime + consumer sum')]:text+=f'| {label} | {cell(b[k])} | {cell(a[k])} |\n'
text+=f"\nThe candidate's standard owner alone is {cell(a['snapshot.Std'])} seconds.\n\n"
text+='| Attempt | Snapshot + owner | Runtime subtotal | Sandbox consumer |\n|---|---:|---:|---:|\n'
for r in s['samples']:
 t=r['times_s'];text+=f"| {r['attempt']} | {t['snapshot_with_owner']:.3f} | {t['runtime_producers']:.3f} | {t['Sandbox.PanelSupport']:.3f} |\n"
text+=f"\nChanged BMI storage totals {int(s['bmi_bytes']['before']['median']):,} → {int(s['bmi_bytes']['after']['median']):,} bytes (snapshot versus snapshot **plus** new owner; constant within each arm). This is emitted storage for these changed modules, not the whole prerequisite cache, peak process memory or engine runtime memory. Per-command maximum single-process RSS and user/system CPU records are retained in the results.\n\n"
text+=(p/'report-body.md').read_text()
text+='''
## Evidence

[Manifest](../../../benchmarks/ci/manifests/workspace_snapshot_std.yaml) ·
[All samples, ranges and recalculation](../diagnostics/runtime268_snapshot_std/summary.json) ·
[Source/protocol/archive index](../diagnostics/runtime268_snapshot_std/evidence-index.json) ·
[Verification](../diagnostics/runtime268_snapshot_std/verification.json) ·
[Claude results review](../diagnostics/runtime268_snapshot_std/results-review.txt) ·
[Raw traces, commands, controls, logs and scripts](../diagnostics/runtime268_snapshot_std/raw-evidence.tar.gz).
'''
(p/'report.md').write_text(text)
