from pathlib import Path
import json,subprocess,signal,time
p=Path('/tmp/intrinsic-runtime268');d=json.loads((p/'real.summary.json').read_text());args=d['command']
# Only the debugger's newly spawned inferior receives this interrupt.
cmd=['gdb','--batch','-ex','set pagination off','-ex','set debuginfod enabled off','-ex','run','-ex','bt 24','-ex','continue','--args']+args
with (p/'compiler-stack.log').open('w') as f:
 r=subprocess.Popen(cmd,cwd=d['cwd'],stdout=f,stderr=subprocess.STDOUT)
 time.sleep(8)
 if r.poll() is None:r.send_signal(signal.SIGINT)
 code=r.wait()
print('Debugger diagnostic exit:',code)
