from pathlib import Path
p=Path('/tmp/intrinsic-runtime268')
exec((p/'diagnose.py').read_text().split('identity=')[0])
base+=['-Wdecls-in-multiple-modules']
run('duplicate-declarations',original,{'kind':'exact source with compiler duplication warning enabled'})
