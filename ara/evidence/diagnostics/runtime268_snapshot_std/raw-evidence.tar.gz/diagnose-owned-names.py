from pathlib import Path
import subprocess,time
p=Path('/tmp/intrinsic-runtime268')
exec((p/'diagnose.py').read_text().split('identity=')[0])
lib=p/'OwnedStd.cppm';lib.write_text(gmf+'module Extrinsic.Runtime.EditorWorkspaceSnapshots:Std;\nnamespace Extrinsic::Runtime::SnapshotStd { using std::array; using std::size_t; using std::uint8_t; using std::uint32_t; using std::uint64_t; using std::shared_ptr; using std::optional; using std::nullopt; using std::string; using std::vector; }\n')
args=base.copy();args.remove(args[mi]);pcm=out/'OwnedStd.pcm';args+=['-fmodule-output='+str(pcm)];args[args.index('-c')+1]=str(lib);args[args.index('-o')+1]=str(out/'OwnedStd.o')
start=time.perf_counter()
with (p/'owned-stdlib.log').open('w') as f:r=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
print('Owned std',r.returncode,round(time.perf_counter()-start,3),flush=True)
assert r.returncode==0,(p/'owned-stdlib.log').read_text()
modmap+='-fmodule-file=Extrinsic.Runtime.EditorWorkspaceSnapshots:Std='+str(pcm)+'\n'
text=original[len(gmf):].replace('export module Extrinsic.Runtime.EditorWorkspaceSnapshots;','export module Extrinsic.Runtime.EditorWorkspaceSnapshots;\nimport :Std;').replace('std::','SnapshotStd::')
run('owned-stdlib-partition',text,{'kind':'private partition with using-declarations at owned namespace; no declarations added to std; snapshot types unchanged'})
