from pathlib import Path
import json,statistics,hashlib
p=Path('/tmp/intrinsic-runtime268');rows=[]
for f in sorted((p/'measurement/results').glob('*.json')):
 d=json.loads(f.read_text());m=d['metrics'];s=d['diagnostics'];t=m['build_time_ms'];assert d['execution_status']=='passed' and d['claim_eligible'] is False
 assert m['sample_count']==1 and all(x['exit_code']==0 for x in s['scenarios'].values())
 assert m['total_time_ms']['runtime_and_consumer']==sum(t.values())
 assert m['total_time_ms']['runtime_producers']==sum(v for k,v in t.items() if k!='Sandbox.PanelSupport')
 for k,v in s['scenarios'].items():
  assert t[k]==v['wall_ms']
  execution=json.loads((p/'measurement'/d['attempt_id']/(k+'.execution.json')).read_text());assert execution==v
 row={'attempt':d['attempt_id'],'arm':s['arm'],'source':d['source']['revision'],'times_s':{k:v/1000 for k,v in t.items()},'bmi_bytes':s['emitted_bmi_bytes'],'rss_bytes':m['memory_peak_bytes']}
 row['times_s'].update({k:v/1000 for k,v in m['total_time_ms'].items()})
 row['times_s']['snapshot_with_owner']=sum(v/1000 for k,v in t.items() if k in ('snapshot','snapshot.Std'))
 row['bmi_total_bytes']=sum(s['emitted_bmi_bytes'].values());rows.append(row)
assert len(rows)==10 and sum(r['arm']=='before' for r in rows)==5
assert [r['arm'] for r in rows]==['before','after','after','before','before','after','after','before','before','after']
def stats(xs):return {'samples':xs,'median':statistics.median(xs),'min':min(xs),'max':max(xs)}
summary={'benchmark_id':'build.workspace_snapshot_std.v1','claim_eligible':False,'scope':'Serial focused producer replay; all candidate declaration-owner cost included. No full-build or statistical/runtime claim.','samples':rows,'times_s':{},'bmi_bytes':{},'rss_bytes':{}}
for arm in ('before','after'):
 cohort=[r for r in rows if r['arm']==arm]
 summary['times_s'][arm]={k:stats([r['times_s'][k] for r in cohort]) for k in cohort[0]['times_s']}
 summary['bmi_bytes'][arm]=stats([r['bmi_total_bytes'] for r in cohort])
 summary['rss_bytes'][arm]={k:stats([r['rss_bytes'][k] for r in cohort]) for k in cohort[0]['rss_bytes']}
summary['median_time_reduction_percent']={k:100*(1-summary['times_s']['after'][k]['median']/v['median']) for k,v in summary['times_s']['before'].items()}
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for k,v in summary['times_s']['before'].items():
 a=summary['times_s']['after'][k];print(k, f"{v['median']:.3f} ({v['min']:.3f}-{v['max']:.3f}) -> {a['median']:.3f} ({a['min']:.3f}-{a['max']:.3f}); {summary['median_time_reduction_percent'][k]:.1f}%")
print('BMI',summary['bmi_bytes'])
