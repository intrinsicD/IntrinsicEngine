from pathlib import Path
R=Path('/home/alex/Documents/IntrinsicEngine')
def read(f): return (R/f).read_text()
def write(f,s): (R/f).write_text(s)
base='src/app/Sandbox/Editor/'
h=read(base+'Sandbox.PanelSupport.hpp')
a=h.index('    using SandboxPointCloudConsolidationPanelConfig =');b=h.index('    struct SandboxParameterizationUvPane',a)
declarations=h[a:b];h=h[:a]+h[b:]
proto='    [[nodiscard]] bool IsSupportedPointCloudConsolidationStrategy(\n        Runtime::PointCloudConsolidationStrategy strategy) noexcept;\n';assert proto in h;h=h.replace(proto,'');declarations+=proto
h=h.replace('extern "C++"\n{\nnamespace Extrinsic::Sandbox::Editor', 'extern "C++"\n{\nnamespace Extrinsic::Runtime\n{\n    struct EditorPointCloudServicePreparedFrame;\n}\n\nnamespace Extrinsic::Sandbox::Editor',1)
h=h.replace('const Runtime::EditorPointCloudServicePreparedFrame& pointCloudService','Runtime::EditorPointCloudServicePreparedFrame& pointCloudService').replace('Runtime::EditorPointCloudServicePreparedFrame PointCloudService{};','// Borrows shell-owned frame storage for the current draw visit.\n            const Runtime::EditorPointCloudServicePreparedFrame* PointCloudService{nullptr};').replace('            bool ClusteringAvailable{false};\n','').replace('            bool PointCloudConsolidationAvailable{false};\n','')
h=h.replace('// View data is copied, but command handles borrow live runtime services and\n        // remain valid only inside the prepared-frame visitor that supplies them.','// Most view data is copied; the point-cloud service frame and live command\n        // handles are borrowed only for the prepared-frame draw visit.')
write(base+'Sandbox.PanelSupport.hpp',h)
write(base+'Sandbox.PointCloudConsolidationPanel.hpp','''// Consolidation action/view records shared by its method panel and integration tests.\n// Include after runtime imports and Sandbox.PanelSupport.hpp; these declarations\n// stay out of unrelated panel consumers. Definitions live in MethodPanels.cpp.\n#pragma once\n\nextern "C++"\n{\nnamespace Extrinsic::Sandbox::Editor\n{\n'''+declarations+'}\n}\n')
s=read(base+'Sandbox.PanelSupport.cpp');a=s.index('        [[nodiscard]] bool IsSupportedPointCloudConsolidationStrategy(');b=s.index('        [[nodiscard]] const char* ParameterizationSolverStatusLabel(',a);strategy=s[a:b];s=s[:a]+s[b:]
a=s.index('    std::array<SandboxPointCloudConsolidationStrategyOption, 4u>');b=s.index('    glm::vec2 ProjectSandboxParameterizationUvPoint(',a);funcs=s[a:b];s=s[:a]+s[b:]
s=s.replace('const Runtime::EditorPointCloudServicePreparedFrame& pointCloudService','Runtime::EditorPointCloudServicePreparedFrame& pointCloudService').replace('PointCloudService(pointCloudService),','PointCloudService(&pointCloudService),').replace('              ClusteringAvailable(pointCloudService.ClusteringAvailable),\n              PointCloudConsolidationAvailable(\n                  pointCloudService.PointCloudConsolidationAvailable),\n','')
for mod in ['PointCloudServiceOperations','PointCloudConsolidationTypes','PointCloudConsolidationModule']:s=s.replace('import Extrinsic.Runtime.'+mod+';\n','')
write(base+'Sandbox.PanelSupport.cpp',s)
for name in ['Sandbox.DomainPanels.cpp','Sandbox.MeshProcessingPanels.cpp']:
 s=read(base+name)
 for mod in ['PointCloudServiceOperations','PointCloudConsolidationTypes']:s=s.replace('import Extrinsic.Runtime.'+mod+';\n','')
 write(base+name,s)
s=read(base+'Sandbox.MethodPanels.cpp');s=s.replace('import Extrinsic.Runtime.PointCloudConsolidationTypes;\n','');s=s.replace('import Extrinsic.Runtime.PointCloudConsolidationConfig;','import Extrinsic.Runtime.PointCloudConsolidationConfig;\nimport Extrinsic.Runtime.PointCloudConsolidationTypes;\nimport Extrinsic.Runtime.PointCloudConsolidationModule;')
s=s.replace('#include "Sandbox.PanelSupport.hpp"','#include "Sandbox.PanelSupport.hpp"\n#include "Sandbox.PointCloudConsolidationPanel.hpp"')
helper='''namespace Extrinsic::Sandbox::Editor\n{\n    namespace\n    {\n        const Runtime::EditorPointCloudServicePreparedFrame& PointCloudServiceFrame(\n            const SandboxEditorContext& context)\n        {\n            // Preserve the empty, unavailable state of a default context.\n            static const Runtime::EditorPointCloudServicePreparedFrame unavailable{};\n            return context.PointCloudService ? *context.PointCloudService : unavailable;\n        }\n    }\n}\n\nextern "C++"\n{\nnamespace Extrinsic::Sandbox::Editor\n{\n'''
funcs=funcs.replace('        SandboxPointCloudConsolidationPanelActionResult result{};','        const auto& service = PointCloudServiceFrame(context);\n        SandboxPointCloudConsolidationPanelActionResult result{};')
funcs=funcs.replace('context.PointCloudService.','service.')
insert=helper+strategy+funcs+'}\n}\n\n'
pos=s.index('namespace Extrinsic::Sandbox::Editor\n{');s=s[:pos]+insert+s[pos:]
for marker in ['        void DrawPointCloudConsolidationWindow(','        void DrawKMeansControls(']:
 pos=s.index(marker);body=s.index('\n        {',pos)+len('\n        {');s=s[:body]+'\n            const auto& service = PointCloudServiceFrame(context);'+s[body:]
s=s.replace('context.PointCloudService.','service.').replace('context.ClusteringAvailable','service.ClusteringAvailable')
write(base+'Sandbox.MethodPanels.cpp',s)
s=read(base+'Sandbox.EditorShell.cpp');s=s.replace('                Runtime::EditorSceneEditingPreparedFrame Scene{};','                Runtime::EditorSceneEditingPreparedFrame Scene{};\n                Runtime::EditorPointCloudServicePreparedFrame PointCloudService{};')
s=s.replace('                    .Scene = Runtime::PrepareEditorSceneEditingFrame(Attachment),','                    .Scene = Runtime::PrepareEditorSceneEditingFrame(Attachment),\n                    .PointCloudService = Runtime::PrepareEditorPointCloudServiceFrame(Attachment),')
s=s.replace('                    Runtime::PrepareEditorPointCloudServiceFrame(Attachment),','                    prepared.PointCloudService,')
s=s.replace('                ActivePreparedFrame.reset();\n                ActiveContext.reset();','                // Drop the context before the frame storage it borrows.\n                ActiveContext.reset();\n                ActivePreparedFrame.reset();')
write(base+'Sandbox.EditorShell.cpp',s)
f='src/runtime/Editor/Operations/Runtime.PointCloudServiceOperations.cppm';s=read(f);a=s.index('    }\n    struct EditorPointCloudServicePreparedFrame');b=s.index('    [[nodiscard]] EditorPointCloudServicePreparedFrame',a);block=s[a+6:b];s=s[:a]+''.join('    '+line if line.strip() else line for line in block.splitlines(keepends=True))+'    }\n'+s[b:];write(f,s)
f='tests/integration/runtime/Test.SandboxPointCloudConsolidationPanel.cpp';s=read(f).replace('#include "../../../src/app/Sandbox/Editor/Sandbox.PanelSupport.hpp"','#include "../../../src/app/Sandbox/Editor/Sandbox.PanelSupport.hpp"\n#include "../../../src/app/Sandbox/Editor/Sandbox.PointCloudConsolidationPanel.hpp"').replace('context.PointCloudService = prepared;','context.PointCloudService = &prepared;').replace('    context.PointCloudConsolidationAvailable =\n        prepared.PointCloudConsolidationAvailable;\n','');write(f,s)
