from pathlib import Path
from datetime import datetime,UTC
import collections,hashlib,json,os,shlex,shutil,subprocess,sys,time,yaml
R=Path('/home/alex/Documents/IntrinsicEngine');P=Path('/tmp/intrinsic-runtime267');BASE=Path('/dev/shm/intrinsic-runtime267-measurement');S=BASE/'source';B=BASE/'build';O=P/'measurement';M=R/'benchmarks/ci/manifests/processing_config_editor.yaml'
sys.path[:0]=[str(R/'tools/analysis'),str(R/'tools/benchmark')]
import compile_hotspots as h
from benchmark_compile_iteration import command,dependency_snapshot,log_window,critical_path,write_json
from seal_benchmark_results import canonicalize
from validate_benchmark_results import validate_result_data
m=yaml.safe_load(M.read_text());p=m['params'];refs=p['source_revisions'];assert collections.Counter(p['sample_order'])=={'before':3,'after':3}
assert not O.exists() and (B/'.runtime267-owner').read_text()==str(O) and (S/'.git').is_file() and not command(['git','status','--porcelain'],S)
assert shutil.disk_usage(BASE).free>8*1024**3
O.mkdir();(B/'.runtime267-owner').write_text(str(O));env=dict(os.environ,CCACHE_DISABLE='1',VCPKG_FORCE_SYSTEM_BINARIES='1')
configure=['cmake','--preset',p['preset'],'-B',str(B),*p['configure_options'],'-DVCPKG_MANIFEST_INSTALL=OFF'];build=['cmake','--build',str(B),'--target',p['target'],'--parallel',str(p['jobs'])]
packages=dependency_snapshot(S/'external/vcpkg-installed/ci');counts=collections.Counter();common_commands=None
changed=command(['git','diff','--name-only',refs['before'],refs['after'],'--','src','cmake','CMakeLists.txt','CMakePresets.json','vcpkg.json','vcpkg-configuration.json'],S).splitlines()
expected={'src/app/Sandbox/Editor/'+n for n in ['Sandbox.DomainPanels.cpp','Sandbox.EditorShell.cpp','Sandbox.MeshProcessingPanels.cpp','Sandbox.MethodPanels.cpp','Sandbox.PanelSupport.cpp','Sandbox.PanelSupport.hpp','Sandbox.PointCloudConsolidationPanel.hpp']}|{'src/app/Sandbox/CMakeLists.txt','src/runtime/Editor/Operations/Runtime.PointCloudServiceOperations.cppm'}
assert set(changed)==expected,changed
changed_units={f for f in changed if f.endswith(('.cpp','.cppm'))};previous_arm=None
protocol={'manifest_sha256':hashlib.sha256(M.read_bytes()).hexdigest(),'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source':str(S),'build':str(B),'packages':packages,'compiler':command([p['compiler'],'--version'],S),'cpu':next(x.split(':',1)[1].strip() for x in Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name')),'scope':'Settled actual editor target after untimed source reconciliation; no fresh build timing.'};write_json(O/'protocol.json',protocol)
removed={'src/app/Sandbox/Editor/Sandbox.'+n+'.cpp' for n in ['DomainPanels','MeshProcessingPanels','PanelSupport']}
for pos,arm in enumerate(p['sample_order'],1):
 assert not command(['git','status','--porcelain'],S)
 rev=refs[arm];assert len(rev)==40
 subprocess.run(['git','checkout','--detach',rev],cwd=S,check=True,capture_output=True)
 counts[arm]+=1;name=f'{pos:02d}-{arm}-{counts[arm]}';d=O/name;d.mkdir();print('SETUP',name,flush=True)
 if arm!=previous_arm:
  for source in changed_units:os.utime(S/source,None)
 for label,argv in [('configure',configure),('settle',build)]:
  if label=='settle':
   subprocess.run(['ninja','-C',str(B),'-t','recompact'],check=True,stdout=subprocess.DEVNULL)
   setup_before=(B/'.ninja_log').read_bytes() if (B/'.ninja_log').exists() else b''
  start=time.perf_counter()
  with (d/(label+'.log')).open('w') as f:r=subprocess.run(argv,cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  write_json(d/(label+'.execution.json'),{'command':argv,'exit_code':r.returncode,'untimed_setup_wall_seconds':time.perf_counter()-start});assert r.returncode==0,label
  if label=='settle':
   setup_log=log_window(setup_before,(B/'.ninja_log').read_bytes());(d/'settle.ninja_log').write_bytes(setup_log)
   setup_resolver=h.SourceResolver(S,B);setup_rows=[h.build_report_row(S,setup_resolver,e) for e in h.parse_ninja_log(d/'settle.ninja_log',B)];write_json(d/'settle.hotspots.json',setup_rows)
   if arm!=previous_arm:assert changed_units<={x['source'] for x in setup_rows}
 previous_arm=arm
 commands=json.loads((B/'compile_commands.json').read_text());assert all('ccache' not in x['command'] for x in commands);assert all(p['compiler'] in x['command'] for x in commands if x['file'].endswith(('.cpp','.cppm')))
 if common_commands is None:common_commands=commands
 else:assert commands==common_commands
 cache=(B/'CMakeCache.txt').read_text();assert f'CMAKE_HOME_DIRECTORY:INTERNAL={S}' in cache and f'CMAKE_CACHEFILE_DIR:INTERNAL={B}' in cache
 shutil.copyfile(B/'compile_commands.json',d/'compile_commands.json');shutil.copyfile(B/'CMakeCache.txt',d/'CMakeCache.txt')
 # Bind and pre-read the exact tracked source inputs; test/docs also remain at this commit.
 tracked=command(['git','ls-files'],S).splitlines();hashes={f:hashlib.sha256((S/f).read_bytes()).hexdigest() for f in tracked if (S/f).is_file()};write_json(d/'source-hashes.json',hashes)
 assert dependency_snapshot(S/'external/vcpkg-installed/ci')==packages
 maps={str(f.relative_to(B)):f.read_text() for f in B.rglob('*.modmap')};write_json(d/'module-response-maps.json',maps)
 resolver=h.SourceResolver(S,B);timings={};rss={};details={};print('MEASURE',name,flush=True)
 for scenario,path in p['scenarios'].items():
  subprocess.run(['ninja','-C',str(B),'-t','recompact'],check=True,stdout=subprocess.DEVNULL)
  if path:os.utime(S/path,None)
  before=(B/'.ninja_log').read_bytes();stamp=datetime.now(UTC).isoformat();load=os.getloadavg();start=time.perf_counter()
  with (d/(scenario+'.log')).open('w') as f:r=subprocess.run(['/usr/bin/time','-q','-f','{"user_s":%U,"system_s":%S,"max_single_process_rss_kib":%M}','-o',str(d/(scenario+'.time.json')),'--',*build],cwd=S,env=env,stdout=f,stderr=subprocess.STDOUT)
  wall=(time.perf_counter()-start)*1000;rec=json.loads((d/(scenario+'.time.json')).read_text().splitlines()[-1]);rec.update(wall_ms=wall,started_at=stamp,loadavg_before=load,exit_code=r.returncode,command=build);write_json(d/(scenario+'.execution.json'),rec);assert r.returncode==0
  window=log_window(before,(B/'.ninja_log').read_bytes());lp=d/(scenario+'.ninja_log');lp.write_bytes(window)
  rows=[h.build_report_row(S,resolver,e) for e in h.parse_ninja_log(lp,B)];sources={x['source'] for x in rows};outputs=[x.split('\t')[3] for x in window.decode().splitlines()[1:]]
  if scenario=='noop':assert not rows and not any(x.endswith(('.o','.a','.pcm')) for x in outputs)
  elif scenario=='config_impl':assert len(rows)==1 and sources=={path}
  else:
   assert path in sources and len(rows)>1 and 'src/app/Sandbox/Editor/Sandbox.MethodPanels.cpp' in sources
   assert (removed<=sources if arm=='before' else not removed & sources),sources
  graph=command(['ninja','-C',str(B),'-t','graph',p['target']],S);(d/(scenario+'.dot')).write_text(graph);crit=critical_path(graph,window);assert crit['duration_ms']<=wall+100
  write_json(d/(scenario+'.hotspots.json'),rows);details[scenario]={'execution':rec,'compiler_invocations':len(rows),'sources':sorted(sources),'producer_rows':rows,'critical_path':crit};timings[scenario]=wall;rss[scenario]=rec['max_single_process_rss_kib']*1024
  assert json.loads((B/'compile_commands.json').read_text())==common_commands
  assert {str(f.relative_to(B)):f.read_text() for f in B.rglob('*.modmap')}==maps
  assert not command(['git','status','--porcelain'],S) and command(['git','rev-parse','HEAD'],S).strip()==rev
  assert dependency_snapshot(S/'external/vcpkg-installed/ci')==packages
  print(' PASS',scenario,round(wall/1000,3),'units',len(rows),flush=True)
 assert {f:hashlib.sha256((S/f).read_bytes()).hexdigest() for f in tracked if (S/f).is_file()}==hashes
 raw={'benchmark_id':m['benchmark_id'],'method':m['method'],'dataset':m['dataset'],'backend':'external_baseline','commit':rev,'status':'passed','metrics':{'build_time_ms':timings,'memory_peak_bytes':rss,'sample_count':1},'diagnostics':{'arm':arm,'position':pos,'sample':counts[arm],'source_clean_before_after':True,'source_and_dependency_hashes_verified':True,'commands_identical':True,'scenarios':details}}
 write_json(d/'raw-result.json',raw);sealed=canonicalize(raw,manifest_path=M,manifest=m,manifests_root=R/'benchmarks',run_id='runtime267-config-editor',attempt_id=name,source_state='clean_commit',source_revision=rev,claim_eligible=False,snapshot_sha256=None,diff_sha256=None)
 results=O/'results';results.mkdir(exist_ok=True);dest=results/(name+'.json');_,errors=validate_result_data(sealed,dest,{m['benchmark_id']:(M,m)},R/'benchmarks');assert not errors,errors;write_json(dest,sealed);print('COMPLETE',name,flush=True)
assert counts=={'before':3,'after':3}
