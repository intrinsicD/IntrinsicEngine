from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json,yaml,textwrap,re,shutil,hashlib,tarfile,subprocess
r=Path('/home/alex/Documents/IntrinsicEngine');p=Path('/tmp/intrinsic-runtime267');now=datetime.now(ZoneInfo('Europe/Berlin')).isoformat(timespec='seconds');s=json.loads((p/'summary.json').read_text());diag='ara/evidence/diagnostics/runtime267_processing_config';report='ara/evidence/tables/runtime267_processing_config_measurement.md';task='tasks/done/RUNTIME-267-processing-config-consumer-locality.md'
assert len(s['samples'])==6
assert hashlib.sha256((r/'tools/analysis/benchmark_compile_iteration.py').read_bytes()).hexdigest()==s['freeze']['helper_sha256']
assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==v for f,v in json.loads((p/'verified-source-hashes.json').read_text()).items())
tree=r/'ara/trace/exploration_tree.yaml';obs=r/'ara/staging/observations.yaml';claims=r/'ara/logic/claims.md';session=r/'ara/trace/sessions/2026-09-16_001.yaml';index=r/'ara/trace/sessions/session_index.yaml';pm=r/'ara/trace/pm_reasoning_log.yaml'
def append_rows(path,rows):
 with path.open('a') as f:f.write('\n'+textwrap.indent(yaml.safe_dump(rows,sort_keys=False,width=108,allow_unicode=True),'  '))
summary='Retired RUNTIME-268, GRAPHICS-144, GRAPHICS-145 and RUNTIME-267 with bounded compile measurements and Claude review. Config-interface editor rebuild median 34.245 to 27.372 seconds locally; UI/material/shader/cache tasks retain their independent scope.'
idx=yaml.safe_load(index.read_text())['sessions'][-1];assert idx['id']=='2026-09-16_001';idx.update(summary=summary,turn_count=4,events_count=14,claims_touched=['C99','C100','C101','C102']);it=index.read_text();pos=it.rfind('- id: 2026-09-16_001');assert pos>=0;index.write_text(it[:pos]+yaml.safe_dump([idx],sort_keys=False,width=108))
append_rows(pm,[{'turn':'2026-09-16_001#4','notes':['Crystallize O235/C102 through N608 artifact commitment; no inferred user endorsement or generalized performance claim. All six records remain claim_eligible:false.','Retain both rejected setup/accounting attempts; new frozen population includes all six samples, receiving-unit regression, overlapping implementation/no-op ranges and exact ownership footprint.','Fresh Clang20 compilation is distinct from Clang23 CPU execution. Existing unrelated staged topics keep owners/stale flags; no abandonment or new closure signal. Explicit A=before resolves reviewer notation inversion.']}])
# Publish report and retire accepted scope.
(r/report).write_text((p/'report-draft.md').read_text())
old=r/'tasks/active/RUNTIME-267-processing-config-consumer-locality.md';t=old.read_text().replace('- [ ]','- [x]');t+='''\n## Completion — 2026-09-16
Retired at CPUContracted, the intended compile-refactor endpoint. Source commit
`6fb0807f49a8d660d820470e82613c1ad1a9c424`; accompanying evidence/retirement commit
binds the six retained samples and Claude reviews. See the
[matched comparison](../../ara/evidence/tables/runtime267_processing_config_measurement.md):
local config-interface editor-target median 34.245 → 27.372 s (20.1% lower),
19 → 16 compilers. Receiving MethodPanels cost rises 8.132 → 8.238 s; included
in target timing. Implementation/no-op ranges overlap; no improvement claimed.
All records remain claim_eligible:false; C102 records only these bounded observations.
Full CPU and fresh minimum-compiler evidence are recorded above. No deferred work
inside this bounded task. Mandatory typed config/session consumers remain;
UI-037, GRAPHICS-105, LEGACY-043 and BUILD-006 retain their independent scopes.
BUG-199 fixes the observed CMake metadata-accounting defect; both rejected attempts
remain archived, outside the six accepted samples. No GPU/sanitizer execution claim.
''';(r/task).write_text(t);old.unlink()
bugold=r/'tasks/backlog/bugs/BUG-199-compile-benchmark-cmake-glob-output.md';bug=bugold.read_text().replace('- [ ]','- [x]');bug+='''\n## Completion — 2026-09-16
Retired as a tested harness repair, with no engine maturity change. Fix commit
`a1124cf17`; 26 tooling tests and all six corrected benchmark records pass.
Claude found no concrete defect. Full build wall still includes glob checking;
unexplained non-meta outputs still fail. The original failure and reviewed fix
are retained in RUNTIME-267's
[raw evidence](../../ara/evidence/diagnostics/runtime267_processing_config/raw-evidence.tar.gz).
No deferred work.
''';(r/'tasks/done/BUG-199-compile-benchmark-cmake-glob-output.md').write_text(bug);bugold.unlink()
f=r/'tasks/backlog/README.md';t=f.read_text().replace('GRAPHICS-144 and GRAPHICS-145 are complete. RUNTIME-267 must freeze fresh\nimmediate-before sources for its own comparison. UI-037 and GRAPHICS-105 are independently','GRAPHICS-144, GRAPHICS-145 and RUNTIME-267 are complete. UI-037 and GRAPHICS-105 are independently');t=t.replace('| Processing config dependency chain | [RUNTIME-267](../active/RUNTIME-267-processing-config-consumer-locality.md) |\n','');f.write_text(t)
f=r/'tasks/backlog/runtime/README.md';t=f.read_text();start=t.index('## Compilation locality');end=t.index('## Related queues',start);f.write_text(t[:start]+'''## Compilation locality

BUILD-009 and RUNTIME-266/267/268 are complete. Existing config and prepared-frame
ownership contracts remain authoritative; further changes require a measured
consumer need. Current cross-cutting work is listed in the root backlog.

'''+t[end:])
f=r/'tasks/done/RETIREMENT-LOG.md';t=f.read_text();pos=t.index('\n## ');t=t[:pos]+'''
## 2026-09-16 — RUNTIME-267 and BUG-199: config editor locality

Retired [RUNTIME-267](RUNTIME-267-processing-config-consumer-locality.md) at
CPUContracted: shell-owned prepared frame, draw-scoped context borrow and existing
method implementation owner remove three unrelated config importers. Canonical full
CPU and fresh Clang20 caller compilation pass. Six matched editor-target samples
observe 34.245 → 27.372 s median locally; receiver cost and non-improving controls
remain explicit in the [report](../../ara/evidence/tables/runtime267_processing_config_measurement.md).
One private header, +34 C++ lines; no new module/state owner or broader speed claim.
[BUG-199](BUG-199-compile-benchmark-cmake-glob-output.md) repairs shared CMake glob
metadata accounting, with regression tests and both rejected attempts retained.
Source `6fb0807f4`, harness fix `a1124cf17`; accompanying evidence commit closes the
record. UI/material/shader/cache work remains independent.

'''+t[pos:];f.write_text(t)
# Freeze complete raw evidence, including canonical records and rejected attempts.
d=r/diag;d.mkdir(parents=True,exist_ok=True)
for name in ['summary.json','verification.json','results-review.txt','results-review-resolutions.md']:
 (d/name).write_text((p/name).read_text().rstrip()+'\n')
raw=d/'raw-evidence.tar.gz';files=sorted(x for x in p.rglob('*') if x.is_file() and '__pycache__' not in x.parts)
with tarfile.open(raw,'w:gz',compresslevel=6) as tar:
 for f in files:tar.add(f,arcname=f.relative_to(p),recursive=False)
index_data={'archive':'raw-evidence.tar.gz','archive_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'canonical_results':6,'source_revisions':s['source_revisions'],'files':[{'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]}
with tarfile.open(raw) as tar:
 assert set(tar.getnames())=={x['path'] for x in index_data['files']}
 for x in index_data['files']:assert hashlib.sha256(tar.extractfile(x['path']).read()).hexdigest()==x['sha256']
(d/'evidence-index.json').write_text(json.dumps(index_data,indent=2)+'\n')
for f in [tree,obs,session,index,pm]:yaml.safe_load(f.read_text())
print('Recorded end-of-turn epilogue, report, retirement and verified archive:',len(files),'files,',raw.stat().st_size,'bytes')
