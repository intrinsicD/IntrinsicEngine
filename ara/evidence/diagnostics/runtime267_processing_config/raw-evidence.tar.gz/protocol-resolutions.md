# Protocol review resolutions
- Initial detailed Claude protocol call stopped after seven minutes without
  output. Preserve it as incomplete, never a review approval; shorter review
  returned concrete accounting questions.
- Receiving MethodPanels is in ExtrinsicSandboxEditor, the timed target. Require
  its compilation in both interface probes and report its actual producer cost.
- Restrict production/build diff to the nine declared ownership/import/header
  files. There is no algorithm/config-format change; tests are disabled only in
  the measurement target and passed separately.
- Cache-off explicitly disables launchers and CCACHE_DISABLE; every command must
  use Clang23 without ccache/sccache. It does not mean deleting the CMake cache.
- Reconciliation intentionally reuses unchanged prerequisites. Different source
  arms cannot be required to have byte-identical complete outputs. On each arm
  switch force all changed C++ producers stale, capture setup compiler windows
  and require each producer to compile before any timed probe. Actual no-op
  then checks settlement. Package/source/command identities and fixed per-sample
  maps are verified. No fresh-build or cross-arm binary-identity claim.
- Interface propagation is observed from actual compiler invocations. Before
  must contain all three unrelated panels; after must omit them. Every sample,
  untimed setup and producer duration is retained, including cost at the receiver.

- Rejected setup 1: the root CMake gate omits src/app under headless+tests-off,
  despite Sandbox=ON. Configure succeeded but target lookup failed before any
  target compiler or timed sample. Preserve its complete output, old freeze and
  runner. Set INTRINSIC_BUILD_TESTS=ON in the refrozen protocol; only the editor
  library target is built/timed, with no test compilation/execution in the cohort.
