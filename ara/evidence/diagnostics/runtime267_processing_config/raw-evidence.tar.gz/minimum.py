from pathlib import Path
import json,os,shlex,subprocess,shutil
R=Path('/home/alex/Documents/IntrinsicEngine');P=Path('/tmp/intrinsic-runtime267');B=Path('/dev/shm/intrinsic-runtime267-clang20');assert not B.exists();assert shutil.disk_usage(B.parent).free>8*1024**3;B.mkdir();(B/'.runtime267-owner').write_text(str(P))
env=dict(os.environ,CCACHE_DISABLE='1',VCPKG_FORCE_SYSTEM_BINARIES='1')
configure=['cmake','--preset','ci','-B',str(B),'-DCMAKE_C_COMPILER=/usr/bin/clang-20','-DCMAKE_CXX_COMPILER=/usr/bin/clang++-20','-DCMAKE_CXX_COMPILER_CLANG_SCAN_DEPS=/usr/bin/clang-scan-deps-20','-DINTRINSIC_ENABLE_CCACHE=OFF','-DCMAKE_CXX_COMPILER_LAUNCHER=','-DCMAKE_C_COMPILER_LAUNCHER=','-DEXTRINSIC_BACKEND=Null','-DINTRINSIC_PLATFORM_BACKEND=Null','-DINTRINSIC_HEADLESS_NO_GLFW=ON','-DINTRINSIC_BUILD_BENCHMARKS=OFF','-DVCPKG_MANIFEST_INSTALL=OFF']
with (P/'clang20-configure.log').open('w') as f:r=subprocess.run(configure,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0
rows=json.loads((B/'compile_commands.json').read_text());assert all('/usr/bin/clang++-20' in x['command'] for x in rows if x['file'].endswith(('.cpp','.cppm')))
files=['tests/integration/runtime/Test.SandboxPointCloudConsolidationPanel.cpp','tests/integration/runtime/Test.SandboxEditorPresentation.cpp','tests/contract/runtime/Test.SandboxEditorSessionLifecycle.cpp'];objs=[]
for file in files:
 row=next(x for x in rows if x['file']==str(R/file));args=shlex.split(row['command']);objs.append(args[args.index('-o')+1])
build=['cmake','--build',str(B),'--target','ExtrinsicSandboxEditor',*objs,'--parallel','4'];(P/'clang20-commands.json').write_text(json.dumps({'configure':configure,'build':build,'test_sources':files},indent=2)+'\n')
with (P/'clang20-build.log').open('w') as f:r=subprocess.run(build,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0
for name in ['CMakeCache.txt','compile_commands.json']:shutil.copyfile(B/name,P/('clang20-'+name))
print('Fresh Clang20 app/runtime closure and all 3 caller test objects passed; no Clang20 test execution claimed.')
