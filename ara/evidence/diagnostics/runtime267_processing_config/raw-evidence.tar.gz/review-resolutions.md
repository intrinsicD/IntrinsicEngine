# Plan and source review resolutions
- Root confirmed actual readers before removing duplicate availability flags:
  ClusteringAvailable has one MethodPanels reader; consolidation's context flag
  is unused. Read the canonical prepared-frame flag instead.
- Shell owns the prepared frame before constructing the context. Constructor
  requires a non-const lvalue (rejects temporaries); lifetime still requires the
  owner to outlive the visit. Both draw completion and detach reset context first.
- The sole frame definition joins an existing extern C++ linkage block, not an
  inner namespace. App forward declaration has matching global attachment. No
  alternate DTO, adapter allocation, registration interface import or new module.
- The private declaration header has two concrete consumers: MethodPanels and its
  integration test, both linking the existing editor library. Include after
  runtime imports; standard headers remain in the GMF as required locally.
- One private method helper supplies the previous default empty-frame behavior
  for three callers. This preserves unavailable drawing and config diagnostics;
  no public test-only draw seam added. The negative action test asserts a valid
  request first, proving the rejection occurs on an unattached context.
- Source review initially misread omitted context. Complete source review
  withdrew alleged namespace, attachment, UAF, target guard, transitive guard,
  linkage and constness blockers. Compiler metadata needs actual producers, so
  the conditional app guard remains; forbidding Config catches Types/Module
  transitively. No rules weakened.
- Runtime.EditorProcessing.cpp Resolve explicitly returns the shared empty
  context unless IsBound's epoch predicate succeeds. Availability checks guard
  service dereferences. Existing canonical docs describe preview/apply rechecks;
  the snapshot flags are not new authority. No unrelated validator change.
- A named free function's return type is not generally encoded in its mangled
  name; do not repeat the plan review's blanket ABI statement. Canonical Clang23
  dependency-driven rebuild and fresh Clang20 app/runtime/caller objects verify
  the real module attachment boundary.
