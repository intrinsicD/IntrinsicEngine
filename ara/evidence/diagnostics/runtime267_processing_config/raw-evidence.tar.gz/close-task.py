from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json,yaml,textwrap,re,shutil,hashlib,tarfile,subprocess
r=Path('/home/alex/Documents/IntrinsicEngine');p=Path('/tmp/intrinsic-runtime267');now=datetime.now(ZoneInfo('Europe/Berlin')).isoformat(timespec='seconds');s=json.loads((p/'summary.json').read_text());diag='ara/evidence/diagnostics/runtime267_processing_config';report='ara/evidence/tables/runtime267_processing_config_measurement.md';task='tasks/done/RUNTIME-267-processing-config-consumer-locality.md'
assert len(s['samples'])==6
assert hashlib.sha256((r/'tools/analysis/benchmark_compile_iteration.py').read_bytes()).hexdigest()==s['freeze']['helper_sha256']
assert all(hashlib.sha256((r/f).read_bytes()).hexdigest()==v for f,v in json.loads((p/'verified-source-hashes.json').read_text()).items())
# End-of-turn research epilogue, once. Preserve existing topics and formatting.
tree=r/'ara/trace/exploration_tree.yaml';obs=r/'ara/staging/observations.yaml';claims=r/'ara/logic/claims.md';session=r/'ara/trace/sessions/2026-09-16_001.yaml';index=r/'ara/trace/sessions/session_index.yaml';pm=r/'ara/trace/pm_reasoning_log.yaml'
assert yaml.safe_load(tree.read_text())['tree'][-1]['id']=='N606'
assert yaml.safe_load(obs.read_text())['observations'][-1]['id']=='O234'
assert '## C102:' not in claims.read_text()
assert yaml.safe_load(session.read_text())['session']['turn_count']==3
ob={'id':'O235','timestamp':now,'provenance':'ai-executed','content':'Local exact-source ABBAAB editor-target config-interface rebuild median 34.245 to 27.372 seconds (20.1% lower), with 19 to 16 compilers. Receiver MethodPanels median 8.132 to 8.238 seconds (+1.3%). Implementation/no-op ranges overlap; no improvement claimed. All six results claim_eligible:false.','context':'RUNTIME-267 source be4066391 to 6fb0807f4, Clang23 Debug Null/headless four jobs, cache off, same paths/commands, source and package identities verified. Retained rejected setup/accounting attempts are outside the six samples. N608 commits the bounded source/report.','potential_type':'claim','bound_to':['N607'],'promoted':True,'promoted_to':'logic/claims.md:C102','crystallized_via':'artifact-commitment','stale':False}
def append_rows(path,rows):
 with path.open('a') as f:f.write('\n'+textwrap.indent(yaml.safe_dump(rows,sort_keys=False,width=108,allow_unicode=True),'  '))
append_rows(obs,[ob])
append_rows(tree,[{'id':'N607','type':'experiment','title':'Measure processing config edits against the actual editor target','provenance':'ai-executed','timestamp':now,'result':ob['content']+' All 1138 commands match; exactly three unrelated app consumers leave the rebuild. Frozen helper repair recognizes CMake glob metadata without removing wall overhead.','evidence':['O235',report,diag+'/evidence-index.json'],'status':'resolved'},{'id':'N608','type':'decision','title':'Keep shell-owned family frame borrowing and retire RUNTIME-267','provenance':'ai-executed','timestamp':now,'choice':'Retain source 6fb0807f4 after Claude plan/source/protocol/results review, full CPU 4666 passed plus one expected skip, 158 focused cases and nine strengthened tests. Fresh Clang20 compiled runtime/editor closure plus all three caller objects. One private header, +34 net C++ lines, no new compiled unit/module/state owner. Existing typed session/config dependencies remain; no facade. BUG-199 repairs shared measurement metadata accounting.','alternatives':['Hide mandatory by-value config/results behind a new facade','Borrow a temporary prepared frame','Claim whole-engine or clean-build gains from a local incremental target comparison'],'evidence':['O235','N607',task,report],'status':'resolved'}])
with claims.open('a') as f:f.write('''\n## C102: Bounded processing config editor rebuild observations
- **Statement**: RUNTIME-267's local Clang23 Debug Null/headless ABBAAB cohort, three samples per exact source arm, changes settled config-interface edit plus editor-target archives median from 34.245 to 27.372 seconds (20.1% lower), with 19 to 16 compiler invocations. Before range is 34.225–34.349 seconds; after is 27.244–27.408. Exactly DomainPanels, MeshProcessingPanels and PanelSupport leave the rebuild; no added sources. Receiving MethodPanels median rises 8.132 to 8.238 seconds (+1.3%), included in target timing. All 1,138 configured compiler commands match; clean source and package identities are checked.
- **Status**: supported — descriptive local warm-input incremental observations only; all six canonical records remain claim_eligible:false. No clean-build, whole-engine, runtime/GPU, memory, cross-host/compiler, statistical/general or publication-qualified conclusion. Implementation/no-op ranges overlap; neither improves. Clang20 evidence is compilation only; execution is canonical Clang23 CPU.
- **Provenance**: ai-executed
- **Crystallized via**: artifact-commitment
- **Falsification criteria**: Recalculation disagrees with medians/counts, receiving-helper compile cost is omitted, source/command/package identities do not match, setup compilations leak into timed windows, or missing consumers change functionality. Both rejected attempts must remain separate from all six retained corrected samples. Prior runtime-only targets cannot be combined.
- **Proof**: ['''+report+', '+diag+'/summary.json, '+diag+'/verification.json, '+diag+'/evidence-index.json, '+diag+'/raw-evidence.tar.gz, benchmarks/ci/manifests/processing_config_editor.yaml, '+task+''']
- **Tags**: compilation, C++23 modules, editor dependencies, prepared-frame lifetime, local matched observations
- **From staging**: O235
''')
summary='Retired RUNTIME-268, GRAPHICS-144, GRAPHICS-145 and RUNTIME-267 with bounded compile measurements and Claude review. Config-interface editor rebuild median 34.245 to 27.372 seconds locally; UI/material/shader/cache tasks retain their independent scope.'
st=session.read_text();st=re.sub(r'  last_turn: .*',f"  last_turn: '{now}'",st,count=1).replace('  turn_count: 3','  turn_count: 4',1);start=st.index('  summary:');end=st.index('events_logged:',start);st=st[:start]+textwrap.indent(yaml.safe_dump({'summary':summary},sort_keys=False,width=108),'  ')+st[end:]
def extend_section(text,before,entries):return text.replace(before,yaml.safe_dump(entries,sort_keys=False,width=108,allow_unicode=True)+before,1)
st=extend_section(st,'ai_actions:',[{'turn':4,'type':'experiment','id':'N607','routing':'direct','provenance':'ai-executed','summary':'Measure config edit fanout and real editor-target walls in six retained samples.'},{'turn':4,'type':'decision','id':'N608','routing':'direct','provenance':'ai-executed','summary':'Retain canonical frame ownership/borrow and retire RUNTIME-267 plus BUG-199.'},{'turn':4,'type':'observation','id':'O235','routing':'crystallized','provenance':'ai-executed','summary':'C102 records local incremental observations through N608 artifact commitment.'}])
st=extend_section(st,'claims_touched:',[{'turn':4,'action':'Isolated three app consumers, resolved Claude reviews, verified full CPU and fresh minimum compiler, fixed CMake metadata accounting, measured six samples and retired tasks with retained evidence.','provenance':'ai-executed','files_changed':['src/app/Sandbox/Editor/Sandbox.PanelSupport.hpp','src/runtime/Editor/Operations/Runtime.PointCloudServiceOperations.cppm','benchmarks/ci/manifests/processing_config_editor.yaml',task,report]}])
st=extend_section(st,'key_context:',[{'id':'C102','action':'crystallized','turn':4}]);st=extend_section(st,'open_threads:',[{'turn':4,'excerpt':'User requests continued compile/reuse tasks with Claude: plan, implement, review, test and fix. Standing source-sharing/commit/push authorization persists; no main merge.'}]);st=st.replace('- RUNTIME-268, GRAPHICS-144 and GRAPHICS-145 are complete with bounded measured evidence. RUNTIME-267 config/frame\n  ownership remains open. UI-037 and GRAPHICS-105 are ready; LEGACY-043 follows GRAPHICS-105, and BUILD-006 retains\n  its prerequisites.','- RUNTIME-268, GRAPHICS-144, GRAPHICS-145 and RUNTIME-267 are complete with bounded measured evidence. Mandatory\n  config/session dependencies remain. UI-037 and GRAPHICS-105 are ready; LEGACY-043 follows GRAPHICS-105, and\n  BUILD-006 retains its prerequisites.');session.write_text(st)
idx=yaml.safe_load(index.read_text())['sessions'][-1];assert idx['id']=='2026-09-16_001';idx.update(summary=summary,turn_count=4,events_count=14,claims_touched=['C99','C100','C101','C102']);it=index.read_text();pos=it.rfind('  - id: 2026-09-16_001');assert pos>=0;index.write_text(it[:pos]+textwrap.indent(yaml.safe_dump([idx],sort_keys=False,width=108),'  '))
append_rows(pm,[{'turn':'2026-09-16_001#4','notes':['Crystallize O235/C102 through N608 artifact commitment; no inferred user endorsement or generalized performance claim. All six records remain claim_eligible:false.','Retain both rejected setup/accounting attempts; new frozen population includes all six samples, receiving-unit regression, overlapping implementation/no-op ranges and exact ownership footprint.','Fresh Clang20 compilation is distinct from Clang23 CPU execution. Existing unrelated staged topics keep owners/stale flags; no abandonment or new closure signal. Explicit A=before resolves reviewer notation inversion.']}])
# Publish report and retire accepted scope.
(r/report).write_text((p/'report-draft.md').read_text())
old=r/'tasks/active/RUNTIME-267-processing-config-consumer-locality.md';t=old.read_text().replace('- [ ]','- [x]');t+='''\n## Completion — 2026-09-16
Retired at CPUContracted, the intended compile-refactor endpoint. Source commit
`6fb0807f49a8d660d820470e82613c1ad1a9c424`; accompanying evidence/retirement commit
binds the six retained samples and Claude reviews. See the
[matched comparison](../../ara/evidence/tables/runtime267_processing_config_measurement.md):
local config-interface editor-target median 34.245 → 27.372 s (20.1% lower),
19 → 16 compilers. Receiving MethodPanels cost rises 8.132 → 8.238 s; included
in target timing. Implementation/no-op ranges overlap; no improvement claimed.
All records remain claim_eligible:false; C102 records only these bounded observations.
Full CPU and fresh minimum-compiler evidence are recorded above. No deferred work
inside this bounded task. Mandatory typed config/session consumers remain;
UI-037, GRAPHICS-105, LEGACY-043 and BUILD-006 retain their independent scopes.
BUG-199 fixes the observed CMake metadata-accounting defect; both rejected attempts
remain archived, outside the six accepted samples. No GPU/sanitizer execution claim.
''';(r/task).write_text(t);old.unlink()
bugold=r/'tasks/backlog/bugs/BUG-199-compile-benchmark-cmake-glob-output.md';bug=bugold.read_text().replace('- [ ]','- [x]');bug+='''\n## Completion — 2026-09-16
Retired as a tested harness repair, with no engine maturity change. Fix commit
`a1124cf17`; 26 tooling tests and all six corrected benchmark records pass.
Claude found no concrete defect. Full build wall still includes glob checking;
unexplained non-meta outputs still fail. The original failure and reviewed fix
are retained in RUNTIME-267's
[raw evidence](../../ara/evidence/diagnostics/runtime267_processing_config/raw-evidence.tar.gz).
No deferred work.
''';(r/'tasks/done/BUG-199-compile-benchmark-cmake-glob-output.md').write_text(bug);bugold.unlink()
f=r/'tasks/backlog/README.md';t=f.read_text().replace('GRAPHICS-144 and GRAPHICS-145 are complete. RUNTIME-267 must freeze fresh\nimmediate-before sources for its own comparison. UI-037 and GRAPHICS-105 are independently','GRAPHICS-144, GRAPHICS-145 and RUNTIME-267 are complete. UI-037 and GRAPHICS-105 are independently');t=t.replace('| Processing config dependency chain | [RUNTIME-267](../active/RUNTIME-267-processing-config-consumer-locality.md) |\n','');f.write_text(t)
f=r/'tasks/backlog/runtime/README.md';t=f.read_text();start=t.index('## Compilation locality');end=t.index('## Related queues',start);f.write_text(t[:start]+'''## Compilation locality

BUILD-009 and RUNTIME-266/267/268 are complete. Existing config and prepared-frame
ownership contracts remain authoritative; further changes require a measured
consumer need. Current cross-cutting work is listed in the root backlog.

'''+t[end:])
f=r/'tasks/done/RETIREMENT-LOG.md';t=f.read_text();pos=t.index('\n## ');t=t[:pos]+'''
## 2026-09-16 — RUNTIME-267 and BUG-199: config editor locality

Retired [RUNTIME-267](RUNTIME-267-processing-config-consumer-locality.md) at
CPUContracted: shell-owned prepared frame, draw-scoped context borrow and existing
method implementation owner remove three unrelated config importers. Canonical full
CPU and fresh Clang20 caller compilation pass. Six matched editor-target samples
observe 34.245 → 27.372 s median locally; receiver cost and non-improving controls
remain explicit in the [report](../../ara/evidence/tables/runtime267_processing_config_measurement.md).
One private header, +34 C++ lines; no new module/state owner or broader speed claim.
[BUG-199](BUG-199-compile-benchmark-cmake-glob-output.md) repairs shared CMake glob
metadata accounting, with regression tests and both rejected attempts retained.
Source `6fb0807f4`, harness fix `a1124cf17`; accompanying evidence commit closes the
record. UI/material/shader/cache work remains independent.

'''+t[pos:];f.write_text(t)
# Freeze complete raw evidence, including canonical records and rejected attempts.
d=r/diag;d.mkdir(parents=True,exist_ok=True)
for name in ['summary.json','verification.json','results-review.txt','results-review-resolutions.md']:
 (d/name).write_text((p/name).read_text().rstrip()+'\n')
raw=d/'raw-evidence.tar.gz';files=sorted(x for x in p.rglob('*') if x.is_file() and '__pycache__' not in x.parts)
with tarfile.open(raw,'w:gz',compresslevel=6) as tar:
 for f in files:tar.add(f,arcname=f.relative_to(p),recursive=False)
index_data={'archive':'raw-evidence.tar.gz','archive_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'canonical_results':6,'source_revisions':s['source_revisions'],'files':[{'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]}
with tarfile.open(raw) as tar:
 assert set(tar.getnames())=={x['path'] for x in index_data['files']}
 for x in index_data['files']:assert hashlib.sha256(tar.extractfile(x['path']).read()).hexdigest()==x['sha256']
(d/'evidence-index.json').write_text(json.dumps(index_data,indent=2)+'\n')
for f in [tree,obs,session,index,pm]:yaml.safe_load(f.read_text())
print('Recorded end-of-turn epilogue, report, retirement and verified archive:',len(files),'files,',raw.stat().st_size,'bytes')
