from pathlib import Path
import subprocess,json,concurrent.futures
r=Path('/home/alex/Documents/IntrinsicEngine');p=Path('/tmp/intrinsic-runtime267');out=p/'final-checks';out.mkdir(exist_ok=True)
commands={
 'tasks':['python3','tools/agents/check_task_policy.py','--root','.','--strict'],
 'lifecycle':['python3','tools/agents/check_task_state_links.py','--root','.','--strict'],
 'maturity':['python3','tools/agents/check_task_maturity_followups.py','--root','.','--strict'],
 'links':['python3','tools/docs/check_doc_links.py','--root','.','--strict'],
 'layering':['python3','tools/repo/check_layering.py','--root','src','--strict'],
 'test-layout':['python3','tools/repo/check_test_layout.py','--root','.','--strict'],
 'root':['python3','tools/repo/check_root_hygiene.py','--root','.'],
 'skills':['python3','tools/agents/sync_skills.py','--check'],
 'manifests':['python3','tools/benchmark/validate_benchmark_manifests.py'],
 'results':['python3','tools/benchmark/validate_benchmark_results.py','--root',str(p/'measurement/results'),'--strict'],
 'claims':['python3','tools/agents/check_ara_claims.py','--root','.','--strict'],
 'harness':['python3','tests/regression/tooling/Test.CompileHotspots.py'],
 'diff':['git','diff','--check']}
files=set(subprocess.check_output(['git','diff','--name-only','be40663918749417275b06fb8268a00310688f7d'],cwd=r,text=True).splitlines())
files.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r,text=True).splitlines())
commands['docs-sync']=['python3','tools/docs/check_docs_sync.py','--root','.','--files',*sorted(files),'--strict']
def run(item):
 name,cmd=item;q=subprocess.run(cmd,cwd=r,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/(name+'.log')).write_text(q.stdout.rstrip()+'\n');return {'name':name,'command':cmd,'exit_code':q.returncode}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:results=list(ex.map(run,commands.items()))
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps([{'name':x['name'],'exit_code':x['exit_code']} for x in results],indent=2));raise SystemExit(any(x['exit_code'] for x in results))
