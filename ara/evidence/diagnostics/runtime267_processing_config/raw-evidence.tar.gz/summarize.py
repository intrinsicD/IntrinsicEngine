from pathlib import Path
import collections,hashlib,json,statistics,sys,yaml
R=Path('/home/alex/Documents/IntrinsicEngine');P=Path('/tmp/intrinsic-runtime267');O=P/'measurement';M=R/'benchmarks/ci/manifests/processing_config_editor.yaml';m=yaml.safe_load(M.read_text())
sys.path.insert(0,str(R/'tools/benchmark'))
from validate_benchmark_results import validate_result_data
freeze=json.loads((P/'freeze.json').read_text());protocol=json.loads((O/'protocol.json').read_text())
for k,f in [('manifest_sha256',M),('runner_sha256',P/'benchmark.py')]:assert hashlib.sha256(f.read_bytes()).hexdigest()==freeze[k]==protocol[k]
files=sorted((O/'results').glob('*.json'));assert len(files)==6
samples=[];sets={};commands=[];sources={}
for i,f in enumerate(files):
 d=json.loads(f.read_text());_,errors=validate_result_data(d,f,{m['benchmark_id']:(M,m)},R/'benchmarks');assert not errors,errors
 arm=m['params']['sample_order'][i];diag=d['diagnostics'];assert diag['arm']==arm and diag['position']==i+1 and d['source']['revision']==m['params']['source_revisions'][arm] and d['source']['state']=='clean_commit' and not d['claim_eligible'] and d['status']=='passed'
 assert all(diag[k] for k in ['source_clean_before_after','source_and_dependency_hashes_verified','commands_identical'])
 sample={'attempt':d['attempt_id'],'arm':arm,'build_time_ms':d['metrics']['build_time_ms'],'memory_peak_bytes':d['metrics']['memory_peak_bytes'],'compiler_invocations':{},'critical_path_ms':{}}
 for scenario,v in diag['scenarios'].items():
  assert v['execution']['started_at']>freeze['frozen_at'];assert v['execution']['exit_code']==0
  current=frozenset(v['sources']);key=(arm,scenario);assert sets.get(key,current)==current;sets[key]=current
  sample['compiler_invocations'][scenario]=v['compiler_invocations'];sample['critical_path_ms'][scenario]=v['critical_path']['duration_ms']
  sample.setdefault('producer_durations_ms',{})[scenario]={r['source']:r['duration_ms'] for r in v['producer_rows']}
 samples.append(sample)
 commands.append(hashlib.sha256((O/d['attempt_id']/'compile_commands.json').read_bytes()).hexdigest())
 assert diag['scenarios']['config_impl']['compiler_invocations']==1 and diag['scenarios']['noop']['compiler_invocations']==0
assert len(set(commands))==1
removed=sets[('before','config_interface')]-sets[('after','config_interface')];added=sets[('after','config_interface')]-sets[('before','config_interface')]
expected={'src/app/Sandbox/Editor/Sandbox.'+x+'.cpp' for x in ['DomainPanels','MeshProcessingPanels','PanelSupport']};assert removed==expected and not added,(removed,added)
summary={'benchmark_id':m['benchmark_id'],'source_revisions':m['params']['source_revisions'],'freeze':freeze,'samples':samples,'config_interface_removed_sources':sorted(removed),'config_interface_added_sources':sorted(added),'compiler_commands_sha256':commands[0],'compiler_commands_count':len(json.loads((O/samples[0]['attempt']/'compile_commands.json').read_text())),'arms':{},'protocol':protocol}
for arm in ('before','after'):
 sub=[x for x in samples if x['arm']==arm];assert len(sub)==3;summary['arms'][arm]={}
 for metric in ('build_time_ms','memory_peak_bytes','compiler_invocations','critical_path_ms'):
  summary['arms'][arm][metric]={}
  for scenario in sub[0][metric]:
   v=[x[metric][scenario] for x in sub];summary['arms'][arm][metric][scenario]={'median':statistics.median(v),'min':min(v),'max':max(v),'samples':v}
 producers=sorted({p for x in sub for p in x['producer_durations_ms']['config_interface']});summary['arms'][arm]['config_interface_producers']={p:{'median':statistics.median(v:=[x['producer_durations_ms']['config_interface'][p] for x in sub]),'min':min(v),'max':max(v)} for p in producers}
summary['median_reduction_percent']={s:100*(1-summary['arms']['after']['build_time_ms'][s]['median']/summary['arms']['before']['build_time_ms'][s]['median']) for s in m['params']['scenarios']}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'arms':{a:{k:v for k,v in d.items() if k in ['build_time_ms','compiler_invocations']} for a,d in summary['arms'].items()},'median_reduction_percent':summary['median_reduction_percent'],'removed':sorted(removed)},indent=2))
