import pathlib,subprocess,json,time
p=pathlib.Path('/tmp/intrinsic-entt-assessment-20260921')
base='''#include <entt/entity/registry.hpp>
#include <vector>
struct Component { std::vector<float> values; };
'''
variants={'baseline':'','assure':'extern template auto &entt::basic_registry<>::assure<Component>(entt::id_type);\n','storage':'extern template class entt::basic_storage<Component>;\nextern template class entt::basic_sigh_mixin<entt::basic_storage<Component>, entt::registry>;\n'}
results=[]
for name,decl in variants.items():
 src=p/(name+'.cpp');src.write_text(base+decl+'Component &read(entt::registry &r,entt::entity e) { return r.get<Component>(e); }\n')
 args=['/usr/bin/clang++-23','-std=c++23','-O0','-g','-fno-exceptions','-fno-rtti','-isystem','/home/alex/Documents/IntrinsicEngine/external/vcpkg-installed/ci/x64-linux/include','-ftime-trace='+str(p/(name+'.json')),'-c',str(src),'-o',str(p/(name+'.o'))]
 t=time.monotonic();r=subprocess.run(args,capture_output=True,text=True);(p/(name+'.log')).write_text(r.stdout+r.stderr)
 results.append(dict(name=name,argv=args,elapsed=time.monotonic()-t,returncode=r.returncode))
 if r.returncode: print(name,r.stderr[:1500]);continue
 es=json.load(open(p/(name+'.json')))['traceEvents']; selected=[e for e in es if e.get('name')=='InstantiateFunction' and ('Component' in e.get('args',{}).get('detail',''))];
 for e in sorted(selected,key=lambda e:e['dur'],reverse=True)[:4]:print(name,round(e['dur']/1000,2),e['args']['detail'][:180])
(p/'results.json').write_text(json.dumps(results,indent=2))
