import pathlib,json,hashlib,subprocess
p=pathlib.Path('/tmp/intrinsic-entt-assessment-20260921'); root=pathlib.Path('/home/alex/Documents/IntrinsicEngine')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'repository_source_changed':False,'kind':'standalone feasibility diagnostic, not target benchmark','compiler':subprocess.check_output(['/usr/bin/clang++-23','--version'],text=True).splitlines()[0],'variants':[],'dependency_hashes':{},'retained_trace_hashes':{}}
for r in json.loads((p/'results.json').read_text()):
 events=json.loads((p/(r['name']+'.json')).read_text())['traceEvents']
 r['source_sha256']=h(p/(r['name']+'.cpp'))
 r['assure_events']=[e for e in events if e.get('name')=='InstantiateFunction' and 'assure<Component>' in e.get('args',{}).get('detail','')]
 r['allocation_events']=[e for e in events if e.get('name')=='InstantiateFunction' and e.get('args',{}).get('detail','').startswith('std::allocate_shared<entt::basic_sigh_mixin<entt::basic_storage<Component>')]
 summary['variants'].append(r)
for name in ['registry.hpp','storage.hpp','mixin.hpp']:
 path=root/'external/vcpkg-installed/ci/x64-linux/include/entt/entity'/name;summary['dependency_hashes'][str(path.relative_to(root))]=h(path)
for path in pathlib.Path('/tmp/intrinsic-compile-graph/property-instantiation-after').glob('Test*.json'):summary['retained_trace_hashes'][str(path)]=h(path)
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
