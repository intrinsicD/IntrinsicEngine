#include <entt/entity/registry.hpp>
#include <vector>
struct Component { std::vector<float> values; };
extern template auto &entt::basic_registry<>::assure<Component>(entt::id_type);
Component &read(entt::registry &r,entt::entity e) { return r.get<Component>(e); }
