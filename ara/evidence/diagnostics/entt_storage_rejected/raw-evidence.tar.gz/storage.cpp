#include <entt/entity/registry.hpp>
#include <vector>
struct Component { std::vector<float> values; };
extern template class entt::basic_storage<Component>;
extern template class entt::basic_sigh_mixin<entt::basic_storage<Component>, entt::registry>;
Component &read(entt::registry &r,entt::entity e) { return r.get<Component>(e); }
