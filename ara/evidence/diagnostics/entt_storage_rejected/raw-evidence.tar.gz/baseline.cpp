#include <entt/entity/registry.hpp>
#include <vector>
struct Component { std::vector<float> values; };
Component &read(entt::registry &r,entt::entity e) { return r.get<Component>(e); }
