from pathlib import Path
import json,statistics,sys
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/intrinsic-build007-measure/cohort-20260915-r2')
results=[json.loads(p.read_text()) for p in sorted((root/'results').glob('*.json'))]
def stats(values):
 return {'median':statistics.median(values),'min':min(values),'max':max(values),'samples':values}
by_arm={arm:[r for r in results if r['diagnostics']['arm']==arm] for arm in ['before','after']}
summary={'completed_samples':{a:len(v) for a,v in by_arm.items()},'scenarios':{}}
if all(by_arm.values()):
 for scenario in results[0]['metrics']['build_time_ms']:
  row={}
  for arm,rs in by_arm.items():
   row[arm]={
    'build_seconds':stats([r['metrics']['build_time_ms'][scenario]/1000 for r in rs]),
    'compiler_invocations':stats([r['diagnostics']['scenarios'][scenario]['compiler_invocations'] for r in rs]),
    'critical_seconds':stats([r['diagnostics']['scenarios'][scenario]['critical_path']['duration_ms']/1000 for r in rs]),
    'cpu_seconds':stats([sum(r['diagnostics']['scenarios'][scenario]['execution'][k] for k in ['cpu_user_s','cpu_system_s']) for r in rs]),
    'max_single_process_rss_mib':stats([r['metrics']['memory_peak_bytes'][scenario]/1024**2 for r in rs])}
   if scenario=='reconfigure':row[arm]['configure_plus_build_seconds']=stats([(r['metrics']['configure_time_ms']['reconfigure']+r['metrics']['build_time_ms'][scenario])/1000 for r in rs])
  b=row['before']['build_seconds']['median'];a=row['after']['build_seconds']['median'];row['median_build_reduction_percent']=(b-a)/b*100
  summary['scenarios'][scenario]=row
  print(scenario, f'{b:.3f}s -> {a:.3f}s ({(b-a)/b*100:+.1f}% reduction)', 'compiles',row['before']['compiler_invocations']['samples'],'->',row['after']['compiler_invocations']['samples'])
 full=summary['scenarios']['clean'];edges={}
 for arm,rs in by_arm.items():
  d={}
  for r in rs:
   sample=root/r['attempt_id'];rows=json.loads((sample/'clean.hotspots.json').read_text())
   for row in rows:d.setdefault((row['source'],row['edge_kind']),[]).append(row['duration_ms'])
  edges[arm]=d
 common=set(edges['before'])&set(edges['after'])
 summary['matched_producers']=[{'source':k[0],'kind':k[1],'before_ms':stats(edges['before'][k]),'after_ms':stats(edges['after'][k])} for k in sorted(common)]
 summary['before_only_producers']=[list(k) for k in sorted(set(edges['before'])-common)]
 summary['after_only_producers']=[list(k) for k in sorted(set(edges['after'])-common)]
summary['initial_configure_seconds']={arm:stats([r['metrics']['configure_time_ms']['initial']/1000 for r in rs]) for arm,rs in by_arm.items() if rs}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Completed samples:',summary['completed_samples'])
