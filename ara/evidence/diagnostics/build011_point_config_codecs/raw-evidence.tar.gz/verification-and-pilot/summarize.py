import json,statistics,sys,collections
from pathlib import Path
raw=Path(sys.argv[1]);samples=sorted(raw.glob('[0-9]*-*'))
assert len(samples)==4
rs=[json.loads((p/'raw-result.json').read_text()) for p in samples]
s={'scope':'Clang23 ci Debug Null/headless runtime-contract executable closure, ABBA two samples per arm, caches disabled, local descriptive observations only','scenarios':{},'clean_compiler_seconds_by_source':{},'clean_compiler_duration_sum_s':{}}
for scenario in rs[0]['metrics']['build_time_ms']:
 row={}
 for arm in ['before','after']:
  pop=[r for r in rs if r['diagnostics']['arm']==arm];v=[r['metrics']['build_time_ms'][scenario]/1000 for r in pop]
  row[arm]={'seconds':v,'median_s':statistics.median(v),'min_s':min(v),'max_s':max(v),'compiler_invocations':[r['diagnostics']['scenarios'][scenario]['compiler_invocations'] for r in pop],'loadavg_before':[r['diagnostics']['scenarios'][scenario]['execution']['loadavg_before'] for r in pop]}
 row['saved_s']=row['before']['median_s']-row['after']['median_s'];row['saved_percent']=100*row['saved_s']/row['before']['median_s'];row['nonoverlapping_improvement']=row['after']['max_s']<row['before']['min_s'];s['scenarios'][scenario]=row
for arm in ['before','after']:
 totals=collections.defaultdict(list);sums=[]
 for p in samples:
  if '-'+arm+'-' not in p.name:continue
  times=collections.defaultdict(float)
  for r in json.loads((p/'clean.hotspots.json').read_text()):times[r['source']]+=r['duration_ms']/1000
  sums.append(sum(times.values()))
  for f,t in times.items():totals[f].append(t)
 s['clean_compiler_seconds_by_source'][arm]={f:statistics.median(v) for f,v in sorted(totals.items())};s['clean_compiler_duration_sum_s'][arm]=sums
commands=[{r['file']:r['command'] for r in json.loads((p/'compile_commands.json').read_text())} for p in samples]
common=set.intersection(*(set(c) for c in commands));assert all(len({c[k] for c in commands})==1 for k in common)
s['commands']={'identical_common_commands':len(common),'before_only':sorted(set(commands[0])-set(commands[1])),'after_only':sorted(set(commands[1])-set(commands[0]))}
a=s['scenarios'];g={'header_improves_15_percent_with_separated_ranges':a['shared_header']['saved_percent']>=15 and a['shared_header']['nonoverlapping_improvement'],'clean_regression_at_most_2_percent':a['clean']['saved_percent']>=-2,'clean_compiler_work_reduced':statistics.median(s['clean_compiler_duration_sum_s']['after'])<statistics.median(s['clean_compiler_duration_sum_s']['before']),'individual_codec_regressions_at_most_50_percent':all(a[n]['saved_percent']>=-50 for n in ['normal_codec','density_codec','descriptor_codec'])};g['accepted']=all(g.values());s['acceptance']=g
(raw/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
for n,r in a.items():print(f"{n}: {r['before']['median_s']:.3f} -> {r['after']['median_s']:.3f} seconds; saved {r['saved_percent']:.2f}%")
print(g)
