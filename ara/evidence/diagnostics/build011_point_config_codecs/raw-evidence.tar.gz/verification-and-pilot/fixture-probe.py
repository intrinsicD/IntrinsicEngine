from pathlib import Path
import json,subprocess,shlex,hashlib
root=Path('/home/alex/Documents/IntrinsicEngine');out=Path('/tmp/intrinsic-config-compilation-20260921');build=Path('/dev/shm/intrinsic-build011-clang20');source=root/'tests/support/EditorFeatureTestContext.cpp';before=source.read_text();assert before.startswith('#include "EditorFeatureTestContext.hpp"\n\n#include <utility>')
row=next(r for r in json.loads((build/'compile_commands.json').read_text()) if r['file']==str(source));args=shlex.split(row['command']);args[args.index('-o')+1]=str(out/'fixture-probe.o');records=[]
try:
 for arm in ['before','after']:
  if arm=='after':source.write_text(before.replace('#include "EditorFeatureTestContext.hpp"\n\n#include <utility>','#include <utility>\n\n#include "EditorFeatureTestContext.hpp"',1))
  with (out/f'fixture-{arm}.log').open('w') as stream:r=subprocess.run(args,cwd=row['directory'],stdout=stream,stderr=subprocess.STDOUT)
  records.append({'arm':arm,'returncode':r.returncode,'argv':args,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()});print(arm,r.returncode,flush=True)
 assert records[0]['returncode']!=0 and records[1]['returncode']==0
finally:
 (out/'fixture-probe.json').write_text(json.dumps(records,indent=2)+'\n')
