from pathlib import Path
import json,shlex
root=Path('/tmp/intrinsic-build011-measurement');work=Path('/tmp/intrinsic-config-compilation-20260921');m=json.load(open(work/'moved.json'))
before=json.load(open(root/'01-before-1/compile_commands.json'));after=json.load(open(root/'02-after-1/compile_commands.json'))
def normalized(command):
 args=shlex.split(command);out=[];i=0
 while i<len(args):
  if args[i] in ['-o','-c','-MT','-MF']:i+=2;continue
  if args[i].startswith('@') and args[i].endswith('.modmap'):i+=1;continue
  out.append(args[i]);i+=1
 return out
checks=[]
for new,families in m['groups'].items():
 row=next(r for r in after if r['file'].endswith('/'+new));n=normalized(row['command'])
 for family in families:
  old=f'src/runtime/Modules/{family}/Runtime.{family}Config.cpp';r=next(r for r in before if r['file'].endswith('/'+old));assert normalized(r['command'])==n,(old,new);checks.append({'before':old,'after':new})
(work/'relocated-command-equivalence.json').write_text(json.dumps({'ignored_only':'source, output, dependency file/target and per-TU module-map filenames','matched_flags':checks},indent=2)+'\n');print('All ten relocated source commands retain identical compilation flags.')
