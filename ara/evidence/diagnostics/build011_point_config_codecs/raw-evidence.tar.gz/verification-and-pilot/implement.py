from pathlib import Path
import re,json
root=Path('/home/alex/Documents/IntrinsicEngine')
groups={'PointNeighborhood':['OutlierAnalysis','KernelDensity','PointSpacing','DensityWeight'],'PointFeatures':['BilateralFilter','KeypointAnalysis','DescriptorAnalysis','PointConstruction'],'PointNormalsRegistration':['NormalEstimation','Registration']}
# Preserve every function body. Only disambiguate the two private helper names.
outputs={}; allpaths=[]
for group,families in groups.items():
 includes=set(); bodies=[]; imports=[]
 for f in families:
  p=root/f'src/runtime/Modules/{f}/Runtime.{f}Config.cpp';t=p.read_text();allpaths.append(str(p.relative_to(root)))
  includes.update(re.findall(r'^#include <[^>]+>',t,re.M))
  imports.append(f'import Extrinsic.Runtime.{f}Config;')
  ns=t[t.index('namespace Extrinsic::Runtime'):]
  ns=re.sub(r'\bParse\b',f'Parse{f}Config',ns)
  ns=re.sub(r'\bSection\b',f'Make{f}ConfigSection',ns)
  bodies.append(ns.rstrip())
  interface=p.with_suffix('.cppm');it=interface.read_text()
  # Attach declarations, not their owning config records, globally: existing codec idiom.
  it=re.sub(r'^(    )(?=(?:\[\[nodiscard\]\] )?(?:const char|std::string Serialize|Core::Config::EngineConfigSectionValidationResult|std::optional<|void Set|Core::Config::EngineConfigSectionRegistration|std::array<GeometryPropertyRef))',r'\1extern "C++" ',it,flags=re.M)
  # Standalone [[nodiscard]] + newline patterns need handling separately if any.
  interface.write_text(it)
 path=root/f'src/runtime/Config/internal/Runtime.{group}ConfigCodecs.cpp'
 outputs[str(path.relative_to(root))]=families
 path.write_text('// Compiles '+', '.join(families)+' config codecs together to share JSON work.\n'+'\n'.join(sorted(includes))+'\n\n'+'\n'.join(imports)+'\n\n#include "Config/internal/Runtime.PointConfigJson.hpp"\n\n'+'\n\n'.join(bodies)+'\n')
 for f in families:
  (root/f'src/runtime/Modules/{f}/Runtime.{f}Config.cpp').unlink()
cm=root/'src/runtime/CMakeLists.txt';txt=cm.read_text()
for p in allpaths:
 rel=p.removeprefix('src/runtime/');txt=re.sub(r'^\s*'+re.escape(rel)+r'\n','\n',txt,flags=re.M)
anchor='        Config/internal/Runtime.FeatureConfigCodecs.Detail.cpp'
assert anchor in txt
for p in outputs: txt=txt.replace(anchor,anchor+'\n        '+p.removeprefix('src/runtime/'),1)
cm.write_text(txt)
(root/'/tmp/unused') if False else None
Path('/tmp/intrinsic-config-compilation-20260921/moved.json').write_text(json.dumps({'groups':outputs,'removed':allpaths},indent=2))
