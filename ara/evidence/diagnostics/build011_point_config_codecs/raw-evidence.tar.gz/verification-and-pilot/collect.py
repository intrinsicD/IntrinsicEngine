from pathlib import Path
import json,hashlib,shutil,subprocess,tarfile
repo=Path('/home/alex/Documents/IntrinsicEngine');raw=Path('/tmp/intrinsic-build011-measurement');work=Path('/tmp/intrinsic-config-compilation-20260921');out=repo/'ara/evidence/diagnostics/build011_point_config_codecs'
assert not out.exists()
summary=json.loads((raw/'summary.json').read_text());samples=sorted(raw.glob('[0-9]*-*'));assert len(samples)==4
out.mkdir(parents=True);(out/'results').mkdir()
for name in ['summary.json','protocol.json']:shutil.copy(raw/name,out/name)
for name in ['source-identity.json','verification.json','source-accounting.json','edit-cooccurrence.json']:shutil.copy(work/name,out/name)
for p in (raw/'results').glob('*.json'):shutil.copy(p,out/'results'/p.name)
manifest=repo/'benchmarks/ci/manifests/engine_compile_iteration_point_config_codecs.yaml';shutil.copy(manifest,work/'manifest-frozen.yaml')
archive_files={}
for path in sorted(raw.rglob('*')):
 if path.is_file():archive_files['measurement/'+str(path.relative_to(raw))]=path
# Preserve every build/test/review attempt, compiler commands, source checks and driver bytes.
for path in sorted(work.iterdir()):
 if path.is_file() and path.suffix in ['.log','.json','.txt','.py','.diff','.yaml']:
  archive_files['verification-and-pilot/'+path.name]=path
for path in sorted(Path('/tmp/intrinsic-compile-graph/config-candidate').iterdir()):
 if path.suffix in ['.log','.json']:archive_files['diagnostic-traces/'+path.name]=path
hashes={name:hashlib.sha256(path.read_bytes()).hexdigest() for name,path in archive_files.items()}
(out/'archive-contents.json').write_text(json.dumps(hashes,indent=2)+'\n')
with tarfile.open(out/'raw-evidence.tar.gz','w:gz') as archive:
 for name,path in archive_files.items():archive.add(path,arcname=name)
(out/'evidence-index.json').write_text(json.dumps({str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file()},indent=2)+'\n')
print('Captured',len(hashes),'files at',out)
