#!/usr/bin/env bash
set -euo pipefail
cd /home/alex/Documents/IntrinsicEngine
while ! test -f /tmp/intrinsic-build009/cohort-20260915/results/06-after-3.json; do sleep 10; done
# The result is sealed only after the last timed build and evidence capture.
python3 /tmp/intrinsic-build009/check-comparability.py > /tmp/intrinsic-build009/comparability.log
python3 /tmp/intrinsic-build009/summarize.py /tmp/intrinsic-build009/cohort-20260915 > /tmp/intrinsic-build009/summary.log
printf 'Benchmark complete; configuring current refactor\n'
cmake --preset ci > /tmp/intrinsic-runtime266/ci-configure.log 2>&1
printf 'Building IntrinsicTests\n'
cmake --build --preset ci --target IntrinsicTests -j 4 > /tmp/intrinsic-runtime266/ci-build.log 2>&1
printf 'Running focused CPU checks\n'
ctest --test-dir build/ci --output-on-failure -R 'CompilationLocality|SceneRegistry|SceneSerialization|SelectionController|StableEntity|WorldRegistry|SandboxEditor|SceneEditing|EditorCommandHistory|RuntimeConfig' -LE 'gpu|vulkan|slow|flaky-quarantine' --no-tests=error --timeout 60 > /tmp/intrinsic-runtime266/ci-focused.log 2>&1
printf 'Running full CPU gate\n'
ctest --test-dir build/ci --output-on-failure -LE 'gpu|vulkan|slow|flaky-quarantine' --timeout 60 > /tmp/intrinsic-runtime266/ci-cpu.log 2>&1
printf 'CPU verification complete\n'
