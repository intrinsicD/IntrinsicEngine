#!/usr/bin/env bash
set -euo pipefail
cd /home/alex/Documents/IntrinsicEngine
while ! rg --quiet '^COMPLETE 04-before-2$' /tmp/intrinsic-runtime266/runner.log; do sleep 10; done
python3 /tmp/intrinsic-runtime266/check-comparability.py > /tmp/intrinsic-runtime266/comparability.log
python3 /tmp/intrinsic-runtime266/summarize.py /tmp/intrinsic-runtime266/cohort-20260915 > /tmp/intrinsic-runtime266/summary.log
python3 tools/benchmark/validate_benchmark_results.py --root /tmp/intrinsic-runtime266/cohort-20260915/results --manifests-root benchmarks --strict > /tmp/intrinsic-runtime266/result-validation.log
printf 'All four samples validated and summarized\n'
