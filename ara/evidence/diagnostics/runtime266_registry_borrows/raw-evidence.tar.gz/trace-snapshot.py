from pathlib import Path
import json,shlex,subprocess,time,hashlib
p=Path('/tmp/intrinsic-runtime266'); log=p/'runner.log'
while 'COMPLETE 04-before-2\n' not in log.read_text():time.sleep(10)
r=json.loads((p/'snapshot-compiler-command.json').read_text());args=shlex.split(r['command']);cwd=Path(r['directory'])
refs=[(i,a) for i,a in enumerate(args) if a.startswith('@')];assert len(refs)==1
idx,arg=refs[0];old=cwd/arg[1:];lines=old.read_text().splitlines();assert sum(x.startswith('-fmodule-output=') for x in lines)==1
out_pcm=p/'snapshot-trace.pcm';out_obj=p/'snapshot-trace.o';out_map=p/'snapshot-trace.modmap';out_trace=p/'snapshot-trace.json'
assert not any(x.exists() for x in [out_pcm,out_obj,out_map,out_trace])
new='\n'.join('-fmodule-output='+str(out_pcm) if x.startswith('-fmodule-output=') else x for x in lines)+'\n';out_map.write_text(new)
args[idx]='@'+str(out_map);args[args.index('-o')+1]=str(out_obj);args.append('-ftime-trace='+str(out_trace))
identity={'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_file':r['file'],'source_sha256':hashlib.sha256(Path(r['file']).read_bytes()).hexdigest(),'command':args,'cwd':str(cwd),'scope':'Single diagnostic compile of the verified after source, outside timed samples; isolated output PCM/object, existing dependency BMIs read only. Trace overhead is not benchmark timing.'}
(p/'snapshot-trace-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
with (p/'snapshot-trace.log').open('w') as out:ret=subprocess.run(args,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
assert ret.returncode==0,ret.returncode
data=json.loads(out_trace.read_text());events=data['traceEvents']
totals=[{'name':x['name'],'milliseconds':x['dur']/1000,'args':x.get('args',{})} for x in events if x['name'].startswith('Total ') and 'dur' in x]
totals.sort(key=lambda x:x['milliseconds'],reverse=True)
longest=[{'name':x['name'],'milliseconds':x['dur']/1000,'args':x.get('args',{})} for x in events if not x['name'].startswith('Total ') and 'dur' in x]
longest.sort(key=lambda x:x['milliseconds'],reverse=True)
(p/'snapshot-trace-summary.json').write_text(json.dumps({'totals':totals,'longest_events':longest[:40],'event_count':len(events),'scope':identity['scope']},indent=2)+'\n')
print('Diagnostic snapshot trace complete')
