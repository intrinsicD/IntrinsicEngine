from pathlib import Path
import json,subprocess
p=Path('/tmp/intrinsic-runtime266');original=json.loads((p/'snapshot-trace-identity.json').read_text())
args=[x.replace('snapshot-trace','snapshot-full-trace') for x in original['command']]+['-fno-modules-reduced-bmi']
mp=p/'snapshot-full-trace.modmap';assert not mp.exists();mp.write_text((p/'snapshot-trace.modmap').read_text().replace('snapshot-trace','snapshot-full-trace'))
d={**original,'command':args,'scope':'Single diagnostic Full-BMI comparison against the previous reduced-BMI trace; fresh isolated outputs and same source/dependency BMIs. Not a repeated timing benchmark or validated project-wide mode.'}
(p/'snapshot-full-trace-identity.json').write_text(json.dumps(d,indent=2)+'\n')
with (p/'snapshot-full-trace.log').open('w') as out:r=subprocess.run(args,cwd=d['cwd'],stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0,r.returncode
x=json.loads((p/'snapshot-full-trace.json').read_text());totals=[{'name':e['name'],'milliseconds':e['dur']/1000,'args':e.get('args',{})} for e in x['traceEvents'] if e['name'].startswith('Total ') and 'dur' in e];totals.sort(key=lambda x:x['milliseconds'],reverse=True)
y={'totals':totals,'pcm_bytes':(p/'snapshot-full-trace.pcm').stat().st_size,'scope':d['scope']};(p/'snapshot-full-trace-summary.json').write_text(json.dumps(y,indent=2)+'\n');print(json.dumps(y,indent=2))
