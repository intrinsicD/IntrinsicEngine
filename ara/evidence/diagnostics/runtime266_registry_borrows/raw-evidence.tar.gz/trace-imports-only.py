from pathlib import Path
import json,re,subprocess,time
p=Path('/tmp/intrinsic-runtime266');identity=json.load(open(p/'snapshot-trace-identity.json'));source=Path(identity['source_file']).read_text()
probe=p/'SnapshotImportsOnly.cppm';assert not probe.exists()
gmf=source.split('export module ',1)[0]
imports='\n'.join(re.findall(r'^(?:export )?import [^;]+;',source,re.M))
probe.write_text(gmf+'export module Intrinsic.Diagnostic.SnapshotImportsOnly;\n'+imports+'\nexport constexpr int SnapshotImportProbe() noexcept { return 0; }\n')
args=[x.replace('snapshot-trace','snapshot-imports-trace') for x in identity['command']]
args[args.index('-c')+1]=str(probe)
mp=p/'snapshot-imports-trace.modmap';mp.write_text((p/'snapshot-trace.modmap').read_text().replace('snapshot-trace','snapshot-imports-trace'))
start=time.perf_counter()
with (p/'snapshot-imports-trace.log').open('w') as out:r=subprocess.run(args,cwd=identity['cwd'],stdout=out,stderr=subprocess.STDOUT)
elapsed=time.perf_counter()-start;assert r.returncode==0,r.returncode
x=json.load(open(p/'snapshot-imports-trace.json'));totals=[{'name':e['name'],'milliseconds':e['dur']/1000} for e in x['traceEvents'] if e['name'].startswith('Total ') and 'dur' in e];totals.sort(key=lambda x:x['milliseconds'],reverse=True)
d={'command':args,'cwd':identity['cwd'],'source':str(probe),'wall_seconds':elapsed,'pcm_bytes':(p/'snapshot-imports-trace.pcm').stat().st_size,'totals':totals,'scope':'Synthetic diagnostic retaining the snapshot GMF/includes and every direct import, replacing own declarations with one trivial exported function. Different module identity, no correctness equivalence or benchmark speedup claim.'}
(p/'snapshot-imports-trace-summary.json').write_text(json.dumps(d,indent=2)+'\n');print('Imports-only diagnostic complete:',elapsed)
