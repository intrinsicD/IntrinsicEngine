#!/usr/bin/env bash
set -euo pipefail
cd /home/alex/Documents/IntrinsicEngine
build_path=/dev/shm/intrinsic-runtime266-clang20
if test -e "$build_path"; then printf 'Refusing existing proof build\n' >&2; exit 1; fi
mkdir "$build_path"
printf 'RUNTIME-266 minimum compiler verification\n' > "$build_path/.runtime266-owner"
export CCACHE_DISABLE=1
cmake --preset ci -B "$build_path" \
  -DCMAKE_C_COMPILER=/usr/bin/clang-20 \
  -DCMAKE_CXX_COMPILER=/usr/bin/clang++-20 \
  -DCMAKE_CXX_COMPILER_CLANG_SCAN_DEPS=/usr/bin/clang-scan-deps-20 \
  -DCMAKE_C_COMPILER_LAUNCHER= -DCMAKE_CXX_COMPILER_LAUNCHER= \
  -DINTRINSIC_ENABLE_CCACHE=OFF -DVCPKG_MANIFEST_INSTALL=OFF \
  -DEXTRINSIC_BACKEND=Null -DINTRINSIC_PLATFORM_BACKEND=Null \
  -DINTRINSIC_HEADLESS_NO_GLFW=ON -DINTRINSIC_BUILD_TESTS=ON \
  -DINTRINSIC_BUILD_BENCHMARKS=OFF -DINTRINSIC_BUILD_SANDBOX=ON \
  > /tmp/intrinsic-runtime266/clang20-configure.log 2>&1
printf 'Building Sandbox editor library and engine with fresh Clang20\n'
cmake --build "$build_path" --target ExtrinsicSandboxEditor -j 4 \
  > /tmp/intrinsic-runtime266/clang20-build.log 2>&1
python3 - <<'PY'
from pathlib import Path
import json,subprocess
p=Path('/tmp/intrinsic-runtime266')
cmd=json.loads((p/'guard-command.json').read_text()); cmd[cmd.index('--build-dir')+1]='/dev/shm/intrinsic-runtime266-clang20'
r=subprocess.run(cmd,capture_output=True,text=True)
(p/'clang20-boundary.log').write_text(r.stdout+r.stderr)
print(r.stdout+r.stderr);raise SystemExit(r.returncode)
PY
printf 'Minimum compiler proof complete\n'
