from pathlib import Path
import hashlib,json
p=Path('/tmp/intrinsic-runtime266/cohort-20260915')
rs=[json.loads(x.read_text()) for x in sorted((p/'results').glob('*.json'))]
assert len(rs)==4, len(rs)
expected=['before','after','after','before']
assert [r['diagnostics']['arm'] for r in rs]==expected
protocol=json.loads((p/'protocol.json').read_text())
manifest=Path('benchmarks/ci/manifests/engine_compile_iteration_registry_borrow.yaml')
assert hashlib.sha256(manifest.read_bytes()).hexdigest()==protocol['manifest_sha256']
entries=[]; commands=[]; dependencies=[]
for r in rs:
 d=p/r['attempt_id']; commands.append({x['file']:x['command'] for x in json.loads((d/'compile_commands.json').read_text())})
 dependencies.append(json.loads((d/'dependencies.json').read_text()))
 assert r['source']['revision']==protocol['manifest']['params']['source_revisions'][r['diagnostics']['arm']]
 assert r['claim_eligible'] is False
 assert r['diagnostics']['source_clean_before_after']
 assert r['manifest']['sha256']==protocol['manifest_sha256']
 for name,s in r['diagnostics']['scenarios'].items():
  assert s['execution']['exit_code']==0
  assert s['execution']==json.loads((d/(name+'.execution.json')).read_text())
  assert s['compiler_invocations']==len(json.loads((d/(name+'.hotspots.json')).read_text()))
 entries.append({'attempt':r['attempt_id'],'arm':r['diagnostics']['arm'],'sha256':hashlib.sha256((p/'results'/(r['attempt_id']+'.json')).read_bytes()).hexdigest()})
assert all(d==dependencies[0] for d in dependencies)
common=set.intersection(*(set(c) for c in commands))
assert all(len({c[f] for c in commands})==1 for f in common)
source_prefix='/tmp/intrinsic-build009/source/'
report={'samples':entries,'sample_counts':{'before':2,'after':2},'shared_sources_with_identical_compiler_commands':len(common),'identical_dependencies_all_four':dependencies[0],'before_only_sources':[f.replace(source_prefix,'') for f in sorted(set(commands[0])-set(commands[1]))],'after_only_sources':[f.replace(source_prefix,'') for f in sorted(set(commands[1])-set(commands[0]))],'claim_eligible':False,'raw_scenario_execution_records_identical_to_results':True}
(p/'comparability.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
